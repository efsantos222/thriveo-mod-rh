<?php
/**
 * PagBank Webhook Handler for Thriveo (WordPress Integrated)
 * URL: https://thriveo.com.br/webhook/pagbank.php
 */

// 1. Carregar o WordPress
define('WP_USE_THEMES', false);
require_once __DIR__ . '/../wp-load.php';

// 2. Log de Entrada (Segurança e Debug)
$raw_body = file_get_contents('php://input');
$payload = json_decode($raw_body, true);
$evento = $payload['type'] ?? 'unknown';

global $wpdb;
$wpdb->insert($wpdb->prefix . 'thriveo_pagbank_webhook_logs', [
    'evento' => $evento,
    'payload' => $raw_body,
    'criado_em' => current_time('mysql')
]);
$log_id = $wpdb->insert_id;

// 3. Roteamento de Eventos
try {
    switch ($evento) {
        case 'subscription.activated':
        case 'subscription.created':
            $sub_id = $payload['data']['subscription']['id'] ?? '';
            if ($sub_id) {
                $wpdb->update($wpdb->prefix . 'thriveo_pagbank_assinaturas', 
                    ['status' => 'ativa'], 
                    ['pagbank_subscription_id' => $sub_id]
                );
            }
            break;

        case 'charge.paid':
        case 'subscription.recurring_charge.paid':
            $charge = $payload['data']['charge'] ?? [];
            if (!empty($charge['id'])) {
                $wpdb->insert($wpdb->prefix . 'thriveo_pagbank_faturas', [
                    'assinatura_id' => 0, // Precisaria buscar pelo sub_id
                    'pagbank_charge_id' => $charge['id'],
                    'valor' => $charge['amount']['value'] / 100,
                    'status' => 'paga',
                    'metodo_pagamento' => $charge['payment_method']['type'] ?? 'CC',
                    'pago_em' => current_time('mysql')
                ]);
            }
            break;

        case 'subscription.canceled':
            $sub_id = $payload['data']['subscription']['id'] ?? '';
            $wpdb->update($wpdb->prefix . 'thriveo_pagbank_assinaturas', 
                ['status' => 'cancelada'], 
                ['pagbank_subscription_id' => $sub_id]
            );
            break;
    }

    $wpdb->update($wpdb->prefix . 'thriveo_pagbank_webhook_logs', 
        ['processado' => 1], 
        ['id' => $log_id]
    );

} catch (Exception $e) {
    error_log('Erro PagBank Webhook: ' . $e->getMessage());
}

// 4. Resposta Obrigatória
http_response_code(200);
echo "OK";
