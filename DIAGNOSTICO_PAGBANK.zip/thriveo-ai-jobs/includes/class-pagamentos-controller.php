<?php
/**
 * Controller for Payments (Mercado Pago / PagSeguro)
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Pagamentos_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        add_action('wp_ajax_nopriv_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        
        add_action('wp_ajax_thriveo_create_subscription', [__CLASS__, 'create_subscription_ajax']);
    }

    /**
     * Retorna a Chave Pública para criptografia no Frontend
     */
    public static function get_public_key()
    {
        // Em um cenário real, o PagBank fornece a pub key via API ou Painel
        // Aqui buscamos das configurações
        $config = Thriveo_AI_Jobs_PagBank_Handler::get_config();
        
        // Simulação de Public Key se não configurada (para não travar o dev)
        $pub_key = get_option('thriveo_pagbank_public_key', 'PUBSB-87A3E891...'); 

        wp_send_json_success([
            'public_key' => $pub_key,
            'environment' => $config['ambiente']
        ]);
    }

    /**
     * Cria a Assinatura (AJAX)
     */
    public static function create_subscription_ajax()
    {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Usuário não autenticado.']);
        }

        $card_encrypted = sanitize_text_field($_POST['card_encrypted']);
        $plano_slug = sanitize_text_field($_POST['plano_slug']);
        $current_user = wp_get_current_user();

        // 1. Verificar se o plano existe no WP
        global $wpdb;
        $plano = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}thriveo_pagbank_planos WHERE slug = %s",
            $plano_slug
        ));

        if (!$plano) {
            wp_send_json_error(['message' => 'Plano inválido.']);
        }

        // 2. Chamada ao Handler do PagBank
        $subscription_data = [
            'pagbank_plan_id' => $plano->pagbank_plan_id,
            'reference_id'    => 'USER_' . $current_user->ID . '_' . time(),
            'customer_name'   => $current_user->display_name,
            'customer_email'  => $current_user->user_email,
            'customer_tax_id' => '123.456.789-00', // Capturar do perfil se possível
            'card_encrypted'  => $card_encrypted,
            'card_holder_name' => $current_user->display_name,
        ];

        $response = Thriveo_AI_Jobs_PagBank_Handler::criar_assinatura($subscription_data);

        if (!$response['success']) {
            wp_send_json_error([
                'message' => 'Erro no PagBank: ' . ($response['data']['error_messages'][0]['description'] ?? 'Erro desconhecido')
            ]);
        }

        // 3. Salvar Assinatura no Banco (Pendente de Webhook)
        $sub_id = $response['data']['id'];
        $wpdb->insert($wpdb->prefix . 'thriveo_pagbank_assinaturas', [
            'empresa_id' => $current_user->ID, // Vincula ao usuário por enquanto
            'plano_id'   => $plano->id,
            'pagbank_subscription_id' => $sub_id,
            'status'     => 'pendente',
            'criado_em'  => current_time('mysql')
        ]);

        wp_send_json_success([
            'message' => 'Assinatura criada com sucesso! Processando pagamento...',
            'subscription_id' => $sub_id
        ]);
    }

    public static function webhook()
    {
        // Implementação delegada ao arquivo externo ou endpoint REST
    }
}
