<?php
/**
 * PagBank API Handler for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_PagBank_Handler
{
    private static $sandbox_url = 'https://sandbox.api.pagseguro.com';
    private static $production_url = 'https://api.pagseguro.com';

    public static function get_config()
    {
        $ambiente = get_option('thriveo_pagbank_ambiente', 'sandbox');
        $token = ($ambiente === 'production') 
            ? get_option('thriveo_pagbank_token_prod', '87a3e891-7b37-4801-ae79-4840f208e0a76bed935a47d8be22297fcc945c5bdb145a3d-a4b1-48cb-879b-b73313732e6c')
            : get_option('thriveo_pagbank_token_sandbox', 'A22E62CD838A43F3A39FC096B9553D4F');

        return [
            'ambiente' => $ambiente,
            'url'      => ($ambiente === 'production') ? self::$production_url : self::$sandbox_url,
            'token'    => $token
        ];
    }

    private static function request($method, $endpoint, $body = [])
    {
        $config = self::get_config();
        $url = $config['url'] . $endpoint;

        $args = [
            'method'  => $method,
            'timeout' => 45,
            'headers' => [
                'Authorization' => 'Bearer ' . $config['token'],
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
        ];

        if (!empty($body)) {
            $args['body'] = json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        return [
            'success' => ($code >= 200 && $code < 300),
            'code'    => $code,
            'data'    => $data
        ];
    }

    /**
     * Cria Plano de Assinatura
     */
    public static function criar_plano($nome, $valor_centavos, $slug)
    {
        $payload = [
            'reference_id' => 'thriveo_plano_' . $slug,
            'name'         => $nome,
            'interval'     => [
                'unit'   => 'MONTH',
                'length' => 1,
            ],
            'amount' => [
                'value'    => (int) $valor_centavos,
                'currency' => 'BRL',
            ],
        ];

        return self::request('POST', '/recurring/plans', $payload);
    }

    /**
     * Cria Assinatura com Cartão Tokenizado
     */
    public static function criar_assinatura($dados)
    {
        $payload = [
            'plan'         => ['id' => $dados['pagbank_plan_id']],
            'reference_id' => $dados['reference_id'],
            'customer'     => [
                'name'   => $dados['customer_name'],
                'email'  => $dados['customer_email'],
                'tax_id' => preg_replace('/\D/', '', $dados['customer_tax_id']),
            ],
            'payment_method' => [
                'type' => 'CREDIT_CARD',
                'card' => [
                    'encrypted' => $dados['card_encrypted'],
                    'store'     => true,
                    'holder'    => [
                        'name' => $dados['card_holder_name'],
                    ],
                ],
            ],
        ];

        return self::request('POST', '/recurring/subscriptions', $payload);
    }

    /**
     * Webhook Verification - Ranges de IP do PagBank (Simulado para segurança básica)
     */
    public static function is_valid_webhook_origin($ip)
    {
        // Em produção, verificar se o IP pertence ao PagBank
        return true; 
    }
}
