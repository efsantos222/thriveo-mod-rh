<?php
session_start();
require_once 'includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);
    
    error_log("DEBUG - Tentativa de login:");
    error_log("Email fornecido: " . $email);
    error_log("Senha fornecida (length: " . strlen($senha) . "): " . $senha);
    
    // Verificar no arquivo de candidatos DISC
    $candidatos_file = 'resultados/candidatos.csv';
    $autenticado = false;
    $user_type = '';
    
    if (file_exists($candidatos_file)) {
        $fp = fopen($candidatos_file, 'r');
        if ($fp !== false) {
            $header = fgetcsv($fp);
            error_log("Cabeçalho do arquivo DISC: " . implode(", ", $header));
            
            $status_index = 8;
            foreach ($header as $index => $column) {
                if (strtolower(trim($column)) === 'status') {
                    $status_index = $index;
                    break;
                }
            }
            error_log("Índice da coluna de status DISC: " . $status_index);
            
            while (($data = fgetcsv($fp)) !== FALSE) {
                if ($data[4] === $email) {
                    error_log("Email encontrado para: " . $email);
                    error_log("Hash armazenado: " . $data[5]);
                    
                    if (password_verify($senha, $data[5])) {
                        $status = isset($data[$status_index]) ? strtolower(trim($data[$status_index])) : '';
                        
                        if ($status === 'completed') {
                            header('Location: login.php?error=test_completed');
                            exit;
                        }
                        
                        $autenticado = true;
                        $user_type = 'disc';
                        $_SESSION['authenticated'] = true;
                        $_SESSION['user_type'] = 'disc';
                        $_SESSION['questao_atual'] = 0;
                        
                        $_SESSION['user_data'] = [
                            'data_criacao' => $data[0],
                            'selecionador_nome' => $data[1],
                            'selecionador_email' => $data[2],
                            'candidato_nome' => $data[3],
                            'candidato_email' => $data[4],
                            'cargo' => isset($data[6]) ? $data[6] : '',
                            'observacoes' => isset($data[7]) ? $data[7] : '',
                            'status' => isset($data[8]) ? $data[8] : 'pendente'
                        ];
                        break;
                    }
                }
            }
            fclose($fp);
        }
    }
    
    // Se não encontrou no DISC, verificar no MBTI
    if (!$autenticado) {
        $candidatos_mbti_file = 'resultados/candidatos_mbti.csv';
        
        if (file_exists($candidatos_mbti_file)) {
            $fp = fopen($candidatos_mbti_file, 'r');
            if ($fp !== false) {
                $header = fgetcsv($fp);
                error_log("Cabeçalho do arquivo MBTI: " . implode(", ", $header));
                
                $status_index = 8;
                foreach ($header as $index => $column) {
                    if (strtolower(trim($column)) === 'status') {
                        $status_index = $index;
                        break;
                    }
                }
                error_log("Índice da coluna de status MBTI: " . $status_index);
                
                while (($data = fgetcsv($fp)) !== FALSE) {
                    if ($data[4] === $email) {
                        error_log("Email encontrado para: " . $email);
                        error_log("Hash armazenado MBTI: " . $data[5]);
                        error_log("Dados completos do usuário MBTI: " . implode(", ", $data));
                        
                        if (password_verify($senha, $data[5])) {
                            $status = isset($data[$status_index]) ? strtolower(trim($data[$status_index])) : '';
                            error_log("Status do teste MBTI: " . $status);
                            
                            if ($status === 'completed') {
                                header('Location: login.php?error=test_completed');
                                exit;
                            }
                            
                            $autenticado = true;
                            $user_type = 'mbti';
                            $_SESSION['authenticated'] = true;
                            $_SESSION['user_type'] = 'mbti';
                            $_SESSION['questao_atual'] = 0;
                            
                            $_SESSION['user_data'] = [
                                'data_criacao' => $data[0],
                                'selecionador_nome' => $data[1],
                                'selecionador_email' => $data[2],
                                'candidato_nome' => $data[3],
                                'candidato_email' => $data[4],
                                'cargo' => isset($data[6]) ? $data[6] : '',
                                'observacoes' => isset($data[7]) ? $data[7] : '',
                                'status' => isset($data[8]) ? $data[8] : 'pendente'
                            ];
                            break;
                        }
                    }
                }
                fclose($fp);
            }
        }
    }

    // Se não encontrou no DISC nem no MBTI, verificar no Big Five
    if (!$autenticado) {
        $senhas_bigfive_file = 'senhas/senhas_bigfive.csv';
        $candidatos_bigfive_file = 'resultados/candidatos_bigfive.csv';
        
        if (file_exists($senhas_bigfive_file) && file_exists($candidatos_bigfive_file)) {
            // Primeiro verificar a senha
            $senha_correta = false;
            $fp_senhas = fopen($senhas_bigfive_file, 'r');
            if ($fp_senhas !== false) {
                $header = fgetcsv($fp_senhas);
                error_log("Cabeçalho do arquivo de senhas Big Five: " . implode(", ", $header));
                
                while (($data = fgetcsv($fp_senhas)) !== FALSE) {
                    if ($data[0] === $email && $data[1] === $senha) {
                        $senha_correta = true;
                        break;
                    }
                }
                fclose($fp_senhas);
            }
            
            // Se a senha estiver correta, buscar dados do candidato
            if ($senha_correta) {
                $fp_candidatos = fopen($candidatos_bigfive_file, 'r');
                if ($fp_candidatos !== false) {
                    $header = fgetcsv($fp_candidatos);
                    error_log("Cabeçalho do arquivo Big Five: " . implode(", ", $header));
                    
                    while (($data = fgetcsv($fp_candidatos)) !== FALSE) {
                        if ($data[4] === $email) { // Email está na quinta coluna
                            $status = isset($data[7]) ? strtolower(trim($data[7])) : 'pendente';
                            
                            if ($status === 'completed') {
                                header('Location: login.php?error=test_completed');
                                exit;
                            }
                            
                            $autenticado = true;
                            $user_type = 'bigfive';
                            $_SESSION['bigfive_authenticated'] = true;
                            $_SESSION['bigfive_email'] = $email;
                            $_SESSION['bigfive_nome'] = $data[3];
                            
                            $_SESSION['user_data'] = [
                                'data_criacao' => $data[0],
                                'selecionador_nome' => $data[1],
                                'selecionador_email' => $data[2],
                                'candidato_nome' => $data[3],
                                'candidato_email' => $data[4],
                                'empresa' => $data[5],
                                'cargo' => $data[6],
                                'status' => $status
                            ];
                            
                            header('Location: bigfive_test.php');
                            exit;
                        }
                    }
                    fclose($fp_candidatos);
                }
            }
        }
    }
}

header('Location: login.php?error=invalid');
exit;
