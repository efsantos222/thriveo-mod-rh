<?php
session_start();

// Verificar se está logado como superadmin
if (!isset($_SESSION['superadmin_authenticated']) || !$_SESSION['superadmin_authenticated']) {
    header('Location: superadmin_login.php');
    exit;
}

function deleteFromCSV($email, $file) {
    if (!file_exists($file)) {
        return false;
    }

    $lines = file($file);
    $out = fopen($file . '.tmp', 'w');
    
    $header = true;
    foreach ($lines as $line) {
        if ($header) {
            fwrite($out, $line);
            $header = false;
            continue;
        }
        
        $data = str_getcsv($line);
        if ($data[4] !== $email) { // email está na posição 4
            fwrite($out, $line);
        }
    }
    
    fclose($out);
    unlink($file);
    rename($file . '.tmp', $file);
    return true;
}

function deleteSelecionador($email) {
    $admins_file = 'resultados/admins.csv';
    if (!file_exists($admins_file)) {
        return false;
    }

    $lines = file($admins_file);
    $out = fopen($admins_file . '.tmp', 'w');
    
    $header = true;
    foreach ($lines as $line) {
        if ($header) {
            fwrite($out, $line);
            $header = false;
            continue;
        }
        
        $data = str_getcsv($line);
        if ($data[1] !== $email) { // email está na posição 1
            fwrite($out, $line);
        }
    }
    
    fclose($out);
    unlink($admins_file);
    rename($admins_file . '.tmp', $admins_file);
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';
    $email = $_POST['email'] ?? '';
    $response = ['success' => false, 'message' => ''];

    if (empty($email)) {
        $response['message'] = 'Email não fornecido';
        echo json_encode($response);
        exit;
    }

    switch ($type) {
        case 'disc':
            // Excluir candidato DISC
            if (deleteFromCSV($email, 'resultados/candidatos.csv')) {
                // Excluir arquivo de avaliação DISC
                $avaliacao_file = 'resultados/' . str_replace(['@', '.'], '_', $email) . '_avaliacao.csv';
                if (file_exists($avaliacao_file)) {
                    unlink($avaliacao_file);
                }
                $response['success'] = true;
                $response['message'] = 'Candidato DISC excluído com sucesso';
            }
            break;

        case 'mbti':
            // Excluir candidato MBTI
            if (deleteFromCSV($email, 'resultados/candidatos_mbti.csv')) {
                // Excluir arquivo de avaliação MBTI
                $avaliacao_file = 'resultados/' . str_replace(['@', '.'], '_', $email) . '_avaliacao_mbti.csv';
                if (file_exists($avaliacao_file)) {
                    unlink($avaliacao_file);
                }
                $response['success'] = true;
                $response['message'] = 'Candidato MBTI excluído com sucesso';
            }
            break;

        case 'selecionador':
            // Excluir selecionador
            if (deleteSelecionador($email)) {
                $response['success'] = true;
                $response['message'] = 'Selecionador excluído com sucesso';
            }
            break;

        default:
            $response['message'] = 'Tipo de exclusão inválido';
    }

    echo json_encode($response);
    exit;
}
