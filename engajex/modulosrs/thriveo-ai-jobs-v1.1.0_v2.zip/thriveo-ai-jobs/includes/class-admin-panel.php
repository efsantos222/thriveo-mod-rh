<?php
/**
 * Admin Panel for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Admin_Panel
{

    public static function init()
    {
        add_action('admin_menu', [__CLASS__, 'add_admin_menu']);
    }

    public static function add_admin_menu()
    {
        add_menu_page(
            'Thriveo AI Jobs',
            'Thriveo IA',
            'manage_options',
            'thriveo-ai-jobs',
            [__CLASS__, 'render_admin_page'],
            'dashicons-groups',
            30
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Candidatos (IA)',
            'Candidatos',
            'manage_options',
            'thriveo-ai-candidates',
            [__CLASS__, 'render_candidates_page']
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Empresas / Vagas',
            'Empresas & Vagas',
            'manage_options',
            'thriveo-ai-companies',
            [__CLASS__, 'render_companies_page']
        );
    }

    public static function render_admin_page()
    {
        ?>
        <div class="wrap">
            <h1>Painel Thriveo AI Jobs</h1>
            <p>Bem-vindo ao gerenciamento do talento de IA da Thriveo.</p>
            <p>Use os submenus para gerenciar candidatos, empresas (e seus status de pagamento).</p>
        </div>
        <?php
    }

    public static function render_candidates_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_candidates';
        $candidates = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC LIMIT 50");
        ?>
        <div class="wrap">
            <h1>Candidatos IA</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Provider</th>
                        <th>Autorizado Divulgação?</th>
                        <th>Repositórios Públicos</th>
                        <th>Data Cadastro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($candidates)): ?>
                        <tr>
                            <td colspan="7">Nenhum candidato encontrado.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($candidates as $c): ?>
                            <tr>
                                <td>#
                                    <?php echo esc_html($c->id); ?>
                                </td>
                                <td>
                                    <?php if ($c->avatar): ?><img src="<?php echo esc_url($c->avatar); ?>"
                                            style="width:24px;height:24px;border-radius:50%;vertical-align:middle;margin-right:8px;">
                                    <?php endif; ?>
                                    <strong>
                                        <?php echo esc_html($c->name); ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php echo esc_html($c->email); ?>
                                </td>
                                <td>
                                    <?php echo esc_html(ucfirst($c->provider)); ?>
                                </td>
                                <td>
                                    <?php echo $c->authorized_disclosure ? '<span style="color:green">Sim</span>' : '<span style="color:red">Não</span>'; ?>
                                </td>
                                <td>
                                    <?php echo esc_html($c->public_repos); ?>
                                </td>
                                <td>
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($c->created_at))); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function render_companies_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_companies';

        // Handle basic action forms (Make paying / Not paying)
        if (isset($_POST['action']) && isset($_POST['company_id']) && current_user_can('manage_options') && wp_verify_nonce($_POST['_wpnonce'], 'toggle_company_status')) {
            $comp_id = intval($_POST['company_id']);
            $is_paying = $_POST['action'] === 'make_paying' ? 1 : 0;
            $wpdb->update($table, ['is_paying' => $is_paying], ['id' => $comp_id]);
            echo '<div class="notice notice-success is-dismissible"><p>Status da empresa atualizado.</p></div>';
        }

        $companies = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC");
        ?>
        <div class="wrap">
            <h1>Empresas</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>WP User ID</th>
                        <th>Nome da Empresa</th>
                        <th>Status Pagante?</th>
                        <th>Data Cadastro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($companies)): ?>
                        <tr>
                            <td colspan="6">Nenhuma empresa encontrada. Obs: A criação de empresas será via Front-end/Dashboard de
                                Usuários WP.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($companies as $c): ?>
                            <tr>
                                <td>#
                                    <?php echo esc_html($c->id); ?>
                                </td>
                                <td>
                                    <?php echo esc_html($c->wp_user_id); ?>
                                </td>
                                <td><strong>
                                        <?php echo esc_html($c->company_name); ?>
                                    </strong></td>
                                <td>
                                    <?php echo $c->is_paying ? '<span style="color:green;font-weight:bold;">Sim (Premium)</span>' : '<span style="color:gray">Não</span>'; ?>
                                </td>
                                <td>
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($c->created_at))); ?>
                                </td>
                                <td>
                                    <form method="post" style="display:inline-block;">
                                        <?php wp_nonce_field('toggle_company_status'); ?>
                                        <input type="hidden" name="company_id" value="<?php echo esc_attr($c->id); ?>">
                                        <?php if ($c->is_paying): ?>
                                            <input type="hidden" name="action" value="remove_paying">
                                            <button type="submit" class="button button-small">Remover Premium</button>
                                        <?php else: ?>
                                            <input type="hidden" name="action" value="make_paying">
                                            <button type="submit" class="button button-small button-primary">Tornar Premium</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <hr style="margin:2em 0;">

            <h2>Adicionar Empresa Manualmente</h2>
            <p>Para testes, você pode vincular um Usuário WordPress existente como uma Empresa.</p>
            <?php
            if (isset($_POST['add_company']) && isset($_POST['wp_user_id']) && current_user_can('manage_options') && wp_verify_nonce($_POST['_wpnonce'], 'add_thriveo_company')) {
                $wpdb->insert($table, [
                    'wp_user_id' => intval($_POST['wp_user_id']),
                    'company_name' => sanitize_text_field($_POST['company_name']),
                    'is_paying' => intval($_POST['is_paying']),
                ]);
                echo '<meta http-equiv="refresh" content="0">';
            }
            ?>
            <form method="post" class="form-table">
                <?php wp_nonce_field('add_thriveo_company'); ?>
                <input type="hidden" name="add_company" value="1">
                <p>
                    <label>ID do Usuário WP (Admin ou Assinante):</label><br>
                    <input type="number" name="wp_user_id" required>
                </p>
                <p>
                    <label>Nome Fantasia (Empresa):</label><br>
                    <input type="text" name="company_name" required>
                </p>
                <p>
                    <label>Plano Premium (Pagante)?</label><br>
                    <select name="is_paying">
                        <option value="0">Não</option>
                        <option value="1">Sim</option>
                    </select>
                </p>
                <p><button type="submit" class="button button-primary">Adicionar</button></p>
            </form>
        </div>
        <?php
    }
}
