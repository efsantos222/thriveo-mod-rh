<?php
/**
 * OAuth Handler for GitHub and LinkedIn
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_OAuth_Handler
{

    public static function init()
    {
        // Public actions mapping to wp-admin/admin-post.php?action=...
        // Usamos admin-post.php ao invés de admin-ajax.php para redirecionamentos para evitar o retorno '0' do ajax
        add_action('admin_post_nopriv_thriveo_github_start', [__CLASS__, 'github_start']);
        add_action('admin_post_thriveo_github_start', [__CLASS__, 'github_start']);

        add_action('admin_post_nopriv_thriveo_github_callback', [__CLASS__, 'github_callback']);
        add_action('admin_post_thriveo_github_callback', [__CLASS__, 'github_callback']);

        add_action('admin_post_nopriv_thriveo_linkedin_start', [__CLASS__, 'linkedin_start']);
        add_action('admin_post_thriveo_linkedin_start', [__CLASS__, 'linkedin_start']);

        add_action('admin_post_nopriv_thriveo_linkedin_callback', [__CLASS__, 'linkedin_callback']);
        add_action('admin_post_thriveo_linkedin_callback', [__CLASS__, 'linkedin_callback']);

        // Protected route to get user info via JWT (these remain ajax)
        add_action('wp_ajax_nopriv_thriveo_get_me', [__CLASS__, 'get_me']);
        add_action('wp_ajax_thriveo_get_me', [__CLASS__, 'get_me']);

        add_action('wp_ajax_nopriv_thriveo_save_profile', [__CLASS__, 'save_profile']);
        add_action('wp_ajax_thriveo_save_profile', [__CLASS__, 'save_profile']);
    }

    private static function get_redirect_uri($provider)
    {
        return admin_url('admin-post.php?action=thriveo_' . $provider . '_callback');
    }

    private static function get_frontend_url($error = null, $token = null, $provider = null)
    {
        // Assuming elementor hero widget is on home page
        $url = home_url('/');

        $args = [];
        if ($error)
            $args['oauth_error'] = $error;
        if ($token) {
            $args['thriveo_token'] = $token;
            $args['thriveo_provider'] = $provider;
        }

        if (!empty($args)) {
            $url = add_query_arg($args, $url);
        }

        return $url . '#thriveo-dashboard';
    }

    // =========================================================================
    // GITHUB
    // =========================================================================

    public static function github_start()
    {
        if (!session_id())
            session_start();

        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_provider'] = 'github';

        $url = 'https://github.com/login/oauth/authorize?' . http_build_query([
            'client_id' => THRIVEO_GITHUB_CLIENT_ID,
            'redirect_uri' => self::get_redirect_uri('github'),
            'scope' => 'read:user user:email read:org',
            'state' => $state,
        ]);

        wp_redirect($url);
        exit;
    }

    public static function github_callback()
    {
        if (!session_id())
            session_start();

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $state = isset($_GET['state']) ? sanitize_text_field($_GET['state']) : '';

        if (empty($code) || $state !== ($_SESSION['oauth_state'] ?? '')) {
            wp_redirect(self::get_frontend_url('state_mismatch'));
            exit;
        }

        // Exchange code for token
        $args = [
            'body' => [
                'client_id' => THRIVEO_GITHUB_CLIENT_ID,
                'client_secret' => THRIVEO_GITHUB_CLIENT_SECRET,
                'code' => $code,
                'redirect_uri' => self::get_redirect_uri('github'),
            ],
            'headers' => ['Accept' => 'application/json'],
            'timeout' => 15,
        ];

        $response = wp_remote_post('https://github.com/login/oauth/access_token', $args);

        if (is_wp_error($response)) {
            wp_redirect(self::get_frontend_url('token_error'));
            exit;
        }

        $body = wp_remote_retrieve_body($response);
        $token_data = json_decode($body, true);

        if (empty($token_data['access_token'])) {
            wp_redirect(self::get_frontend_url('token_error'));
            exit;
        }

        $access_token = $token_data['access_token'];

        // Get user profile
        $profile_resp = wp_remote_get('https://api.github.com/user', [
            'headers' => [
                'Authorization' => 'token ' . $access_token,
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Thriveo-App/1.0',
            ],
            'timeout' => 15,
        ]);
        $profile = json_decode(wp_remote_retrieve_body($profile_resp), true);

        // Get emails
        $emails_resp = wp_remote_get('https://api.github.com/user/emails', [
            'headers' => [
                'Authorization' => 'token ' . $access_token,
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Thriveo-App/1.0',
            ],
            'timeout' => 15,
        ]);
        $emails = json_decode(wp_remote_retrieve_body($emails_resp), true);

        $primary_email = '';
        if (is_array($emails)) {
            foreach ($emails as $e) {
                if (!empty($e['primary']) && !empty($e['verified'])) {
                    $primary_email = sanitize_email($e['email']);
                    break;
                }
            }
        }

        // Orgs
        $orgs_resp = wp_remote_get('https://api.github.com/user/orgs', [
            'headers' => [
                'Authorization' => 'token ' . $access_token,
                'User-Agent' => 'Thriveo-App/1.0',
            ],
        ]);
        $orgs = json_decode(wp_remote_retrieve_body($orgs_resp), true);
        $org_names = [];
        if (is_array($orgs)) {
            foreach ($orgs as $org) {
                if (isset($org['login'])) {
                    $org_names[] = sanitize_text_field($org['login']);
                }
            }
        }

        // Repos (top 10)
        $repos_resp = wp_remote_get('https://api.github.com/user/repos?sort=stargazers_count&per_page=10', [
            'headers' => [
                'Authorization' => 'token ' . $access_token,
                'User-Agent' => 'Thriveo-App/1.0',
            ],
        ]);
        $repos = json_decode(wp_remote_retrieve_body($repos_resp), true);
        $top_repos = [];
        if (is_array($repos)) {
            foreach ($repos as $r) {
                $top_repos[] = [
                    'name' => sanitize_text_field($r['name'] ?? ''),
                    'description' => sanitize_text_field($r['description'] ?? ''),
                    'stars' => intval($r['stargazers_count'] ?? 0),
                    'language' => sanitize_text_field($r['language'] ?? ''),
                    'url' => sanitize_url($r['html_url'] ?? ''),
                ];
            }
        }

        $user_data = [
            'provider' => 'github',
            'provider_id' => strval($profile['id'] ?? ''),
            'name' => sanitize_text_field($profile['name'] ?? ($profile['login'] ?? '')),
            'email' => $primary_email ?: sanitize_email($profile['email'] ?? ''),
            'avatar' => sanitize_url($profile['avatar_url'] ?? ''),
            'username' => sanitize_text_field($profile['login'] ?? ''),
            'bio' => sanitize_textarea_field($profile['bio'] ?? ''),
            'location' => sanitize_text_field($profile['location'] ?? ''),
            'company' => sanitize_text_field($profile['company'] ?? ''),
            'blog' => sanitize_url($profile['blog'] ?? ''),
            'public_repos' => intval($profile['public_repos'] ?? 0),
            'followers' => intval($profile['followers'] ?? 0),
            'profile_url' => sanitize_url($profile['html_url'] ?? ''),
            'organizations' => implode(',', $org_names),
            'top_repos' => wp_json_encode($top_repos),
            'access_token' => $access_token,
        ];

        $user = self::upsert_user($user_data);
        $jwt = self::generate_jwt($user['id'], $user['email']);

        unset($_SESSION['oauth_state'], $_SESSION['oauth_provider']);

        wp_redirect(self::get_frontend_url(null, $jwt, 'github'));
        exit;
    }

    // =========================================================================
    // LINKEDIN
    // =========================================================================

    public static function linkedin_start()
    {
        if (!session_id())
            session_start();

        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_provider'] = 'linkedin';

        $url = 'https://www.linkedin.com/oauth/v2/authorization?' . http_build_query([
            'response_type' => 'code',
            'client_id' => THRIVEO_LINKEDIN_CLIENT_ID,
            'redirect_uri' => self::get_redirect_uri('linkedin'),
            'scope' => 'openid profile email',
            'state' => $state,
        ]);

        wp_redirect($url);
        exit;
    }

    public static function linkedin_callback()
    {
        if (!session_id())
            session_start();

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $state = isset($_GET['state']) ? sanitize_text_field($_GET['state']) : '';
        $error = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';

        if (!empty($error)) {
            wp_redirect(self::get_frontend_url('linkedin_denied'));
            exit;
        }

        if (empty($code) || $state !== ($_SESSION['oauth_state'] ?? '')) {
            wp_redirect(self::get_frontend_url('state_mismatch'));
            exit;
        }

        // Exchange code
        $args = [
            'body' => [
                'grant_type' => 'authorization_code',
                'code' => $code,
                'redirect_uri' => self::get_redirect_uri('linkedin'),
                'client_id' => THRIVEO_LINKEDIN_CLIENT_ID,
                'client_secret' => THRIVEO_LINKEDIN_CLIENT_SECRET,
            ],
            'timeout' => 15,
        ];

        $response = wp_remote_post('https://www.linkedin.com/oauth/v2/accessToken', $args);

        if (is_wp_error($response)) {
            wp_redirect(self::get_frontend_url('token_error'));
            exit;
        }

        $body = wp_remote_retrieve_body($response);
        $token_data = json_decode($body, true);

        if (empty($token_data['access_token'])) {
            wp_redirect(self::get_frontend_url('token_error'));
            exit;
        }

        $access_token = $token_data['access_token'];

        // Userinfo via OpenID
        $profile_resp = wp_remote_get('https://api.linkedin.com/v2/userinfo', [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
            ],
            'timeout' => 15,
        ]);
        $profile = json_decode(wp_remote_retrieve_body($profile_resp), true);

        $name = trim(sanitize_text_field($profile['given_name'] ?? '') . ' ' . sanitize_text_field($profile['family_name'] ?? ''));

        $user_data = [
            'provider' => 'linkedin',
            'provider_id' => sanitize_text_field($profile['sub'] ?? ''),
            'name' => $name,
            'email' => sanitize_email($profile['email'] ?? ''),
            'avatar' => sanitize_url($profile['picture'] ?? ''),
            'username' => '',
            'bio' => '',
            'location' => sanitize_text_field($profile['locale']['country'] ?? ''),
            'company' => '',
            'blog' => '',
            'public_repos' => 0,
            'followers' => 0,
            'profile_url' => 'https://linkedin.com',
            'organizations' => '',
            'top_repos' => wp_json_encode([]),
            'access_token' => $access_token,
        ];

        $user = self::upsert_user($user_data);
        $jwt = self::generate_jwt($user['id'], $user['email']);

        unset($_SESSION['oauth_state'], $_SESSION['oauth_provider']);

        wp_redirect(self::get_frontend_url(null, $jwt, 'linkedin'));
        exit;
    }

    // =========================================================================
    // ME (API)
    // =========================================================================

    public static function get_me()
    {
        $user = self::require_auth();

        // Remove sensitive data
        unset($user['access_token']);

        if (!empty($user['top_repos'])) {
            $user['top_repos'] = json_decode($user['top_repos'], true);
        }

        wp_send_json_success(['user' => $user]);
    }

    public static function save_profile()
    {
        $user = self::require_auth();
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_candidates';

        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : $user['name'];
        $headline = isset($_POST['headline']) ? sanitize_text_field($_POST['headline']) : $user['company'];
        $bio = isset($_POST['bio']) ? sanitize_textarea_field($_POST['bio']) : $user['bio'];
        $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : $user['location'];
        $company = isset($_POST['company']) ? sanitize_text_field($_POST['company']) : $user['company'];
        $years = isset($_POST['ai_experience_years']) ? intval($_POST['ai_experience_years']) : $user['ai_experience_years'];
        $skills = isset($_POST['ai_skills']) ? sanitize_text_field($_POST['ai_skills']) : $user['ai_skills'];

        // Handling checkboxes which might not be set in POST if unchecked
        $is_available = isset($_POST['is_available']) ? intval($_POST['is_available']) : 1;
        $is_public = isset($_POST['is_public']) ? intval($_POST['is_public']) : 1;

        $wpdb->update(
            $table,
            [
                'name' => $name,
                // Taking advantage of the existing 'company' column to store the headline
                'company' => $headline,
                'bio' => $bio,
                'location' => $location,
                'ai_experience_years' => $years,
                'ai_skills' => $skills,
                'authorized_disclosure' => $is_public
            ],
            ['id' => $user['id']]
        );

        wp_send_json_success(['message' => 'Perfil atualizado com sucesso.']);
    }

    // =========================================================================
    // DB Logic
    // =========================================================================

    private static function upsert_user($data)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_candidates';

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE provider = %s AND provider_id = %s",
            $data['provider'],
            $data['provider_id']
        ), ARRAY_A);

        if ($existing) {
            $wpdb->update(
                $table,
                [
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'avatar' => $data['avatar'],
                    'username' => $data['username'],
                    'bio' => $data['bio'],
                    'location' => $data['location'],
                    'company' => $data['company'],
                    'blog' => $data['blog'],
                    'public_repos' => $data['public_repos'],
                    'followers' => $data['followers'],
                    'profile_url' => $data['profile_url'],
                    'organizations' => $data['organizations'],
                    'top_repos' => $data['top_repos'],
                    'access_token' => $data['access_token'],
                ],
                ['id' => $existing['id']]
            );
            $user_id = $existing['id'];
        } else {
            $wpdb->insert(
                $table,
                [
                    'provider' => $data['provider'],
                    'provider_id' => $data['provider_id'],
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'avatar' => $data['avatar'],
                    'username' => $data['username'],
                    'bio' => $data['bio'],
                    'location' => $data['location'],
                    'company' => $data['company'],
                    'blog' => $data['blog'],
                    'public_repos' => $data['public_repos'],
                    'followers' => $data['followers'],
                    'profile_url' => $data['profile_url'],
                    'organizations' => $data['organizations'],
                    'top_repos' => $data['top_repos'],
                    'access_token' => $data['access_token'],
                ]
            );
            $user_id = $wpdb->insert_id;
        }

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $user_id), ARRAY_A);
    }

    // =========================================================================
    // JWT Logic
    // =========================================================================

    private static function generate_jwt($user_id, $email)
    {
        $header = self::base64url_encode(wp_json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload = self::base64url_encode(wp_json_encode([
            'sub' => $user_id,
            'email' => $email,
            'iat' => time(),
            'exp' => time() + (7 * 24 * 3600),
        ]));
        $sig = self::base64url_encode(hash_hmac('sha256', "$header.$payload", THRIVEO_JWT_SECRET, true));
        return "$header.$payload.$sig";
    }

    private static function verify_jwt($token)
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3)
            return null;

        list($header, $payload, $sig) = $parts;
        $expected = self::base64url_encode(hash_hmac('sha256', "$header.$payload", THRIVEO_JWT_SECRET, true));

        if (!hash_equals($expected, $sig))
            return null;

        $data = json_decode(self::base64url_decode($payload), true);
        if (empty($data['exp']) || $data['exp'] < time())
            return null;

        return $data;
    }

    private static function require_auth()
    {
        $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (function_exists('apache_request_headers') && empty($auth_header)) {
            $headers = apache_request_headers();
            $auth_header = $headers['Authorization'] ?? '';
        }

        $token = str_replace('Bearer ', '', $auth_header);

        if (empty($token)) {
            wp_send_json_error('Token ausente', 401);
        }

        $payload = self::verify_jwt($token);
        if (!$payload) {
            wp_send_json_error('Token inválido ou expirado', 401);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_candidates';
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $payload['sub']), ARRAY_A);

        if (!$user) {
            wp_send_json_error('Usuário não encontrado', 404);
        }

        return $user;
    }

    private static function base64url_encode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function base64url_decode($data)
    {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
    }
}
