<?php
/**
 * Elementor Hero Widget.
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Thriveo_AI_Jobs_Hero_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'thriveo_ai_hero';
    }

    public function get_title()
    {
        return esc_html__('Thriveo AI Hero', 'thriveo-ai-jobs');
    }

    public function get_icon()
    {
        return 'eicon-code';
    }

    public function get_categories()
    {
        return ['general'];
    }

    public function get_keywords()
    {
        return ['hero', 'oauth', 'login', 'ai', 'thriveo'];
    }

    public function get_script_depends()
    {
        return ['thriveo-hero-widget-js'];
    }

    public function get_style_depends()
    {
        return ['thriveo-hero-widget-css'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'thriveo-ai-jobs'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'headline',
            [
                'label' => esc_html__('Headline', 'thriveo-ai-jobs'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('O talento de IA que sua empresa precisa encontrar', 'thriveo-ai-jobs'),
            ]
        );

        $this->add_control(
            'subheadline',
            [
                'label' => esc_html__('Subheadline', 'thriveo-ai-jobs'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Plataforma exclusiva de cadastro, validação e recrutamento de profissionais especializados em Inteligência Artificial no Brasil.', 'thriveo-ai-jobs'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Obter as URLs de autenticação do WordPress (admin-post para lidar com os redirects propriamente)
        $github_url = admin_url('admin-post.php?action=thriveo_github_start');
        $linkedin_url = admin_url('admin-post.php?action=thriveo_linkedin_start');
        ?>

        <div class="thriveo-hero-wrapper">
            <!-- LEFT PANEL -->
            <div class="th-left">
                <div class="th-left-bg"></div>
                <div class="th-grid-lines"></div>
                <div class="th-orb th-orb1"></div>
                <div class="th-orb th-orb2"></div>

                <div class="th-left-content">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="th-logo">
                        <div class="th-logo-mark">T</div>
                        <span class="th-logo-name">Thriveo</span>
                    </a>

                    <h1 class="th-left-headline">
                        <?php echo wp_kses_post(str_replace('precisa encontrar', '<span class="th-hi">precisa encontrar</span>', $settings['headline'])); ?>
                    </h1>

                    <p class="th-left-sub">
                        <?php echo wp_kses_post($settings['subheadline']); ?>
                    </p>

                    <div class="th-stats-row">
                        <div class="th-stat">
                            <span class="th-stat-n">2.400+</span>
                            <span class="th-stat-l">Talentos IA</span>
                        </div>
                        <div class="th-stat">
                            <span class="th-stat-n">180+</span>
                            <span class="th-stat-l">Empresas</span>
                        </div>
                        <div class="th-stat">
                            <span class="th-stat-n">94%</span>
                            <span class="th-stat-l">Match rate</span>
                        </div>
                    </div>
                </div>

                <div class="th-left-footer">
                    <div id="th-left-dashboard-links" style="display:none; margin-bottom: 24px;">
                        <div style="font-size: 13px; color: var(--muted2); margin-bottom: 12px;">Acesso Rápido:</div>
                        <div class="th-left-links-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                            <button class="th-btn-secondary" style="margin-top:0;"
                                onclick="window.location.href='<?php echo esc_url(home_url('/?thriveo_dashboard=1')); ?>'">Completar
                                Perfil</button>
                            <button class="th-btn-secondary" style="margin-top:0;"
                                onclick="window.location.href='<?php echo esc_url(home_url('/?thriveo_talentos=1')); ?>'">Banco
                                de Talentos</button>
                            <button class="th-btn-secondary" style="margin-top:0;"
                                onclick="window.location.href='<?php echo esc_url(home_url('/?thriveo_empresa_vagas=1')); ?>'">Gestão
                                de Vagas</button>
                            <button class="th-btn-secondary" style="margin-top:0;"
                                onclick="window.location.href='<?php echo esc_url(home_url('/?thriveo_empresa_vagas=1&nova_vaga=1')); ?>'">Publicar
                                Vaga</button>
                            <button class="th-btn-secondary" style="margin-top:0;"
                                onclick="alert('Treinamentos IA em breve')">Treinamentos IA</button>
                            <button class="th-btn-logout" id="th-btnLogout-left" style="margin-top:0;">Sair da conta</button>
                        </div>
                    </div>
                    © <?php echo date('Y'); ?> Thriveo · todos os direitos reservados
                </div>
            </div>

            <!-- RIGHT PANEL -->
            <div class="th-right" id="thriveo-dashboard">

                <!-- LOGIN BOX -->
                <div class="th-form-box" id="th-loginBox">
                    <div class="th-form-tag">// acesso à plataforma</div>
                    <h2 class="th-form-title">Entre ou cadastre-se</h2>
                    <p class="th-form-desc">Use sua conta GitHub ou LinkedIn. Nenhuma senha necessária.</p>

                    <div class="th-alert" id="th-errorAlert"></div>

                    <!-- GitHub -->
                    <a href="<?php echo esc_url($github_url); ?>" class="th-oauth-btn th-github" id="th-btnGithub">
                        <div class="th-oauth-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path
                                    d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z" />
                            </svg>
                        </div>
                        <span class="th-oauth-label">Continuar com GitHub</span>
                        <span class="th-oauth-arrow">→</span>
                    </a>

                    <div class="th-or-divider">ou</div>

                    <!-- LinkedIn -->
                    <a href="<?php echo esc_url($linkedin_url); ?>" class="th-oauth-btn th-linkedin" id="th-btnLinkedin">
                        <div class="th-oauth-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#0A66C2">
                                <path
                                    d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                            </svg>
                        </div>
                        <span class="th-oauth-label">Continuar com LinkedIn</span>
                        <span class="th-oauth-arrow">→</span>
                    </a>

                    <div class="th-features">
                        <div class="th-feat">
                            <div class="th-feat-dot"></div><span>Perfil público de especialista em IA</span>
                        </div>
                        <div class="th-feat">
                            <div class="th-feat-dot"></div><span>Certificação Thriveo inclusa</span>
                        </div>
                        <div class="th-feat">
                            <div class="th-feat-dot"></div><span>Visibilidade para 180+ empresas</span>
                        </div>
                    </div>

                    <div class="th-form-footer">
                        Ao continuar você concorda com os
                        <a href="/termos">Termos de Uso</a> e a
                        <a href="/privacidade">Política de Privacidade</a> (LGPD).
                    </div>
                </div>

                <!-- DASHBOARD PÓS-LOGIN -->
                <div id="th-dashboard" style="display:none;">
                    <div class="th-form-tag">// bem-vindo ao thriveo</div>
                    <h2 class="th-form-title" style="margin-bottom:24px">Seu perfil</h2>

                    <div class="th-profile-card" id="th-profileCard">
                        <!-- preenchido via JS -->
                    </div>

                    <div id="th-reposSection" style="display:none">
                        <div class="th-repos-title">Top Repositórios</div>
                        <div id="th-reposList"></div>
                    </div>
                </div>

            </div>
        </div>

        <?php
    }
}
