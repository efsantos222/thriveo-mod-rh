<?php
/**
 * Database Schema creation
 */

if (!defined('ABSPATH')) {
	exit;
}

class Thriveo_AI_Jobs_DB_Schema
{

	public static function create_tables()
	{
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

		// 1. Candidates Table (Updated to match prompt requirements if needed, but keeping core OAuth columns)
		$table_candidates = $wpdb->prefix . 'thriveo_ai_candidates';
		$sql_candidates = "CREATE TABLE $table_candidates (
			id INT UNSIGNED NOT NULL AUTO_INCREMENT,
			provider VARCHAR(20) NOT NULL,
			provider_id VARCHAR(100) NOT NULL,
			name VARCHAR(200) DEFAULT '' NOT NULL,
			email VARCHAR(200) DEFAULT '' NOT NULL,
			avatar VARCHAR(500) DEFAULT '',
			username VARCHAR(100) DEFAULT '',
			bio TEXT,
			location VARCHAR(200) DEFAULT '',
			company VARCHAR(200) DEFAULT '',
			blog VARCHAR(500) DEFAULT '',
			public_repos INT DEFAULT 0,
			followers INT DEFAULT 0,
			profile_url VARCHAR(500) DEFAULT '',
			organizations TEXT,
			top_repos LONGTEXT,
			access_token TEXT,
			ai_experience_years INT DEFAULT 0,
			ai_skills TEXT,
			authorized_disclosure TINYINT(1) DEFAULT 0,
            area_atuacao VARCHAR(50) DEFAULT '',
            nivel_experiencia VARCHAR(30) DEFAULT '',
            disponibilidade VARCHAR(50) DEFAULT '',
            cargo_atual VARCHAR(255) DEFAULT '',
            cidade VARCHAR(100) DEFAULT '',
            estado VARCHAR(2) DEFAULT '',
            ativo TINYINT(1) DEFAULT 1,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_provider (provider, provider_id)
		) $charset_collate;";

		// 2. Companies Table (Thriveo AI Companies)
		$table_companies = $wpdb->prefix . 'thriveo_ai_companies';
		$sql_companies = "CREATE TABLE $table_companies (
			id INT UNSIGNED NOT NULL AUTO_INCREMENT,
			wp_user_id BIGINT(20) UNSIGNED NOT NULL,
			company_name VARCHAR(200) DEFAULT '' NOT NULL,
            logo_url VARCHAR(500) DEFAULT '',
            website VARCHAR(255) DEFAULT '',
            company_size VARCHAR(50) DEFAULT '',
            segment VARCHAR(100) DEFAULT '',
			is_paying TINYINT(1) DEFAULT 0,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY wp_user_id (wp_user_id)
		) $charset_collate;";

		// 3. New Vagas Table (Replacing/Updating thriveo_ai_jobs)
		$table_vagas = $wpdb->prefix . 'thriveo_vagas';
		$sql_vagas = "CREATE TABLE $table_vagas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            titulo VARCHAR(200) NOT NULL,
            slug VARCHAR(220) NOT NULL,
            area_atuacao VARCHAR(50) NOT NULL,
            nivel VARCHAR(30) NOT NULL,
            regime VARCHAR(30) NOT NULL,
            modalidade VARCHAR(30) NOT NULL,
            cidade VARCHAR(100),
            estado VARCHAR(2),
            descricao LONGTEXT NOT NULL,
            responsabilidades TEXT,
            requisitos_obrigatorios TEXT NOT NULL,
            requisitos_desejaveis TEXT,
            stack_json TEXT, -- dbDelta might struggle with JSON type, using TEXT for safety
            salario_min DECIMAL(10,2),
            salario_max DECIMAL(10,2),
            salario_a_combinar TINYINT(1) DEFAULT 0,
            beneficios_json TEXT,
            etapas_processo_json TEXT,
            prazo_candidatura DATE,
            como_candidatar VARCHAR(20) DEFAULT 'sistema',
            link_externo VARCHAR(500),
            email_candidatura VARCHAR(200),
            status VARCHAR(20) DEFAULT 'rascunho',
            tipo_publicacao VARCHAR(20) DEFAULT 'gratuita',
            pagamento_id VARCHAR(100),
            pagamento_status VARCHAR(30),
            visualizacoes INT DEFAULT 0,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expira_em DATETIME,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_slug (slug),
            KEY idx_empresa (empresa_id),
            KEY idx_status (status),
            KEY idx_area (area_atuacao)
        ) $charset_collate;";

		// 4. Candidaturas Table
		$table_candidaturas = $wpdb->prefix . 'thriveo_candidaturas';
		$sql_candidaturas = "CREATE TABLE $table_candidaturas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            vaga_id INT UNSIGNED NOT NULL,
            candidato_id INT UNSIGNED NOT NULL,
            status VARCHAR(30) DEFAULT 'recebida',
            mensagem_candidato TEXT,
            anotacao_empresa TEXT,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_candidatura (vaga_id, candidato_id)
        ) $charset_collate;";

		// 5. Cotas Mensais Table
		$table_cotas = $wpdb->prefix . 'thriveo_cotas_mensais';
		$sql_cotas = "CREATE TABLE $table_cotas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            mes_ano VARCHAR(7) NOT NULL,
            vagas_gratuitas_usadas INT DEFAULT 0,
            vagas_pagas INT DEFAULT 0,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_empresa_mes (empresa_id, mes_ano)
        ) $charset_collate;";

		// 6. Anotacoes Candidatos Table
		$table_anotacoes = $wpdb->prefix . 'thriveo_anotacoes_candidatos';
		$sql_anotacoes = "CREATE TABLE $table_anotacoes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            candidato_id INT UNSIGNED NOT NULL,
            anotacao TEXT NOT NULL,
            autor_nome VARCHAR(100),
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_empresa_candidato (empresa_id, candidato_id)
        ) $charset_collate;";

		dbDelta($sql_candidates);
		dbDelta($sql_companies);
		dbDelta($sql_vagas);
		dbDelta($sql_candidaturas);
		dbDelta($sql_cotas);
		dbDelta($sql_anotacoes);
	}
}
