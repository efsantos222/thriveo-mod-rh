<?php
/**
 * Dashboard Handler for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Dashboard
{
    public static function init()
    {
        // Intercept template redirect to load our custom dashboard PHP file
        add_action('template_redirect', [__CLASS__, 'load_dashboard_template']);
    }

    public static function load_dashboard_template()
    {
        // 1. Personal Candidate Dashboard (Profile)
        if (isset($_GET['thriveo_dashboard']) && $_GET['thriveo_dashboard'] == '1') {
            self::render_template('dashboard.php');
        }

        // 2. Talent Bank (Admin / Employer view of candidates)
        if (isset($_GET['thriveo_talentos']) && $_GET['thriveo_talentos'] == '1') {
            self::render_template('talentos.php');
        }

        // 3. Employer Job Management
        if (isset($_GET['thriveo_empresa_vagas']) && $_GET['thriveo_empresa_vagas'] == '1') {
            self::render_template('empresa-vagas.php');
        }

        // 4. Public Job Board
        if (isset($_GET['thriveo_vagas']) && $_GET['thriveo_vagas'] == '1') {
            self::render_template('public-vagas.php');
        }
    }

    private static function render_template($file)
    {
        $template_path = THRIVEO_AI_JOBS_DIR . 'templates/' . $file;
        if (file_exists($template_path)) {
            status_header(200);
            include($template_path);
            exit;
        }
    }
}
