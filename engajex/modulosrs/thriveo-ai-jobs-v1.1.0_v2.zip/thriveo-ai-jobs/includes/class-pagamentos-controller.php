<?php
/**
 * Controller for Payments (Mercado Pago / PagSeguro)
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Pagamentos_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_create_payment', [__CLASS__, 'create_payment']);
        add_action('wp_ajax_nopriv_thriveo_payment_webhook', [__CLASS__, 'webhook']);
    }

    public static function create_vaga_payment()
    {
        // Mocking Mercado Pago payment creation
        $vaga_id = isset($_POST['vaga_id']) ? intval($_POST['vaga_id']) : 0;

        // Em um cenário real, aqui integraríamos com a SDK do MP
        $payment_url = "https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=MOCK_123";

        wp_send_json_success([
            'payment_url' => $payment_url,
            'message' => 'Redirecionando para o pagamento...'
        ]);
    }

    public static function webhook()
    {
        // Webhook handler from Payment Gateway
        // Updates vaga status to 'ativa' and sends email
    }
}
