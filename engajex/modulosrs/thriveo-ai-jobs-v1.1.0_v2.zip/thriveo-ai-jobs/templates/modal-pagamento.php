<?php
/**
 * Modal de Pagamento Condicional
 */
if (!defined('ABSPATH'))
    exit;
?>
<div id="modal-pagamento"
    style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:2000; align-items:center; justify-content:center; backdrop-filter:blur(10px);">
    <div
        style="background:white; padding:40px; border-radius:30px; max-width:500px; width:90%; text-align:center; box-shadow:0 20px 40px rgba(0,0,0,0.2);">
        <div
            style="width:80px; height:80px; background:#f0fdf9; color:#00c896; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; font-size:2rem;">
            <i class="fas fa-credit-card"></i>
        </div>
        <h2 style="color:#1a2e4a; margin-bottom:15px;">Publicação Pró</h2>
        <p style="color:#64748b; margin-bottom:30px;">Sua cota gratuita de 1 vaga/mês foi atingida. Para manter esta
            vaga ativa e com destaque, o valor é de:</p>

        <div style="font-size:3rem; font-weight:800; color:#1a2e4a; margin-bottom:10px;">R$ 99,00</div>
        <p
            style="color:#00c896; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; margin-bottom:30px;">
            Pagamento Único • 30 Dias Ativa</p>

        <ul style="text-align:left; list-style:none; margin-bottom:40px; color:#334e68; font-size:0.9rem;">
            <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:#00c896"></i> Destaque
                "PATROCINADA" no topo</li>
            <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:#00c896"></i> Acesso total às
                candidaturas</li>
            <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:#00c896"></i> Busca ativa no
                banco de talentos</li>
        </ul>

        <button onclick="window.location.href='#'"
            style="width:100%; background:#00c896; color:white; border:none; padding:18px; border-radius:15px; font-weight:700; font-size:1.1rem; cursor:pointer; transition:0.3s; margin-bottom:15px;">
            Pagar com Mercado Pago
        </button>
        <button onclick="document.getElementById('modal-pagamento').style.display='none'"
            style="background:none; border:none; color:#64748b; cursor:pointer; font-weight:500;">
            Cancelar e Salvar rascunho
        </button>
    </div>
</div>