<?php

$dir = __DIR__ . '/templates/';
$files = ['talentos.php', 'empresa-vagas.php', 'matching.php', 'entrevista.php', 'certificacoes.php'];

foreach ($files as $f) {
    if (!file_exists($dir . $f)) continue;

    $content = file_get_contents($dir . $f);

    // 1. Inject the CSS link before </head>
    if (strpos($content, 'thriveo-sidebar-layout.css') === false) {
        $content = str_replace('</head>', "    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\">\n    <link rel=\"stylesheet\" href=\"<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css\">\n</head>", $content);
    }
    
    // 2. Remove ONLY specific CSS blocks if needed (optional, or just leave them. The new classes won't conflict with their old tags, we'll just rename their HTML tags)
    
    $sidebar_html = <<<'HTML'
<aside class="app-sidebar">
    <div class="app-logo">
        <a href="<?php echo home_url(); ?>">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
        </a>
    </div>
    <ul class="nav-menu">
        <li><a href="?thriveo_dashboard=1" class="%%MENU_PERFIL%%"><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
        <li><a href="?thriveo_certificacoes=1" class="%%MENU_CERTIFICACOES%%"><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
        <li><a href="?thriveo_vagas=1" class="%%MENU_VAGAS%%"><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
        <li><a href="?thriveo_talentos=1" class="%%MENU_TALENTOS%%"><i class="fas fa-users"></i> Banco de Talentos</a></li>
        <li><a href="?thriveo_empresa_vagas=1" class="%%MENU_GESTAO%%"><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
        <li><a href="?thriveo_matching=1" class="%%MENU_MATCHING%%"><i class="fas fa-bolt"></i> Matching IA</a></li>
        <li><a href="?thriveo_entrevista=1" class="%%MENU_ENTREVISTA%%"><i class="fas fa-comments"></i> Entrevista IA</a></li>
        <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
        <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
    </ul>
    <div class="sidebar-user-info">
        <div class="sidebar-user-name">Usuário Ativo</div>
        <div class="sidebar-user-status">Sessão Segura</div>
    </div>
HTML;

    // Remove the old aside logic or replace carefully.
    if ($f === 'talentos.php') {
        // talentos.php has <aside> \n <div class="logo"> ... </ul> ... filter-section
        $pattern = '/<aside>.*?<ul class="nav-menu">.*?<\/ul>/is';
        $content = preg_replace($pattern, $sidebar_html, $content, 1);
        $content = str_replace('%%MENU_TALENTOS%%', 'active', $content);
    } elseif ($f === 'empresa-vagas.php') {
        $pattern = '/<aside>.*?<\/ul>\s*<\/aside>/is';
        $content = preg_replace($pattern, $sidebar_html . "\n</aside>", $content, 1);
        $content = str_replace('%%MENU_GESTAO%%', 'active', $content);
    } elseif ($f === 'certificacoes.php') {
        $pattern = '/<aside>.*?<\/aside>/is';
        $content = preg_replace($pattern, $sidebar_html . "\n</aside>", $content, 1);
        $content = str_replace('%%MENU_CERTIFICACOES%%', 'active', $content);
    } elseif ($f === 'matching.php' || $f === 'entrevista.php') {
        $pattern = '/<aside class="sidebar">.*?<\/nav>\s*<\/aside>/is';
        $content = preg_replace($pattern, $sidebar_html . "\n</aside>", $content, 1);
        if ($f === 'matching.php') $content = str_replace('%%MENU_MATCHING%%', 'active', $content);
        if ($f === 'entrevista.php') $content = str_replace('%%MENU_ENTREVISTA%%', 'active', $content);
    }

    // Clean any remaining unused tags
    $content = preg_replace('/%%MENU_[A-Z_]+%%/', '', $content);

    // Apply the universal container and main classes
    $content = str_replace('<div class="app-container">', '<div class="app-container">', $content);
    $content = str_replace('<div class="app-container-matching">', '<div class="app-container">', $content);
    $content = str_replace('<div class="app-container-entrevista">', '<div class="app-container">', $content);
    
    $content = str_replace('<main>', '<main class="app-main">', $content);
    $content = str_replace('<main class="main-content">', '<main class="app-main">', $content);

    // Remove overlapping background and text colors inline that ruin the sidebar
    // We'll just aggressively remove the root definitions of primary and text from individual pages to let sidebar css take over.
    $content = preg_replace('/:root\s*{[^}]*}/is', '', $content);
    
    // Convert <body> styles over to generic
    $content = preg_replace('/body\s*{[^}]*}/is', '', $content);

    file_put_contents($dir . $f, $content);
}

echo "Done\n";
