<?php
require_once dirname(dirname(dirname(dirname(__DIR__)))) . '/wp-load.php';
global $wpdb;
$vagas = $wpdb->get_results("SELECT id, empresa_id, titulo, status, tipo_publicacao FROM {$wpdb->prefix}thriveo_vagas", ARRAY_A);
print_r($vagas);
