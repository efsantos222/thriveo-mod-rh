<?php
/**
 * Database Schema creation
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_DB_Schema
{

    public static function create_tables()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // 1. Candidates Table (Updated to match prompt requirements if needed, but keeping core OAuth columns)
        $table_candidates = $wpdb->prefix . 'thriveo_ai_candidates';
        $sql_candidates = "CREATE TABLE $table_candidates (
			id INT UNSIGNED NOT NULL AUTO_INCREMENT,
			provider VARCHAR(20) NOT NULL,
			provider_id VARCHAR(100) NOT NULL,
			name VARCHAR(200) DEFAULT '' NOT NULL,
			email VARCHAR(200) DEFAULT '' NOT NULL,
			avatar VARCHAR(500) DEFAULT '',
			username VARCHAR(100) DEFAULT '',
			bio TEXT,
			location VARCHAR(200) DEFAULT '',
			company VARCHAR(200) DEFAULT '',
			blog VARCHAR(500) DEFAULT '',
			public_repos INT DEFAULT 0,
			followers INT DEFAULT 0,
			profile_url VARCHAR(500) DEFAULT '',
			organizations TEXT,
			top_repos LONGTEXT,
			access_token TEXT,
			ai_experience_years INT DEFAULT 0,
			ai_skills TEXT,
			authorized_disclosure TINYINT(1) DEFAULT 0,
            area_atuacao VARCHAR(50) DEFAULT '',
            nivel_experiencia VARCHAR(30) DEFAULT '',
            disponibilidade VARCHAR(50) DEFAULT '',
            cargo_atual VARCHAR(255) DEFAULT '',
            cidade VARCHAR(100) DEFAULT '',
            estado VARCHAR(2) DEFAULT '',
            ativo TINYINT(1) DEFAULT 1,
            score_perfil DECIMAL(5,2) DEFAULT 0,
            selo_d1 TINYINT(1) DEFAULT 0,
            selo_d2 TINYINT(1) DEFAULT 0,
            selo_d3 TINYINT(1) DEFAULT 0,
            selo_d4 TINYINT(1) DEFAULT 0,
            selo_elite TINYINT(1) DEFAULT 0,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_provider (provider, provider_id)
		) $charset_collate;";

        // 2. Companies Table (Thriveo AI Companies)
        $table_companies = $wpdb->prefix . 'thriveo_ai_companies';
        $sql_companies = "CREATE TABLE $table_companies (
			id INT UNSIGNED NOT NULL AUTO_INCREMENT,
			wp_user_id BIGINT(20) UNSIGNED NOT NULL,
			company_name VARCHAR(200) DEFAULT '' NOT NULL,
            logo_url VARCHAR(500) DEFAULT '',
            website VARCHAR(255) DEFAULT '',
            company_size VARCHAR(50) DEFAULT '',
            segment VARCHAR(100) DEFAULT '',
			is_paying TINYINT(1) DEFAULT 0,
            razao_social VARCHAR(200) DEFAULT '',
            cnpj VARCHAR(20) DEFAULT '',
            endereco VARCHAR(255) DEFAULT '',
            bairro VARCHAR(100) DEFAULT '',
            cidade VARCHAR(100) DEFAULT '',
            estado VARCHAR(2) DEFAULT '',
            cep VARCHAR(10) DEFAULT '',
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY wp_user_id (wp_user_id)
		) $charset_collate;";

        // 3. New Vagas Table (Replacing/Updating thriveo_ai_jobs)
        $table_vagas = $wpdb->prefix . 'thriveo_vagas';
        $sql_vagas = "CREATE TABLE $table_vagas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            titulo VARCHAR(200) NOT NULL,
            slug VARCHAR(220) NOT NULL,
            area_atuacao VARCHAR(50) NOT NULL,
            nivel VARCHAR(30) NOT NULL,
            regime VARCHAR(30) NOT NULL,
            modalidade VARCHAR(30) NOT NULL,
            cidade VARCHAR(100),
            estado VARCHAR(2),
            descricao LONGTEXT NOT NULL,
            responsabilidades TEXT,
            requisitos_obrigatorios TEXT NOT NULL,
            requisitos_desejaveis TEXT,
            stack_json TEXT, -- dbDelta might struggle with JSON type, using TEXT for safety
            salario_min DECIMAL(10,2),
            salario_max DECIMAL(10,2),
            salario_a_combinar TINYINT(1) DEFAULT 0,
            beneficios_json TEXT,
            etapas_processo_json TEXT,
            prazo_candidatura DATE,
            como_candidatar VARCHAR(20) DEFAULT 'sistema',
            link_externo VARCHAR(500),
            email_candidatura VARCHAR(200),
            status VARCHAR(20) DEFAULT 'rascunho',
            tipo_publicacao VARCHAR(20) DEFAULT 'gratuita',
            pagamento_id VARCHAR(100),
            pagamento_status VARCHAR(30),
            visualizacoes INT DEFAULT 0,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expira_em DATETIME,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_slug (slug),
            KEY idx_empresa (empresa_id),
            KEY idx_status (status),
            KEY idx_area (area_atuacao)
        ) $charset_collate;";

        // 4. Candidaturas Table
        $table_candidaturas = $wpdb->prefix . 'thriveo_candidaturas';
        $sql_candidaturas = "CREATE TABLE $table_candidaturas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            vaga_id INT UNSIGNED NOT NULL,
            candidato_id INT UNSIGNED NOT NULL,
            status VARCHAR(30) DEFAULT 'recebida',
            mensagem_candidato TEXT,
            anotacao_empresa TEXT,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_candidatura (vaga_id, candidato_id)
        ) $charset_collate;";

        // 5. Cotas Mensais Table
        $table_cotas = $wpdb->prefix . 'thriveo_cotas_mensais';
        $sql_cotas = "CREATE TABLE $table_cotas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            mes_ano VARCHAR(7) NOT NULL,
            vagas_gratuitas_usadas INT DEFAULT 0,
            vagas_pagas INT DEFAULT 0,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_empresa_mes (empresa_id, mes_ano)
        ) $charset_collate;";

        // 6. Anotacoes Candidatos Table
        $table_anotacoes = $wpdb->prefix . 'thriveo_anotacoes_candidatos';
        $sql_anotacoes = "CREATE TABLE $table_anotacoes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            candidato_id INT UNSIGNED NOT NULL,
            anotacao TEXT NOT NULL,
            autor_nome VARCHAR(100),
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_empresa_candidato (empresa_id, candidato_id)
        ) $charset_collate;";

        dbDelta($sql_candidates);
        dbDelta($sql_companies);
        dbDelta($sql_vagas);
        dbDelta($sql_candidaturas);
        dbDelta($sql_cotas);
        dbDelta($sql_anotacoes);

        // 7. Certificacoes Table
        $table_cert = $wpdb->prefix . 'thriveo_certificacoes';
        $sql_cert = "CREATE TABLE $table_cert (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            candidato_id INT UNSIGNED NOT NULL,
            tipo VARCHAR(20) NOT NULL, -- D1, D2, D3, D4, ELITE
            subtipo VARCHAR(100),
            score DECIMAL(5,2),
            status VARCHAR(20) DEFAULT 'ativo',
            codigo_verificacao VARCHAR(36) NOT NULL,
            pdf_path VARCHAR(500),
            concedido_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            expira_em DATETIME,
            metadata_json TEXT,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_codigo (codigo_verificacao),
            KEY idx_candidato (candidato_id)
        ) $charset_collate;";

        // 8. Questoes Tecnicas Table
        $table_questoes = $wpdb->prefix . 'thriveo_questoes_tecnicas';
        $sql_questoes = "CREATE TABLE $table_questoes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            trilha VARCHAR(50) NOT NULL,
            nivel VARCHAR(20) NOT NULL,
            topico VARCHAR(100) NOT NULL,
            tipo VARCHAR(30) NOT NULL,
            enunciado TEXT NOT NULL,
            codigo_base TEXT,
            alternativas_json TEXT NOT NULL,
            resposta_correta CHAR(1) NOT NULL,
            explicacao TEXT NOT NULL,
            dificuldade TINYINT NOT NULL,
            gerada_por_ia TINYINT(1) DEFAULT 1,
            ativa TINYINT(1) DEFAULT 1,
            vezes_usada INT DEFAULT 0,
            taxa_acerto DECIMAL(5,2),
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_trilha_nivel (trilha, nivel)
        ) $charset_collate;";

        // 9. Sessoes Teste Table
        $table_sessoes = $wpdb->prefix . 'thriveo_sessoes_teste';
        $sql_sessoes = "CREATE TABLE $table_sessoes (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            candidato_id INT UNSIGNED NOT NULL,
            trilha VARCHAR(50) NOT NULL,
            nivel VARCHAR(20) NOT NULL,
            status VARCHAR(30) DEFAULT 'iniciada',
            questoes_json TEXT,
            respostas_json TEXT,
            score_obtido DECIMAL(5,2),
            aprovado TINYINT(1),
            tempo_inicio DATETIME,
            tempo_fim DATETIME,
            tempo_limite_min INT DEFAULT 30,
            trocas_de_aba INT DEFAULT 0,
            ip_candidato VARCHAR(45),
            PRIMARY KEY  (id),
            KEY idx_candidato (candidato_id),
            KEY idx_trilha (trilha, nivel)
        ) $charset_collate;";

        // 10. Avaliacoes Softskills Table
        $table_soft = $wpdb->prefix . 'thriveo_avaliacoes_softskills';
        $sql_soft = "CREATE TABLE $table_soft (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            candidato_id INT UNSIGNED NOT NULL,
            tipo VARCHAR(30) NOT NULL, -- DISC, IE, FIT_CULTURAL, REMOTE_READY
            status VARCHAR(20) DEFAULT 'iniciada',
            respostas_json TEXT,
            resultado_json TEXT,
            perfil_predominante VARCHAR(50),
            score_geral DECIMAL(5,2),
            concluido_em DATETIME,
            PRIMARY KEY  (id),
            KEY idx_candidato_tipo (candidato_id, tipo)
        ) $charset_collate;";

        // 11. Referencias Profissionais Table
        $table_refs = $wpdb->prefix . 'thriveo_referencias_profissionais';
        $sql_refs = "CREATE TABLE $table_refs (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            candidato_id INT UNSIGNED NOT NULL,
            nome_referente VARCHAR(150) NOT NULL,
            cargo_referente VARCHAR(100),
            empresa_referente VARCHAR(150),
            email_referente VARCHAR(200) NOT NULL,
            tipo_relacao VARCHAR(30) NOT NULL,
            periodo_inicio VARCHAR(7),
            periodo_fim VARCHAR(7),
            token_resposta VARCHAR(64) NOT NULL,
            token_expira_em DATETIME,
            status VARCHAR(20) DEFAULT 'enviado',
            scores_json TEXT,
            recomendaria VARCHAR(20),
            comentario TEXT,
            ip_referente VARCHAR(45),
            respondido_em DATETIME,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_token (token_resposta),
            KEY idx_candidato (candidato_id)
        ) $charset_collate;";

        // 12. Log Verificacoes Table
        $table_log_verif = $wpdb->prefix . 'thriveo_log_verificacoes';
        $sql_log_verif = "CREATE TABLE $table_log_verif (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            codigo_verificacao VARCHAR(36) NOT NULL,
            ip_consultor VARCHAR(45),
            user_agent TEXT,
            consultado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 13. Trilhas IA Table
        $table_trilhas = $wpdb->prefix . 'thriveo_trilhas';
        $sql_trilhas = "CREATE TABLE $table_trilhas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            titulo VARCHAR(200) NOT NULL,
            conteudo LONGTEXT NOT NULL,
            image_url VARCHAR(500),
            nivel VARCHAR(20) DEFAULT 'iniciante',
            ativa TINYINT(1) DEFAULT 1,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 14. PagBank Planos
        $table_pb_planos = $wpdb->prefix . 'thriveo_pagbank_planos';
        $sql_pb_planos = "CREATE TABLE $table_pb_planos (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nome VARCHAR(80) NOT NULL,
            slug VARCHAR(40) NOT NULL,
            descricao TEXT,
            preco_mensal DECIMAL(10,2) NOT NULL,
            pagbank_plan_id VARCHAR(100),
            ativo TINYINT(1) DEFAULT 1,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug)
        ) $charset_collate;";

        // 15. PagBank Assinaturas
        $table_pb_ass = $wpdb->prefix . 'thriveo_pagbank_assinaturas';
        $sql_pb_ass = "CREATE TABLE $table_pb_ass (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            plano_id INT UNSIGNED NOT NULL,
            pagbank_subscription_id VARCHAR(100),
            status VARCHAR(20) DEFAULT 'pendente',
            nf_status VARCHAR(20) DEFAULT 'pendente',
            nf_numero VARCHAR(50) DEFAULT '',
            proximo_vencimento DATE,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_empresa (empresa_id),
            KEY idx_status (status)
        ) $charset_collate;";

        // 16. PagBank Faturas
        $table_pb_faturas = $wpdb->prefix . 'thriveo_pagbank_faturas';
        $sql_pb_faturas = "CREATE TABLE $table_pb_faturas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            assinatura_id INT UNSIGNED NOT NULL,
            pagbank_charge_id VARCHAR(100),
            valor DECIMAL(10,2) NOT NULL,
            status VARCHAR(20) DEFAULT 'aguardando',
            metodo_pagamento VARCHAR(20),
            pago_em DATETIME,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_assinatura (assinatura_id)
        ) $charset_collate;";

        // 17. PagBank Webhook Logs
        $table_pb_logs = $wpdb->prefix . 'thriveo_pagbank_webhook_logs';
        $sql_pb_logs = "CREATE TABLE $table_pb_logs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            evento VARCHAR(100) NOT NULL,
            payload LONGTEXT NOT NULL,
            processado TINYINT(1) DEFAULT 0,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql_cert);
        dbDelta($sql_questoes);
        dbDelta($sql_sessoes);
        dbDelta($sql_soft);
        dbDelta($sql_refs);
        dbDelta($sql_log_verif);
        dbDelta($sql_trilhas);
        dbDelta($sql_pb_planos);
        dbDelta($sql_pb_ass);
        dbDelta($sql_pb_faturas);
        dbDelta($sql_pb_logs);

        // --- UNIFIED PLATFORM TABLES ---
        
        // 18. Empresas Table (Detailed for multi-tenancy)
        $table_empresas_unified = $wpdb->prefix . 'thriveo_empresas';
        $sql_empresas_unified = "CREATE TABLE $table_empresas_unified (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nome_fantasia VARCHAR(200) NOT NULL,
            razao_social VARCHAR(200),
            cnpj VARCHAR(20),
            logo_url VARCHAR(500),
            cor_primaria VARCHAR(7) DEFAULT '#0052cc',
            cor_secundaria VARCHAR(7) DEFAULT '#0f172a',
            config_modulos_json TEXT, -- List of enabled modules
            mp_access_token TEXT, -- Optional MP key per company
            mp_public_key TEXT,
            status VARCHAR(20) DEFAULT 'ativo',
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 19. Plataforma Usuarios Table (Permissions Link)
        $table_plt_users = $wpdb->prefix . 'thriveo_plataforma_usuarios';
        $sql_plt_users = "CREATE TABLE $table_plt_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            wp_user_id BIGINT(20) UNSIGNED NOT NULL,
            empresa_id INT UNSIGNED, -- NULL for Super Admin
            role VARCHAR(30) NOT NULL, -- super_admin, empresa_admin, usuario
            modulo_acesso_json TEXT, -- IDs of modules this user can manage
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY wp_user_id (wp_user_id),
            KEY idx_empresa (empresa_id)
        ) $charset_collate;";

        // 20. Modulos Table
        $table_modulos = $wpdb->prefix . 'thriveo_modulos';
        $sql_modulos = "CREATE TABLE $table_modulos (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nome VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL,
            descricao TEXT,
            ativo TINYINT(1) DEFAULT 1,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug)
        ) $charset_collate;";

        dbDelta($sql_empresas_unified);
        dbDelta($sql_plt_users);
        dbDelta($sql_modulos);
    }
}
