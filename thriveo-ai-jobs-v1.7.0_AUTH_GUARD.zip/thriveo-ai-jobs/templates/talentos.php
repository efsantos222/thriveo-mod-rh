<?php
/**
 * Talent Bank Template
 */
if (!defined('ABSPATH'))
    exit;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco de Talentos IA - Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0052cc;
            --secondary: #003d99;
            --accent: #00c896;
            --bg: #f8fafc;
            --white: #ffffff;
            --text: #0f172a;
            --text-light: #64748b;
            --navy: #003d99;
            --glass: rgba(255, 255, 255, 0.9);
            --border: #e2e8f0;
            --blue-light: #e8f0fe;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }

        .app-container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        /* Sidebar */
        aside {
            background: var(--white);
            color: var(--text);
            padding: 2.5rem 1.5rem;
            position: sticky;
            top: 0;
            height: 100vh;
            border-right: 1px solid var(--border);
        }

        .logo {
            margin-bottom: 3rem;
            display: flex;
            justify-content: center;
        }
        .logo img {
            max-width: 140px;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-menu li {
            margin-bottom: 1rem;
        }

        .nav-menu a {
            color: var(--text-light);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            border-radius: 8px;
            transition: 0.3s;
            font-weight: 600;
        }

        .nav-menu a:hover,
        .nav-menu a.active {
            background: var(--blue-light);
            color: var(--primary);
        }

        /* Filters */
        .filter-section {
            margin-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 2rem;
        }

        .filter-group {
            margin-bottom: 1.5rem;
        }

        .filter-group label {
            display: block;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255, 255, 255, 0.5);
            margin-bottom: 0.8rem;
        }

        .filter-group select,
        .filter-group input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            padding: 10px;
            border-radius: 6px;
            outline: none;
        }

        /* Main Content */
        main {
            padding: 2rem;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .search-bar {
            flex: 1;
            max-width: 600px;
            position: relative;
        }

        .search-bar input {
            width: 100%;
            padding: 15px 15px 15px 50px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            background: var(--white);
            font-size: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            outline: none;
            transition: 0.3s;
        }

        .search-bar i {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        .search-bar input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(0, 200, 150, 0.1);
        }

        .view-toggle {
            display: flex;
            gap: 10px;
        }

        .btn-toggle {
            background: var(--white);
            border: 1px solid #e2e8f0;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-toggle.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* Talent Grid */
        .talent-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 1.5rem;
        }

        .talent-card {
            background: var(--white);
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            transition: 0.3s;
            border: 1px solid transparent;
            position: relative;
            display: flex;
            flex-direction: column;
        }

        .talent-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border-color: var(--accent);
        }

        .match-badge {
            position: absolute;
            top: 1.5rem;
            right: 1.5rem;
            background: rgba(0, 200, 150, 0.1);
            color: var(--accent);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .talent-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 1.5rem;
        }

        .talent-avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--bg);
        }

        .talent-info h3 {
            font-size: 1.1rem;
            color: var(--navy);
            margin-bottom: 2px;
        }

        .talent-info p {
            font-size: 0.9rem;
            color: var(--text-light);
        }

        .talent-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 1.5rem;
            flex-grow: 1;
        }

        .tag {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: 500;
        }

        .tag-blue {
            background: #e0f2fe;
            color: #0369a1;
        }

        .tag-orange {
            background: #ffedd5;
            color: #9a3412;
        }

        .tag-purple {
            background: #f3e8ff;
            color: #7e22ce;
        }

        .tag-green {
            background: #dcfce7;
            color: #15803d;
        }

        .talent-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 1.5rem;
            border-top: 1px solid #f1f5f9;
        }

        .social-links {
            display: flex;
            gap: 12px;
        }

        .social-links a {
            font-size: 1.2rem;
            color: var(--text-light);
            transition: 0.3s;
        }

        .social-links a:hover {
            color: var(--primary);
        }

        .btn-perfil {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-perfil:hover {
            background: var(--navy);
        }

        /* Modal */
        #candidate-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--white);
            width: 90%;
            max-width: 900px;
            max-height: 90vh;
            border-radius: 20px;
            overflow-y: auto;
            position: relative;
            padding: 2.5rem;
        }

        .close-modal {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--text-light);
        }

        /* Loading */
        #loading-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: var(--bg);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #e2e8f0;
            border-top-color: var(--accent);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 1024px) {
            .app-container {
                grid-template-columns: 1fr;
            }

            aside {
                display: none;
            }
        }
    </style>
</head>

<body>

    <div id="loading-overlay">
        <div class="spinner"></div>
    </div>

    <div class="app-container">
        <aside>
            <div class="logo">
                <a href="<?php echo home_url(); ?>" style="text-decoration:none;">
                    <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_branco_transparente.png"
                        alt="Thriveo" style="width: 140px; height: auto; display: block;">
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="?thriveo_talentos=1" class="active"
                        title="Acesse a lista completa de profissionais de IA cadastrados."><i class="fas fa-users"></i>
                        Banco de Talentos</a></li>
                <li><a href="?thriveo_empresa_vagas=1"
                        title="Gerencie suas oportunidades e veja candidatos interessados nas suas vagas."><i
                            class="fas fa-briefcase"></i> Gestão de Vagas</a></li>
                <li><a href="?thriveo_dashboard=1" title="Acesse seu perfil pessoal e configurações de conta."><i
                            class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="?thriveo_certificacoes=1" title="Confira e gerencie os selos de certificação."><i
                            class="fas fa-certificate"></i> Certificações</a></li>
                <li><a href="<?php echo home_url('?thriveo_vagas=1'); ?>"
                        title="Visualize o painel público de oportunidades."><i class="fas fa-eye"></i> Ver Portal de
                        Vagas</a></li>
                <li><a href="<?php echo home_url(); ?>" title="Retornar para a página inicial do portal Thriveo."><i
                            class="fas fa-home"></i> Voltar ao Site</a></li>
                <li><a href="#" id="th-btnLogout-talents" title="Encerrar sua sessão atual com segurança."><i
                            class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
            </ul>

            <div class="filter-section">
                <div class="filter-group">
                    <label>Área de Atuação</label>
                    <select id="filter-area" title="Filtre os candidatos pela especialidade técnica principal.">
                        <option value="">Todas</option>
                        <option value="Backend">Backend</option>
                        <option value="Frontend">Frontend</option>
                        <option value="Full-Stack">Full-Stack</option>
                        <option value="Data/IA">Data/IA</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Nível</label>
                    <select id="filter-nivel">
                        <option value="">Todos</option>
                        <option value="Júnior">Júnior</option>
                        <option value="Pleno">Pleno</option>
                        <option value="Sênior">Sênior</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Origem</label>
                    <select id="filter-origem">
                        <option value="">Todas</option>
                        <option value="github">GitHub</option>
                        <option value="linkedin">LinkedIn</option>
                    </select>
                </div>
            </div>
        </aside>

        <main>
            <div class="page-intro"
                style="margin-bottom: 2.5rem; background: var(--white); padding: 2rem; border-radius: 20px; border-left: 5px solid var(--accent); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <h1 style="font-size: 1.8rem; color: var(--navy); margin-bottom: 0.5rem;">Explore o Futuro do
                    Recrutamento de IA</h1>
                <p style="color: var(--text-light); font-size: 1.05rem; max-width: 800px;">Conecte-se com os melhores
                    profissionais de inteligência artificial do Brasil. Utilize nossos filtros inteligentes calibrados
                    por IA para encontrar o match perfeito para sua cultura e desafios técnicos.</p>
            </div>
            <header>
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" id="search-input" placeholder="Buscar por nome, cargo ou tecnologia..."
                        title="Digite palavras-chave como 'Python', 'LLM' ou nomes para uma busca em tempo real.">
                </div>
                <div class="view-toggle">
                    <button class="btn-toggle active" title="Cards view"><i class="fas fa-th-large"></i></button>
                    <button class="btn-toggle" title="Table view"><i class="fas fa-list"></i></button>
                </div>
            </header>

            <div id="talent-results" class="talent-grid">
                <!-- Cards will be injected here via JS -->
            </div>

            <div id="pagination" style="margin-top: 3rem; display: flex; justify-content: center; gap: 10px;">
                <!-- Pagination buttons -->
            </div>
        </main>
    </div>

    <div id="candidate-modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div id="modal-body">
                <!-- Details loaded via AJAX -->
            </div>
        </div>
    </div>

    <script>
        const talentGrid = document.getElementById('talent-results');
        const searchInput = document.getElementById('search-input');
        const filterArea = document.getElementById('filter-area');
        const filterNivel = document.getElementById('filter-nivel');
        const filterOrigem = document.getElementById('filter-origem');

        async function loadTalents(paged = 1) {
            document.getElementById('loading-overlay').style.display = 'flex';

            const params = new URLSearchParams({
                action: 'thriveo_get_candidatos',
                busca: searchInput.value,
                area: filterArea.value,
                nivel: filterNivel.value,
                origem: filterOrigem.value,
                paged: paged
            });

            try {
                const response = await fetch(`<?php echo admin_url('admin-ajax.php'); ?>?${params}`);
                const data = await response.json();

                if (data.success) {
                    renderTalents(data.data.candidatos);
                    renderPagination(data.data.page, data.data.has_more);
                }
            } catch (error) {
                console.error("Erro ao carregar talentos:", error);
            } finally {
                document.getElementById('loading-overlay').style.display = 'none';
            }
        }

        function renderTalents(candidatos) {
            if (candidatos.length === 0) {
                talentGrid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding: 4rem;">Nenhum talento encontrado.</div>';
                return;
            }

            talentGrid.innerHTML = candidatos.map(c => {
                const skills = c.skills_json ? c.skills_json.split(',').slice(0, 5) : [];
                const matchColor = c.match_score > 85 ? 'tag-green' : (c.match_score > 75 ? 'tag-blue' : 'tag-orange');

                return `
                <div class="talent-card">
                    <span class="match-badge">${c.match_score}% Match IA</span>
                    <div class="talent-header">
                        <img src="${c.avatar || 'https://www.gravatar.com/avatar/000?d=mp'}" class="talent-avatar" alt="${c.nome}">
                        <div class="talent-info">
                            <h3>${c.nome}</h3>
                            <p>${c.cargo_atual || 'Especialista em IA'}</p>
                            <small><i class="fas fa-map-marker-alt"></i> ${c.cidade || 'Não informada'} / ${c.estado || ''}</small>
                        </div>
                    </div>
                    <div class="talent-tags">
                        ${skills.map((s, i) => `<span class="tag ${['tag-blue', 'tag-orange', 'tag-purple', 'tag-green'][i % 4]}">${s.trim()}</span>`).join('')}
                    </div>
                    <div class="talent-footer">
                        <div class="social-links">
                            ${c.github_username ? `<a href="https://github.com/${c.github_username}" target="_blank"><i class="fab fa-github"></i></a>` : ''}
                            ${c.linkedin_url ? `<a href="${c.linkedin_url}" target="_blank"><i class="fab fa-linkedin"></i></a>` : ''}
                        </div>
                        <button class="btn-perfil" onclick="viewDetail(${c.id})">Ver Perfil</button>
                    </div>
                </div>
            `;
            }).join('');
        }

        function renderPagination(current, hasMore) {
            const pagDiv = document.getElementById('pagination');
            pagDiv.innerHTML = '';
            if (current > 1) {
                pagDiv.innerHTML += `<button class="btn-perfil" onclick="loadTalents(${current - 1})">Anterior</button>`;
            }
            if (hasMore) {
                pagDiv.innerHTML += `<button class="btn-perfil" onclick="loadTalents(${current + 1})">Próxima</button>`;
            }
        }

        async function viewDetail(id) {
            const modal = document.getElementById('candidate-modal');
            const modalBody = document.getElementById('modal-body');
            modal.style.display = 'flex';
            modalBody.innerHTML = '<p>Carregando perfil...</p>';

            try {
                const response = await fetch(`<?php echo admin_url('admin-ajax.php'); ?>?action=thriveo_get_candidato_detail&id=${id}`);
                const data = await response.json();

                if (data.success) {
                    const c = data.data.candidato;
                    modalBody.innerHTML = `
                    <div style="display:grid; grid-template-columns: 1fr 2fr; gap: 30px;">
                        <div>
                            <img src="${c.avatar}" style="width:100%; border-radius:20px; margin-bottom: 20px;">
                            <h2>${c.name}</h2>
                            <p style="color: var(--text-light); margin-bottom: 20px;">${c.cargo_atual || 'Especialista'}</p>
                            <div style="background:var(--bg); padding: 15px; border-radius: 12px;">
                                <strong>Detalhes:</strong>
                                <ul style="list-style:none; margin-top: 10px; font-size: 0.9rem;">
                                    <li><i class="fas fa-envelope"></i> ${c.email}</li>
                                    <li><i class="fas fa-location-arrow"></i> ${c.location}</li>
                                    <li><i class="fas fa-calendar"></i> Cadastrado em: ${new Date(c.created_at).toLocaleDateString()}</li>
                                </ul>
                            </div>
                        </div>
                        <div>
                            <h3>Sobre / Bio</h3>
                            <p style="margin: 15px 0 25px;">${c.bio || 'Sem bio cadastrada.'}</p>
                            
                            <h3>Stack Tecnológica</h3>
                            <div class="talent-tags" style="margin-top: 15px;">
                                ${c.ai_skills ? c.ai_skills.split(',').map(s => `<span class="tag tag-blue">${s}</span>`).join('') : ''}
                            </div>

                            <h3 style="margin-top: 30px;">Anotações da Empresa</h3>
                            <textarea id="note-text" style="width:100%; height:80px; margin: 10px 0; padding:10px; border-radius:8px; border:1px solid #ddd;"></textarea>
                            <button class="btn-perfil" onclick="saveNote(${c.id})">Salvar Anotação</button>
                            
                            <div id="notes-list" style="margin-top:20px; font-size: 0.85rem;">
                                ${data.data.anotacoes.map(n => `
                                    <div style="border-bottom: 1px solid #eee; padding: 10px 0;">
                                        <strong>${n.autor_nome}:</strong> ${n.anotacao} <br>
                                        <small style="color:#aaa">${new Date(n.criado_em).toLocaleDateString()}</small>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                `;
                }
            } catch (error) {
                modalBody.innerHTML = 'Erro ao carregar dados.';
            }
        }

        async function saveNote(id) {
            const text = document.getElementById('note-text').value;
            if (!text) return alert("Digite algo.");

            const fd = new FormData();
            fd.append('action', 'thriveo_save_candidate_note');
            fd.append('candidato_id', id);
            fd.append('anotacao', text);

            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: fd
            });
            const data = await response.json();
            if (data.success) {
                alert("Anotação salva!");
                viewDetail(id); // Reload
            }
        }

        // Events
        searchInput.addEventListener('input', () => loadTalents());
        filterArea.addEventListener('change', () => loadTalents());
        filterNivel.addEventListener('change', () => loadTalents());
        filterOrigem.addEventListener('change', () => loadTalents());

        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.onclick = () => document.getElementById('candidate-modal').style.display = 'none';
        });

        // Initial load
        loadTalents();
    </script>

</body>

</html>