<?php
if (!defined('ABSPATH')) exit;

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0,0,0,0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #0052cc; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) { window.location.href = '<?php echo home_url(); ?>'; }
            else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => { if (data.success) window.location.reload(); else window.location.href = '<?php echo home_url(); ?>'; })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
<?php exit; endif; ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Matching Inteligente — Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL . 'assets/css/thriveo-modern.css'; ?>">
    <style>
        body { background: var(--surface); font-family: var(--font); margin: 0; padding: 0; }
        .nav-modern { background: var(--white); box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
        .hero-mini { padding: 4rem 2rem 2rem; background: var(--white); border-bottom: 1px solid var(--border); text-align: center; }
        .hero-mini h1 { font-size: 2.2rem; font-weight: 800; color: var(--ink); margin-bottom: 1rem; letter-spacing: -0.02em; }
        .hero-mini p { color: var(--muted); max-width: 600px; margin: 0 auto; }
        
        .container-matching { max-width: 1000px; margin: 0 auto; padding: 3rem 2rem; }
        
        .match-card { background: var(--white); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 2rem; box-shadow: var(--shadow); margin-bottom: 2rem; position: relative; overflow: hidden; }
        .match-card::before { content: ""; position: absolute; top:0; left:0; width: 4px; height: 100%; background: var(--blue); }
        
        .match-header { display: flex; justify-content: space-between; align-items: start; gap: 2rem; margin-bottom: 1.5rem; }
        .match-info h3 { margin: 0; font-size: 1.2rem; font-weight: 700; color: var(--ink); }
        .match-info .company { font-size: 0.9rem; color: var(--muted); margin-top: 0.2rem; font-weight: 500; }
        
        /* Circular Score */
        .score-circle { width: 80px; height: 80px; position: relative; flex-shrink: 0; }
        .score-circle svg { transform: rotate(-90deg); }
        .score-circle .circle-bg { fill: none; stroke: var(--border); stroke-width: 6; }
        .score-circle .circle-progress { fill: none; stroke: var(--blue); stroke-width: 6; stroke-linecap: round; transition: stroke-dashoffset 1s ease; }
        .score-circle .score-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; font-weight: 800; color: var(--blue); }

        .tags-vaga { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem; }
        .tag-match { background: var(--blue-light); color: var(--blue); padding: 0.3rem 0.8rem; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        
        .match-details { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border); }
        .detail-item { display: flex; flex-direction: column; gap: 0.2rem; }
        .detail-item label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600; }
        .detail-item span { font-size: 1rem; font-weight: 700; color: var(--ink); }

        .back-link { position: absolute; top: 22px; left: 2.5rem; text-decoration: none; color: var(--muted); font-size: 0.85rem; font-weight: 600; display: flex; align-items: center; gap: 0.4rem; transition: color 0.2s; }
        .back-link:hover { color: var(--blue); }

        .pro-badge { position: absolute; top: 1.5rem; right: 1.5rem; background: var(--blue); color: #fff; padding: 0.2rem 0.7rem; border-radius: 50px; font-size: 0.65rem; font-weight: 800; letter-spacing: 0.1em; }
    </style>
</head>
<body>

<nav class="nav-modern">
    <a href="<?php echo home_url('/?thriveo_dashboard=1'); ?>" class="back-link">← Voltar ao Perfil</a>
    <div style="font-weight: 800; color: var(--blue); font-size: 1.25rem;">Thriveo IA</div>
    <div class="user-pill">
        <span style="font-size: 0.85rem; font-weight: 600;">Matching Pro</span>
    </div>
</nav>

<div class="page-modern">
    <header class="hero-mini">
        <div class="tag-modern" style="margin-bottom: 1rem;">Módulo 03 — Matching Inteligente</div>
        <h1>Sua compatibilidade com o mercado</h1>
        <p>Utilizamos IA para cruzar suas certificações, habilidades e portfólio com as melhores oportunidades em tempo real.</p>
    </header>

    <div class="container-matching">
        <!-- MATCH 1 -->
        <div class="match-card">
            <div class="pro-badge">PRO MATCH</div>
            <div class="match-header">
                <div class="match-info">
                    <h3>Engenheiro de LLMs & Agentes</h3>
                    <div class="company">TechCorp Solutions · Remoto · São Paulo</div>
                    <div class="tags-vaga" style="margin-top: 1rem;">
                        <span class="tag-match">LangChain</span>
                        <span class="tag-match">Python</span>
                        <span class="tag-match">RAG</span>
                        <span class="tag-match">FastAPI</span>
                    </div>
                </div>
                <div class="score-circle">
                    <svg width="80" height="80">
                        <circle class="circle-bg" cx="40" cy="40" r="34" />
                        <circle class="circle-progress" cx="40" cy="40" r="34" style="stroke-dasharray: 213.6; stroke-dashoffset: 21.3;" />
                    </svg>
                    <div class="score-text">90%</div>
                </div>
            </div>
            
            <div class="match-details">
                <div class="detail-item"><label>Salário Estimado</label><span>R$ 15.000 - 22.000</span></div>
                <div class="detail-item"><label>Nível</label><span>Sênior</span></div>
                <div class="detail-item"><label>Pontos Fortes</label><span style="color: var(--green); font-size: 0.85rem;">Certificação GenAI ✓</span></div>
                <div class="detail-item">
                    <button class="btn-modern btn-modern-primary" style="justify-content: center;">Aplicar agora</button>
                </div>
            </div>
        </div>

        <!-- MATCH 2 -->
        <div class="match-card" style="opacity: 0.8;">
            <div class="match-header">
                <div class="match-info">
                    <h3>Analista de Dados & Business Intelligence AI</h3>
                    <div class="company">Fintech Alpha · Híbrido · Barueri, SP</div>
                    <div class="tags-vaga" style="margin-top: 1rem;">
                        <span class="tag-match">SQL</span>
                        <span class="tag-match">Pandas</span>
                        <span class="tag-match">AutoML</span>
                        <span class="tag-match">Tableau</span>
                    </div>
                </div>
                <div class="score-circle">
                    <svg width="80" height="80">
                        <circle class="circle-bg" cx="40" cy="40" r="34" />
                        <circle class="circle-progress" cx="40" cy="40" r="34" style="stroke: var(--amber); stroke-dasharray: 213.6; stroke-dashoffset: 64.0;" />
                    </svg>
                    <div class="score-text" style="color: var(--amber);">70%</div>
                </div>
            </div>
            
            <div class="match-details">
                <div class="detail-item"><label>Salário Estimado</label><span>R$ 10.000 - 14.000</span></div>
                <div class="detail-item"><label>Nível</label><span>Pleno</span></div>
                <div class="detail-item"><label>Gap de Skill</label><span style="color: var(--red); font-size: 0.85rem;">Docker / MLOps</span></div>
                <div class="detail-item">
                    <button class="btn-modern btn-modern-primary" style="justify-content: center; background: var(--ink);">Ver Trilha p/ Gap</button>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
