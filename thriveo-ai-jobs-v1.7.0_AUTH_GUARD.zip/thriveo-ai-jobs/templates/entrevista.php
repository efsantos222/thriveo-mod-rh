<?php
if (!defined('ABSPATH')) exit;

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0,0,0,0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #0052cc; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) { window.location.href = '<?php echo home_url(); ?>'; }
            else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => { if (data.success) window.location.reload(); else window.location.href = '<?php echo home_url(); ?>'; })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
<?php exit; endif; ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Entrevista com IA — Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL . 'assets/css/thriveo-modern.css'; ?>">
    <style>
        body { background: var(--surface); font-family: var(--font); margin: 0; padding: 0; height: 100vh; display: flex; flex-direction: column; }
        .nav-modern { background: var(--white); box-shadow: 0 1px 2px rgba(0,0,0,0.05); flex-shrink: 0; }
        
        .interview-container { flex: 1; display: grid; grid-template-columns: 320px 1fr; gap: 2px; background: var(--border); overflow: hidden; margin-top: 68px; }
        
        /* Sidebar */
        .interview-sidebar { background: var(--white); padding: 2rem; display: flex; flex-direction: column; gap: 2rem; overflow-y: auto; }
        .interview-sidebar h2 { font-size: 1.1rem; font-weight: 800; margin: 0; letter-spacing: -0.01em; }
        .interviewer-info { display: flex; align-items: center; gap: 1rem; padding: 1rem; background: var(--surface); border-radius: var(--radius); border: 1px solid var(--border); }
        .interviewer-av { width: 44px; height: 44px; border-radius: 50%; background: var(--blue); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: #fff; }
        .interviewer-text div { font-size: 0.85rem; font-weight: 700; }
        .interviewer-text span { font-size: 0.75rem; color: var(--muted); }
        
        .interview-metrics { display: flex; flex-direction: column; gap: 1.5rem; }
        .metric-item { display: flex; flex-direction: column; gap: 0.4rem; }
        .metric-header { display: flex; justify-content: space-between; font-size: 0.75rem; font-weight: 700; color: var(--muted); text-transform: uppercase; }
        .metric-bar { height: 6px; background: var(--border); border-radius: 3px; overflow: hidden; }
        .metric-fill { height: 100%; background: var(--blue); transition: width 0.3s; }
        
        /* Chat Area */
        .chat-area { background: #fff; display: flex; flex-direction: column; }
        .chat-messages { flex: 1; padding: 2rem; overflow-y: auto; display: flex; flex-direction: column; gap: 1.5rem; background: #fff; }
        
        .msg { max-width: 70%; display: flex; flex-direction: column; gap: 0.3rem; }
        .msg-ai { align-self: flex-start; }
        .msg-user { align-self: flex-end; }
        
        .bubble { padding: 1rem 1.25rem; border-radius: 16px; font-size: 0.95rem; line-height: 1.6; }
        .msg-ai .bubble { background: var(--surface); color: var(--ink); border: 1px solid var(--border); border-bottom-left-radius: 4px; }
        .msg-user .bubble { background: var(--blue); color: #fff; border-bottom-right-radius: 4px; }
        
        .msg-meta { font-size: 0.7rem; color: var(--muted); padding: 0 0.5rem; }
        .msg-user .msg-meta { text-align: right; }
        
        .chat-input-wrapper { padding: 1.5rem 2rem; background: var(--white); border-top: 1px solid var(--border); box-shadow: 0 -4px 12px rgba(0,0,0,0.02); }
        .input-box { display: flex; gap: 1rem; background: var(--surface); padding: 0.5rem; border-radius: 12px; border: 1px solid var(--border); transition: border-color 0.2s, box-shadow 0.2s; }
        .input-box:focus-within { border-color: var(--blue); box-shadow: 0 0 0 3px rgba(0,82,204,0.08); }
        .input-box input { flex: 1; border: none; background: transparent; padding: 0.5rem 0.75rem; font-family: var(--font); font-size: 0.95rem; outline: none; }

        .back-link { position: absolute; top: 22px; left: 2.5rem; text-decoration: none; color: var(--muted); font-size: 0.85rem; font-weight: 600; display: flex; align-items: center; gap: 0.4rem; transition: color 0.2s; }
        .back-link:hover { color: var(--blue); }
    </style>
</head>
<body>

<nav class="nav-modern">
    <a href="<?php echo home_url('/?thriveo_dashboard=1'); ?>" class="back-link">← Sair da Simulação</a>
    <div style="font-weight: 800; color: var(--blue); font-size: 1.25rem;">Thriveo IA</div>
    <div class="user-pill">
        <span style="font-size: 0.85rem; font-weight: 600;">Simulação Técnica</span>
    </div>
</nav>

<div class="interview-container">
    <!-- SIDEBAR -->
    <aside class="interview-sidebar">
        <div>
            <div class="tag-modern" style="margin-bottom: 0.5rem;">Módulo 04 — Entrevista</div>
            <h2>Foco: Desenvolvedor GenAI</h2>
        </div>

        <div class="interviewer-info">
            <div class="interviewer-av">🤖</div>
            <div class="interviewer-text">
                <div>Thriveo Agent</div>
                <span>Technical Interviewer</span>
            </div>
        </div>

        <div class="interview-metrics">
            <div class="metric-item">
                <div class="metric-header"><span>Domínio Técnico</span><span>65%</span></div>
                <div class="metric-bar"><div class="metric-fill" style="width: 65%;"></div></div>
            </div>
            <div class="metric-item">
                <div class="metric-header"><span>Clareza</span><span>80%</span></div>
                <div class="metric-bar"><div class="metric-fill" style="width: 80%;"></div></div>
            </div>
            <div class="metric-item">
                <div class="metric-header"><span>Soft Skills</span><span>45%</span></div>
                <div class="metric-bar"><div class="metric-fill" style="width: 45%; background: var(--amber);"></div></div>
            </div>
        </div>

        <div style="margin-top: auto; padding-top: 2rem; border-top: 1px solid var(--border);">
            <p style="font-size: 0.75rem; color: var(--muted); border-left: 2px solid var(--blue); padding-left: 1rem;">
                Dica da IA: Tente ser mais específico sobre a arquitetura de transformers na sua próxima resposta.
            </p>
        </div>
    </aside>

    <!-- CHAT AREA -->
    <main class="chat-area">
        <div class="chat-messages" id="chat-stream">
            <!-- AI Message -->
            <div class="msg msg-ai">
                <div class="bubble">
                    Olá Ezequiel! Vamos iniciar sua simulação técnica para a vaga de Desenvolvedor GenAI. <br><br>
                    Para começar, poderia me explicar como você abordaria o problema de "hallucination" em um sistema de RAG (Retrieval Augmented Generation)?
                </div>
                <div class="msg-meta">Agora mesmo</div>
            </div>

            <!-- User Message -->
            <div class="msg msg-user">
                <div class="bubble">
                    Com certeza. Para mitigar alucinações em RAG, eu focaria primeiro na qualidade do chunking e dos embeddings. Além disso, utilizaria técnicas de self-grading, onde um modelo avalia se a resposta gerada está de fato baseada no documento recuperado (grounding).
                </div>
                <div class="msg-meta">Lido</div>
            </div>

            <!-- AI Message -->
            <div class="msg msg-ai">
                <div class="bubble">
                    Excelente ponto. O grounding é fundamental. Como você implementaria esse self-grading? Utilizaria algum framework específico como LangGraph ou faria de forma customizada?
                </div>
                <div class="msg-meta">Digitando...</div>
            </div>
        </div>

        <div class="chat-input-wrapper">
            <div class="input-box">
                <input type="text" placeholder="Digite sua resposta técnica aqui...">
                <button class="btn-modern btn-modern-primary">Enviar</button>
            </div>
        </div>
    </main>
</div>

</body>
</html>
