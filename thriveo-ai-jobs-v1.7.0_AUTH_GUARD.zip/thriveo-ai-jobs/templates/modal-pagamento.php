<?php
/**
 * Modal de Planos & Pagamento Condicional (Checkout Transparente)
 */
if (!defined('ABSPATH'))
    exit;
?>
<style>
/* Estilos para o Checkout de Planos */
.plan-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
.plan-card { 
    border: 2px solid #e2e8f0; border-radius: 12px; padding: 20px; text-align: center; cursor: pointer; transition: 0.3s; 
}
.plan-card:hover { border-color: var(--accent); transform: translateY(-3px); }
.plan-card.selected { border-color: var(--accent); background: #f0fdf9; }
.plan-price { font-size: 1.8rem; font-weight: 800; color: var(--navy); margin: 10px 0; }
.plan-features { list-style: none; padding: 0; margin-bottom: 15px; font-size: 0.85rem; color: var(--text-light); text-align: left;}
.plan-features li { margin-bottom: 8px; }
.plan-features i { color: var(--accent); margin-right: 6px; }

.checkout-form { display: none; text-align: left; background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; }
.checkout-form.active { display: block; }

.btn-pay {
    width: 100%; background: var(--accent); color: white; border: none; padding: 15px; border-radius: 10px; font-weight: 700; font-size: 1.1rem; cursor: pointer; transition: 0.3s; margin-top: 15px;
}
.btn-pay:hover { background: #00b386; }
.btn-pay:disabled { background: #cbd5e1; cursor: not-allowed; }

@media (max-width: 768px) {
    .plan-cards { grid-template-columns: 1fr; }
}
</style>

<div id="modal-pagamento" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:2000; align-items:center; justify-content:center; backdrop-filter:blur(10px);">
    <div style="background:white; padding:30px; border-radius:20px; max-width:800px; width:95%; text-align:center; box-shadow:0 20px 40px rgba(0,0,0,0.2); max-height: 90vh; overflow-y: auto;">
        
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
            <h2 style="color:#1a2e4a; margin:0;">Evolua sua Gestão de Vagas</h2>
            <button onclick="document.getElementById('modal-pagamento').style.display='none'" class="btn-icon"><i class="fas fa-times"></i></button>
        </div>
        
        <p style="color:#64748b; margin-bottom:25px;">Escolha o plano ideal para as necessidades da sua empresa. Cancele quando quiser.</p>

        <!-- Etapa 1: Escolha do Plano -->
        <div id="step-plans">
            <div class="plan-cards">
                <div class="plan-card" onclick="selectPlan('basico', 99)">
                    <h3 style="color:var(--text); font-size:1.1rem;">Básico</h3>
                    <div class="plan-price">R$ 99<span style="font-size:1rem;color:#64748b;">/mês</span></div>
                    <ul class="plan-features">
                        <li><i class="fas fa-check-circle"></i> 1 Vaga Adicional</li>
                        <li><i class="fas fa-check-circle"></i> Suporte Email</li>
                    </ul>
                    <button class="btn-ghost" style="width:100%">Selecionar</button>
                </div>
                <div class="plan-card" onclick="selectPlan('profissional', 199)">
                    <div style="background:var(--accent);color:white;font-size:0.7rem;font-weight:bold;padding:3px 8px;border-radius:10px;display:inline-block;margin-bottom:10px;">RECOMENDADO</div>
                    <h3 style="color:var(--text); font-size:1.1rem;">Profissional</h3>
                    <div class="plan-price">R$ 199<span style="font-size:1rem;color:#64748b;">/mês</span></div>
                    <ul class="plan-features">
                        <li><i class="fas fa-check-circle"></i> 3 Vagas Adicionais</li>
                        <li><i class="fas fa-check-circle"></i> Destaque "Patrocinada"</li>
                    </ul>
                    <button class="btn-new" style="width:100%; border-radius:8px;">Selecionar</button>
                </div>
                <div class="plan-card" onclick="selectPlan('enterprise', 499)">
                    <h3 style="color:var(--text); font-size:1.1rem;">Enterprise</h3>
                    <div class="plan-price">R$ 499<span style="font-size:1rem;color:#64748b;">/mês</span></div>
                    <ul class="plan-features">
                        <li><i class="fas fa-check-circle"></i> Vagas Ilimitadas</li>
                        <li><i class="fas fa-check-circle"></i> Triagem IA Avançada</li>
                    </ul>
                    <button class="btn-ghost" style="width:100%">Selecionar</button>
                </div>
            </div>
        </div>

        <!-- Etapa 2: Redirecionamento de Pagamento -->
        <div id="step-checkout" class="checkout-form">
            <h3 style="color:var(--navy); margin-bottom:15px; display:flex; justify-content:space-between;">
                <span>Detalhes do Plano</span>
                <span id="checkout-plan-name" style="color:var(--accent);">Plano</span>
            </h3>
            
            <form id="checkout-pagbank-form">
                <input type="hidden" id="selected_plan_slug" name="plano_slug">
                
                <div style="background: #e0f2fe; padding: 20px; border-radius: 8px; border-left: 4px solid #0ea5e9; text-align: left; margin-bottom: 20px;">
                    <p style="margin: 0; color: #0369a1; font-size: 0.95rem;">
                        <i class="fas fa-shield-alt" style="margin-right: 8px;"></i> Você será redirecionado para o ambiente seguro do PagBank para concluir sua assinatura.
                    </p>
                </div>

                <div class="form-group full" style="margin-bottom:20px;">
                    <label>Seu CPF ou CNPJ *</label>
                    <input type="text" id="cc_tax_id" placeholder="Digite apenas números..." maxlength="18" required>
                </div>

                <button type="submit" class="btn-pay" id="btn-process-pay">
                    <i class="fas fa-external-link-alt"></i> Ir para o Pagamento Seguro
                </button>
                <div style="text-align:center; margin-top:10px;">
                    <button type="button" class="btn-ghost" style="border:none;" onclick="cancelCheckout()">Voltar aos planos</button>
                </div>
            </form>
        </div>

<script>
function selectPlan(slug, price) {
    document.querySelectorAll('.plan-card').forEach(c => c.classList.remove('selected'));
    event.currentTarget.classList.add('selected');
    
    document.getElementById('selected_plan_slug').value = slug;
    document.getElementById('checkout-plan-name').innerText = slug.toUpperCase() + ' - R$ ' + price;
    
    document.getElementById('step-plans').style.display = 'none';
    document.getElementById('step-checkout').classList.add('active');
    
    // Não precisamos buscar chave pública para esse método
    // fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=thriveo_get_pagbank_key')...
}

function cancelCheckout() {
    document.getElementById('step-checkout').classList.remove('active');
    document.getElementById('step-plans').style.display = 'block';
}

document.getElementById('checkout-pagbank-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = document.getElementById('btn-process-pay');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Gerando Link de Pagamento...';

    const formData = new URLSearchParams();
    formData.append('action', 'thriveo_create_subscription');
    formData.append('plano_slug', document.getElementById('selected_plan_slug').value);
    formData.append('tax_id', document.getElementById('cc_tax_id').value);
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData.toString()
    })
    .then(r => r.json())
    .then(res => {
        if(res.success && res.data.payment_link) {
            // Se gerou com sucesso, redireciona o usuário
            window.location.href = res.data.payment_link;
        } else {
            alert('Erro ao gerar pagamento: ' + res.data.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-external-link-alt"></i> Ir para o Pagamento Seguro';
        }
    });
});

// Remover as formatacoes antigas que não servem mais
document.getElementById('cc_tax_id').addEventListener('input', function(e) {
  let val = e.target.value.replace(/\D/g, '');
  if (val.length <= 11) {
    val = val.replace(/(\d{3})(\d)/, '$1.$2');
    val = val.replace(/(\d{3})(\d)/, '$1.$2');
    val = val.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  } else {
    val = val.replace(/^(\d{2})(\d)/, '$1.$2');
    val = val.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
    val = val.replace(/\.(\d{3})(\d)/, '.$1/$2');
    val = val.replace(/(\d{4})(\d)/, '$1-$2');
  }
  e.target.value = val;
});
</script>