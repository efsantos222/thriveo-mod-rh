<?php
/**
 * Public Job Board Template
 */
if (!defined('ABSPATH'))
    exit;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vagas de IA e Tech - Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1a2e4a;
            --accent: #00c896;
            --bg: #f8fafc;
            --white: #ffffff;
            --text: #1e293b;
            --text-light: #64748b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Outfit', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
        }

        .navbar {
            background: var(--white);
            border-bottom: 1px solid #e2e8f0;
            padding: 1rem 2rem;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            color: var(--accent);
        }

        .btn-login {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            transition: 0.3s;
        }

        .btn-login:hover {
            background: #102a43;
        }

        .hero {
            background: var(--primary);
            color: white;
            padding: 5rem 2rem;
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1.25rem;
            color: rgba(255, 255, 255, 0.7);
            max-width: 700px;
            margin: 0 auto;
        }

        .container {
            max-width: 1200px;
            margin: -3rem auto 4rem;
            padding: 0 2rem;
        }

        /* Search & Filters */
        .search-box {
            background: var(--white);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
            display: grid;
            grid-template-columns: 1fr 1fr 1fr auto;
            gap: 15px;
            margin-bottom: 3rem;
        }

        .search-box select,
        .search-box input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            outline: none;
        }

        .btn-search {
            background: var(--accent);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        /* Job Cards */
        .job-grid {
            display: grid;
            gap: 1.5rem;
        }

        .job-card {
            background: var(--white);
            border-radius: 16px;
            padding: 1.5rem;
            border: 1px solid #e2e8f0;
            transition: 0.3s;
            display: grid;
            grid-template-columns: 80px 1fr auto;
            gap: 20px;
            align-items: center;
        }

        .job-card:hover {
            border-color: var(--accent);
            transform: translateY(-3px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }

        .job-card.featured {
            border-left: 4px solid var(--accent);
            background: #f0fdf9;
        }

        .company-logo {
            width: 80px;
            height: 80px;
            border-radius: 12px;
            object-fit: cover;
            background: #f8fafc;
            border: 1px solid #eee;
        }

        .job-info h2 {
            font-size: 1.25rem;
            margin-bottom: 5px;
        }

        .job-info .company-name {
            font-weight: 600;
            color: var(--text-light);
            font-size: 0.95rem;
            margin-bottom: 10px;
        }

        .job-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .tag {
            font-size: 0.75rem;
            padding: 4px 12px;
            border-radius: 20px;
            background: #f1f5f9;
            font-weight: 600;
            color: var(--text-light);
        }

        .job-meta {
            text-align: right;
        }

        .salary {
            font-weight: 700;
            color: var(--primary);
            font-size: 1.1rem;
            display: block;
            margin-bottom: 15px;
        }

        .btn-apply {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .btn-apply:hover {
            background: #102a43;
        }

        .featured-badge {
            font-size: 0.65rem;
            background: var(--accent);
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            vertical-align: middle;
            margin-left: 10px;
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <div class="nav-container">
            <a href="<?php echo home_url(); ?>" class="logo" style="text-decoration:none;">
                <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png"
                    alt="Thriveo" style="width: 120px; height: auto; display: block;">
            </a>
            <div style="display: flex; gap: 20px; align-items: center;">
                <a href="<?php echo home_url(); ?>"
                    style="text-decoration:none; color: var(--text); font-weight: 500; font-size: 0.9rem;">Início</a>
                <a href="?thriveo_talentos=1"
                    style="text-decoration:none; color: var(--text); font-weight: 500; font-size: 0.9rem;">Talentos</a>
                <a href="?thriveo_dashboard=1" class="btn-login" style="margin-left: 10px;">Minha Conta</a>
                <button id="th-btnLogout-public" class="btn-login"
                    style="background: transparent; color: var(--text); border: 1px solid #e2e8f0; cursor: pointer; display: none;">Sair</button>
            </div>
        </div>
    </nav>

    <div class="hero">
        <h1>Sua Carreira em IA Começa Aqui</h1>
        <p>Explore as oportunidades mais disruptivas do mercado. Nossa plataforma conecta especialistas como você com
            empresas que estão liderando a revolução tecnológica no Brasil.</p>
    </div>

    <div class="container">
        <div class="search-box">
            <input type="text" placeholder="Cargo ou palavra-chave..."
                title="Busque por termos como 'Machine Learning', 'LLM', 'Engenheiro', etc.">
            <select title="Selecione a área técnica de seu interesse.">
                <option value="">Todas as Áreas</option>
                <option value="Data/IA">Data / IA</option>
                <option value="Engineering">Engineering</option>
            </select>
            <select title="Escolha a localização desejada ou 'Remoto' para flexibilidade total.">
                <option value="">Todas as Cidades</option>
                <option value="SP">São Paulo</option>
                <option value="Remoto">Remoto</option>
            </select>
            <button class="btn-search" title="Clique para atualizar a lista com os filtros aplicados.">Buscar
                Vagas</button>
        </div>

        <div id="vagas-public-list" class="job-grid">
            <!-- Cards loaded via JS -->
        </div>
    </div>

    <script>
        async function loadPublicVagas() {
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=thriveo_get_vagas_list');
            const data = await response.json();

            if (data.success) {
                renderVagas(data.data.vagas);
            }
        }

        function renderVagas(vagas) {
            const list = document.getElementById('vagas-public-list');
            if (vagas.length === 0) {
                list.innerHTML = '<div style="text-align:center; padding: 3rem;">Nenhuma vaga aberta no momento. Volte em breve!</div>';
                return;
            }

            list.innerHTML = vagas.map(v => {
                const featured = v.tipo_publicacao === 'paga';
                const salario = v.salario_a_combinar == '1' ? 'A combinar' : `R$ ${v.salario_min} - R$ ${v.salario_max}`;

                return `
                <div class="job-card ${featured ? 'featured' : ''}">
                    <img src="${v.logo_url || 'https://via.placeholder.com/80?text=Empresa'}" class="company-logo">
                    <div class="job-info">
                        <h2>${v.titulo} ${featured ? '<span class="featured-badge">PATROCINADA</span>' : ''}</h2>
                        <p class="company-name">${v.company_name} • ${v.cidade || 'Remoto'} / ${v.estado || ''}</p>
                        <div class="job-tags">
                            <span class="tag">${v.modalidade}</span>
                            <span class="tag">${v.regime}</span>
                            <span class="tag">${v.nivel}</span>
                        </div>
                    </div>
                    <div class="job-meta">
                        <span class="salary">${salario}</span>
                        <a href="?thriveo_dashboard=1" class="btn-apply">Candidatar-se</a>
                    </div>
                </div>
            `;
            }).join('');
        }

        loadPublicVagas();

        // Logout logic for public page (simple version as hero.js might not load here)
        document.getElementById('th-btnLogout-public').addEventListener('click', function () {
            localStorage.removeItem('thriveo_token');
            localStorage.removeItem('thriveo_provider');
            window.location.href = '<?php echo home_url(); ?>';
        });

        // Show logout button if token exists
        if (localStorage.getItem('thriveo_token')) {
            document.getElementById('th-btnLogout-public').style.display = 'block';
        }
    </script>

</body>

</html>