<?php
/**
 * Controller for Payments (Mercado Pago / PagSeguro)
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Pagamentos_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        add_action('wp_ajax_nopriv_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        
        add_action('wp_ajax_thriveo_create_subscription', [__CLASS__, 'create_subscription_ajax']);
    }

    /**
     * Retorna a Chave Pública para criptografia no Frontend
     */
    public static function get_public_key()
    {
        // Em um cenário real, o PagBank fornece a pub key via API ou Painel
        // Aqui buscamos das configurações
        $config = Thriveo_AI_Jobs_PagBank_Handler::get_config();
        
        // Simulação de Public Key se não configurada (para não travar o dev)
        $pub_key = get_option('thriveo_pagbank_public_key', 'PUBSB-87A3E891...'); 

        wp_send_json_success([
            'public_key' => $pub_key,
            'environment' => $config['ambiente']
        ]);
    }

    /**
     * Cria a Assinatura (AJAX)
     */
    public static function create_subscription_ajax()
    {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Usuário não autenticado.']);
        }

        $card_encrypted = sanitize_text_field($_POST['card_encrypted']);
        $plano_slug = sanitize_text_field($_POST['plano_slug']);
        $current_user = wp_get_current_user();

        // 1. Verificar se o plano existe no WP
        global $wpdb;
        $tabela_planos = "{$wpdb->prefix}thriveo_pagbank_planos";
        $plano = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabela_planos WHERE slug = %s", $plano_slug));

        // Auto-seed para ambiente de testes inicial
        if (!$plano) {
            $planos_iniciais = [
                ['nome' => 'Básico', 'slug' => 'basico', 'preco_mensal' => 99.00, 'pagbank_plan_id' => 'PLN_BASICO_TEST', 'descricao' => '1 Vaga Adicional'],
                ['nome' => 'Profissional', 'slug' => 'profissional', 'preco_mensal' => 199.00, 'pagbank_plan_id' => 'PLN_PRO_TEST', 'descricao' => '3 Vagas Adicionais + Destaque'],
                ['nome' => 'Enterprise', 'slug' => 'enterprise', 'preco_mensal' => 499.00, 'pagbank_plan_id' => 'PLN_ENT_TEST', 'descricao' => 'Vagas Ilimitadas + Triagem IA']
            ];
            foreach ($planos_iniciais as $p) {
                // Ignore se já existe outro para não dar unique constraint error em multiplas chamadas ajax concorrentes
                $wpdb->insert($tabela_planos, $p);
            }
            // Tenta buscar novamente
            $plano = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabela_planos WHERE slug = %s", $plano_slug));
            
            if (!$plano) {
                wp_send_json_error(['message' => 'Plano inválido e falha ao auto-criar.']);
            }
        }

        // 2. Chamada ao Handler do PagBank
        $tax_id = sanitize_text_field($_POST['tax_id'] ?? '');

        $subscription_data = [
            'pagbank_plan_id' => $plano->pagbank_plan_id,
            'reference_id'    => 'USER_' . $current_user->ID . '_' . time(),
            'customer_name'   => $current_user->display_name,
            'customer_email'  => $current_user->user_email,
            'customer_tax_id' => preg_replace('/[^0-9]/', '', $tax_id),
        ];

        $response = Thriveo_AI_Jobs_PagBank_Handler::criar_assinatura($subscription_data);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'Erro interno de conexão (WP_Error): ' . $response->get_error_message()
            ]);
        }

        if (!$response['success']) {
            $msg = 'Erro desconhecido. ';
            
            if (isset($response['data']['error_messages']) && is_array($response['data']['error_messages'])) {
                $msg = '';
                foreach ($response['data']['error_messages'] as $err) {
                    $msg .= ($err['description'] ?? 'Campo inválido') . ' (' . ($err['parameter_name'] ?? 'N/A') . '); ';
                }
            } else if (isset($response['data']['message'])) {
                $msg = $response['data']['message'];
            } else {
                $msg .= 'Detalhes crus: ' . json_encode($response['data']);
            }
            
            wp_send_json_error([
                'message' => 'Erro no PagBank: ' . $msg,
                'debug' => $response['data']
            ]);
        }

        // Buscar URL de pagamento na resposta
        $payment_link = '';
        if (isset($response['data']['links'])) {
            // PagBank retorna um array de links, procuramos o 'pay' ou 'checkout'
            foreach ($response['data']['links'] as $link) {
                if ($link['rel'] === 'pay' || strpos(strtolower($link['rel']), 'pay') !== false) {
                    $payment_link = $link['href'];
                    break;
                }
            }
        }


        // 3. Salvar Assinatura no Banco (Pendente de Webhook)
        $sub_id = $response['data']['id'];
        $wpdb->insert($wpdb->prefix . 'thriveo_pagbank_assinaturas', [
            'empresa_id' => $current_user->ID, // Vincula ao usuário por enquanto
            'plano_id'   => $plano->id,
            'pagbank_subscription_id' => $sub_id,
            'status'     => 'pendente',
            'criado_em'  => current_time('mysql')
        ]);

        wp_send_json_success([
            'message' => 'Assinatura criada com sucesso! Processando pagamento...',
            'subscription_id' => $sub_id,
            'payment_link' => $payment_link
        ]);
    }

    public static function webhook()
    {
        // Implementação delegada ao arquivo externo ou endpoint REST
    }
}
