<?php
/**
 * Plugin Name: Thriveo AI Jobs Elementor Widget
 * Description: Elementor Hero Widget with LinkedIn and GitHub OAuth integration, plus Talent and Job Board management for AI professionals.
 * Version: 1.5.1
 * Author: Thriveo
 * Text Domain: thriveo-ai-jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

// OpenAI API Standard Key - Protected
if (!defined('THRIVEO_OPENAI_KEY')) {
	define('THRIVEO_OPENAI_KEY', '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');
}

define('THRIVEO_AI_JOBS_VERSION', '1.5.1');
define('THRIVEO_AI_JOBS_DIR', plugin_dir_path(__FILE__));
define('THRIVEO_AI_JOBS_URL', plugin_dir_url(__FILE__));

// --- Configuration Constants ---
// You will need to change these in your production environment
if (!defined('THRIVEO_GITHUB_CLIENT_ID'))
	define('THRIVEO_GITHUB_CLIENT_ID', 'Ov23lix091Zw8Hmi8Hno');
if (!defined('THRIVEO_GITHUB_CLIENT_SECRET'))
	define('THRIVEO_GITHUB_CLIENT_SECRET', 'ef6bb17cd0184d82fd803809088e8e30217eab57');
if (!defined('THRIVEO_LINKEDIN_CLIENT_ID'))
	define('THRIVEO_LINKEDIN_CLIENT_ID', '785etu3l0yvhq5');
if (!defined('THRIVEO_LINKEDIN_CLIENT_SECRET'))
	define('THRIVEO_LINKEDIN_CLIENT_SECRET', 'WPL_AP1.f4sKIrfGgT9xjEfU.GBO50w==');

// In WordPress, we handle the callback via action links. We will build them dynamically later.
if (!defined('THRIVEO_JWT_SECRET'))
	define('THRIVEO_JWT_SECRET', 'TROQUE_ISTO_POR_UMA_CHAVE_LONGA_E_ALEATORIA');

require_once THRIVEO_AI_JOBS_DIR . 'includes/class-db-schema.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-oauth-handler.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-dashboard.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-admin-panel.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-candidatos-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-vagas-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-candidaturas-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-ai-handler.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-score-calculador.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-certificacao-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-testes-tecnicos-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-soft-skills-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-referencias-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-certificado-controller.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-pagbank-handler.php';
require_once THRIVEO_AI_JOBS_DIR . 'includes/class-pagamentos-controller.php';

/**
 * Main Elementor Extension Class
 */
final class Thriveo_AI_Jobs_Extension
{

	private static $_instance = null;

	public static function instance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function __construct()
	{
		add_action('plugins_loaded', [$this, 'init']);
		add_action('init', [$this, 'start_session'], 1);

		// Register activation hook
		register_activation_hook(__FILE__, ['Thriveo_AI_Jobs_DB_Schema', 'create_tables']);
		register_activation_hook(__FILE__, [$this, 'add_ai_manager_role']);
	}

	public function add_ai_manager_role()
	{
		add_role('thriveo_ai_manager', 'Thriveo AI Manager', [
			'read' => true,
			'thriveo_manage_ai' => true,
		]);

		// Also grant this to administrators
		$admin = get_role('administrator');
		if ($admin) {
			$admin->add_cap('thriveo_manage_ai');
		}
	}

	public function start_session()
	{
		if (!session_id()) {
			session_start();
		}
	}

	public function init()
	{
		// Only load if Elementor is installed and activated
		if (!did_action('elementor/loaded')) {
			return;
		}

		// Minimum Elementor Version
		if (!version_compare(ELEMENTOR_VERSION, '3.0.0', '>=')) {
			return;
		}

		// Register callbacks
		add_action('elementor/widgets/register', [$this, 'register_widgets']);
		add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
		add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_scripts']);

		// Initialize Handlers
		Thriveo_AI_Jobs_OAuth_Handler::init();
		Thriveo_AI_Jobs_Admin_Panel::init();
		Thriveo_AI_Jobs_Dashboard::init();
		Thriveo_AI_Jobs_Candidatos_Controller::init();
		Thriveo_AI_Jobs_Vagas_Controller::init();
		Thriveo_AI_Jobs_Candidaturas_Controller::init();
		Thriveo_AI_Jobs_Pagamentos_Controller::init();
	}

	public function enqueue_styles()
	{
		wp_enqueue_style('thriveo-hero-widget-css', THRIVEO_AI_JOBS_URL . 'assets/css/hero.css', [], THRIVEO_AI_JOBS_VERSION);
	}

	public function enqueue_scripts()
	{
		wp_enqueue_script('thriveo-hero-widget-js', THRIVEO_AI_JOBS_URL . 'assets/js/hero.js', ['jquery'], THRIVEO_AI_JOBS_VERSION, true);

		wp_localize_script('thriveo-hero-widget-js', 'thriveoAiObj', [
			'ajaxurl' => admin_url('admin-ajax.php'),
			'oauthNonce' => wp_create_nonce('thriveo_oauth_action')
		]);
	}

	public function register_widgets($widgets_manager)
	{
		require_once THRIVEO_AI_JOBS_DIR . 'includes/elementor/class-hero-widget.php';
		$widgets_manager->register(new \Thriveo_AI_Jobs_Hero_Widget());
	}

}

Thriveo_AI_Jobs_Extension::instance();
