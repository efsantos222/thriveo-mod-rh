<?php
/**
 * Mercado Pago Integration for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_MP {
    public static function init() {
        // Inicialização do Gateway
    }

    public static function criar_preferencia_assinatura($empresa_id, $plano_id) {
        // Lógica para criar checkout do Mercado Pago
        return 'https://www.mercadopago.com.br/';
    }
}
