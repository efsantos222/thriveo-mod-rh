<?php
/**
 * Authentication and Roles for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_Auth {
    
    public static function init() {
        // Bloqueia acesso ao dashboard se não estiver logado
        add_action('template_redirect', [__CLASS__, 'restrict_access']);
        
        // Auto-sincronização do Admin atual
        add_action('admin_init', [__CLASS__, 'auto_sync_admin']);
    }

    public static function setup_roles() {
        // Admin da Empresa (Dono/RH)
        add_role('trh_admin', 'Thriveo RH Empresa Admin', [
            'read' => true
        ]);

        // Gerente (Acesso a departamentos específicos)
        add_role('trh_gerente', 'Thriveo RH Gerente', [
            'read' => true
        ]);

        // Colaborador
        add_role('trh_colaborador', 'Thriveo RH Colaborador', [
            'read' => true
        ]);
        
        // Super Admin (Internal)
        add_role('trh_super_admin', 'Thriveo RH Super Admin', [
            'read' => true,
            'manage_options' => true
        ]);
    }

    public static function auto_sync_admin() {
        if (current_user_can('manage_options')) {
            global $wpdb;
            $user = wp_get_current_user();
            $table = $wpdb->prefix . 'trh_usuarios';
            
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE email = %s", $user->user_email));
            
            if (!$exists) {
                $wpdb->insert($table, [
                    'wp_user_id' => $user->ID,
                    'nome'       => $user->display_name,
                    'email'      => $user->user_email,
                    'senha'      => 'Kyew@1802', // Default synced
                    'role'       => 'trh_super_admin',
                    'status'     => 'ativo'
                ]);
            }
        }
    }

    public static function restrict_access() {
        if (isset($_GET['thriveo_rh']) && !is_user_logged_in()) {
            // Se for admin do WP, deixa passar ou tenta sincronizar
            if (!current_user_can('manage_options')) {
                wp_redirect(wp_login_url(home_url('?thriveo_rh=1')));
                exit;
            }
        }
    }

    /**
     * Retorna os dados do usuário logado na plataforma RH
     */
    public static function get_current_user_data() {
        global $wpdb;
        $user_id = get_current_user_id();
        if (!$user_id) return null;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trh_usuarios WHERE wp_user_id = %d",
            $user_id
        ));
    }
}
