<?php
/**
 * Authentication and Roles for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_Auth {
    
    public static function init() {
        // Bloqueia acesso ao dashboard se não estiver logado
        add_action('template_redirect', [__CLASS__, 'restrict_access']);
    }

    public static function setup_roles() {
        // Admin da Plataforma (Super)
        add_role('trh_super_admin', 'Thriveo RH Super Admin', [
            'read' => true,
            'manage_options' => true
        ]);

        // Admin da Empresa (Dono/RH)
        add_role('trh_admin', 'Thriveo RH Empresa Admin', [
            'read' => true
        ]);

        // Gerente (Acesso a departamentos específicos)
        add_role('trh_gerente', 'Thriveo RH Gerente', [
            'read' => true
        ]);

        // Colaborador
        add_role('trh_colaborador', 'Thriveo RH Colaborador', [
            'read' => true
        ]);
    }

    public static function restrict_access() {
        if (isset($_GET['thriveo_rh']) && !is_user_logged_in()) {
            wp_redirect(wp_login_url(home_url('?thriveo_rh=1')));
            exit;
        }
    }

    /**
     * Retorna os dados do usuário logado na plataforma RH
     */
    public static function get_current_user_data() {
        global $wpdb;
        $user_id = get_current_user_id();
        if (!$user_id) return null;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trh_usuarios WHERE wp_user_id = %d",
            $user_id
        ));
    }
}
