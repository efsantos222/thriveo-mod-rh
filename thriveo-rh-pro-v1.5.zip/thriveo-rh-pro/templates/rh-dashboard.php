<?php
/**
 * Standalone Dashboard Template for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

$user_data = Thriveo_RH_Auth::get_current_user_data();
$is_logged_in = is_user_logged_in();

// Lógica de Login Manual via POST
if (isset($_POST['trh_login_action'])) {
    global $wpdb;
    $email = sanitize_email($_POST['email']);
    $senha = $_POST['password'];
    
    $check = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}trh_usuarios WHERE email = %s AND status = 'ativo'",
        $email
    ));
    
    if ($check && ($senha === $check->senha || (!empty($check->senha) && password_verify($senha, $check->senha)))) {
        if ($check->wp_user_id) {
            wp_set_current_user($check->wp_user_id);
            wp_set_auth_cookie($check->wp_user_id);
            $is_logged_in = true;
            $user_data = $check;
        }
    } else {
        $login_error = "Credenciais inválidas.";
    }
}

if (!$is_logged_in):
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login | Thriveo RH Pro</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { background:#0f172a; display:flex; align-items:center; justify-content:center; height:100vh; font-family:'Plus Jakarta Sans', sans-serif; margin:0; }
        .login-card { background:white; padding:40px; border-radius:16px; width:100%; max-width:400px; box-shadow:0 10px 25px rgba(0,0,0,0.5); }
        .btn-p { width:100%; background:#0052cc; color:white; padding:12px; border:none; border-radius:8px; font-weight:700; cursor:pointer; margin-top:10px; }
        input { width:100%; padding:12px; margin:10px 0 20px; border:1px solid #ddd; border-radius:8px; display:block; box-sizing:border-box; }
        label { font-weight:700; color:#1e293b; font-size:0.9rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2 style="text-align:center; margin-bottom:10px; color:#0f172a;">Thriveo RH Pro</h2>
        <p style="text-align:center; color:#64748b; margin-bottom:30px;">Acessar painel de gestão</p>
        
        <?php if(isset($login_error)) echo "<p style='color:red; text-align:center; font-size:0.9rem;'>$login_error</p>"; ?>
        
        <form method="POST">
            <input type="hidden" name="trh_login_action" value="1">
            <label>E-mail</label>
            <input type="email" name="email" value="ezequiel.santos@gmail.com" required>
            <label>Senha</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn-p">Entrar</button>
        </form>
        <p style="text-align:center; margin-top:20px; font-size:0.85rem; color:#94a3b8;">&copy; <?= date('Y') ?> Thriveo</p>
    </div>
</body>
</html>
<?php 
exit; 
endif;

$tab = $_GET['trh_tab'] ?? 'overview';
$is_super = current_user_can('trh_super_admin') || current_user_can('manage_options');
$emp_id = $user_data ? $user_data->empresa_id : 0;

global $wpdb;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thriveo RH Pro | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --p:#0052cc; --s:#0f172a; --bg:#f8fafc; --sidebar:#1e293b; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Plus Jakarta Sans', sans-serif; background:var(--bg); display:flex; height:100vh; overflow:hidden; }
        
        .sidebar { width:260px; background:var(--sidebar); color:white; padding:30px 20px; display:flex; flex-direction:column; }
        .logo { font-size:1.5rem; font-weight:800; margin-bottom:40px; display:flex; align-items:center; gap:10px; }
        .logo span { color:var(--p); }
        
        .nav-item { display:flex; align-items:center; gap:12px; padding:12px 15px; color:#94a3b8; text-decoration:none; border-radius:8px; margin-bottom:5px; transition:0.3s; }
        .nav-item:hover, .nav-item.active { background:rgba(255,255,255,0.05); color:white; }
        .nav-item.active { border-left:4px solid var(--p); }

        .main { flex:1; padding:40px; overflow-y:auto; }
        .header { display:flex; justify-content:space-between; align-items:center; margin-bottom:40px; }
        
        .card { background:white; padding:30px; border-radius:16px; box-shadow:0 10px 15px -3px rgba(0,0,0,0.05); margin-bottom:30px; }
        .btn { padding:10px 20px; border-radius:8px; font-weight:600; cursor:pointer; border:none; text-decoration:none; display:inline-flex; align-items:center; gap:8px; }
        .btn-p { background:var(--p); color:white; }
        .btn-icon { background:none; color:var(--p); cursor:pointer; border:none; font-size:1.1rem; }
        
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        th { text-align:left; padding:15px; color:#64748b; font-size:0.85rem; border-bottom:2px solid #f1f5f9; }
        td { padding:15px; border-bottom:1px solid #f1f5f9; font-size:0.95rem; }
        
        .badge { display:inline-block; padding:4px 10px; border-radius:20px; font-size:0.8rem; font-weight:700; background:#f1f5f9; color:#475569; }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo">Thriveo<span>RH</span></div>
        <nav style="flex:1;">
            <a href="?thriveo_rh=1&trh_tab=overview" class="nav-item <?= $tab=='overview'?'active':'' ?>"><i class="fas fa-chart-line"></i> Início</a>
            <?php if ($is_super): ?>
                <a href="?thriveo_rh=1&trh_tab=companies" class="nav-item <?= $tab=='companies'?'active':'' ?>"><i class="fas fa-building"></i> Empresas</a>
            <?php endif; ?>
            <a href="?thriveo_rh=1&trh_tab=disc" class="nav-item <?= $tab=='disc'?'active':'' ?>"><i class="fas fa-brain"></i> DISC</a>
            <a href="?thriveo_rh=1&trh_tab=zbb" class="nav-item <?= $tab=='zbb'?'active':'' ?>"><i class="fas fa-wallet"></i> Orçamentos</a>
            <a href="?thriveo_rh=1&trh_tab=pdi" class="nav-item <?= $tab=='pdi'?'active':'' ?>"><i class="fas fa-user-graduate"></i> Metas PDI</a>
        </nav>
        <div style="margin-top:auto;">
            <a href="<?= wp_logout_url(home_url()) ?>" class="nav-item" style="color:#ef4444;"><i class="fas fa-sign-out-alt"></i> Sair</a>
        </div>
    </aside>

    <main class="main">
        <div class="header">
            <div>
                <h1 style="color:var(--s);">Olá, <?= wp_get_current_user()->display_name ?></h1>
                <p style="color:#64748b;">Bem-vindo ao Thriveo RH Pro.</p>
            </div>
            <div class="user-info">
                   <div class="badge" style="background:#0052cc; color:white;"><?= ($user_data ? $user_data->role : 'Admin') ?></div>
            </div>
        </div>

        <?php if ($tab == 'overview'): ?>
            <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:20px;">
                <div class="card">
                    <h3 style="color:#64748b; font-size:1rem; margin-bottom:15px;">Avaliações DISC</h3>
                    <div style="font-size:2.5rem; font-weight:800; color:var(--s);">0</div>
                </div>
                <div class="card">
                    <h3 style="color:#64748b; font-size:1rem; margin-bottom:15px;">Saldo Orçado ZBB</h3>
                    <div style="font-size:2.5rem; font-weight:800; color:var(--s);">R$ 0,00</div>
                </div>
                <div class="card">
                    <h3 style="color:#64748b; font-size:1rem; margin-bottom:15px;">Metas PDI Ativas</h3>
                    <div style="font-size:2.5rem; font-weight:800; color:var(--s);">0</div>
                </div>
            </div>

        <?php elseif ($tab == 'disc'): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Relatórios DISC</h2>
                </div>
                <table>
                    <thead><tr><th>Data</th><th>Colaborador</th><th>E-mail</th><th>Perfil</th><th>Ações</th></tr></thead>
                    <tbody>
                        <?php 
                        $res = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_disc_results WHERE empresa_id = %d ORDER BY concluido_em DESC", $emp_id));
                        if($res): foreach($res as $r): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($r->concluido_em)) ?></td>
                            <td><strong><?= esc_html($r->nome) ?></strong></td>
                            <td><?= esc_html($r->email) ?></td>
                            <td><span class="badge" style="background:var(--p); color:white;"><?= $r->perfil ?></span></td>
                            <td><button class="btn-icon"><i class="fas fa-file-pdf"></i></button></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:40px; color:#94a3b8;">Nenhum resultado encontrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'zbb'): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Gestão de Orçamento (ZBB)</h2>
                    <button class="btn btn-p"><i class="fas fa-plus"></i> Novo Lançamento</button>
                </div>
                <table>
                    <thead><tr><th>Mês/Ano</th><th>Previsto</th><th>Realizado</th><th>Variação</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php 
                        $budgets = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_zbb_budgets WHERE empresa_id = %d ORDER BY ano DESC, mes DESC", $emp_id));
                        if($budgets): foreach($budgets as $b): 
                            $diff = $b->planejado - $b->realizado;
                        ?>
                        <tr>
                            <td><?= sprintf('%02d/%d', $b->mes, $b->ano) ?></td>
                            <td>R$ <?= number_format($b->planejado, 2, ',', '.') ?></td>
                            <td>R$ <?= number_format($b->realizado, 2, ',', '.') ?></td>
                            <td style="color: <?= $diff >= 0 ? '#10b981' : '#ef4444' ?>; font-weight:700;">R$ <?= number_format($diff, 2, ',', '.') ?></td>
                            <td><span class="badge"><?= $b->status ?></span></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:40px; color:#94a3b8;">Nenhum lançamento registrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'pdi'): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Plano de Desenvolvimento Individual (PDI)</h2>
                    <button class="btn btn-p"><i class="fas fa-plus"></i> Nova Meta</button>
                </div>
                <table>
                    <thead><tr><th>Colaborador</th><th>Objetivo/Meta</th><th>Prazo Final</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php 
                        $pdis = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_pdi WHERE empresa_id = %d", $emp_id));
                        if($pdis): foreach($pdis as $p): ?>
                        <tr>
                            <td><strong>Usuário ID #<?= $p->user_id ?></strong></td>
                            <td><?= esc_html($p->meta) ?></td>
                            <td><?= date('d/m/Y', strtotime($p->prazo)) ?></td>
                            <td><span class="badge"><?= $p->status ?></span></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="4" style="text-align:center; padding:40px; color:#94a3b8;">Nenhum PDI cadastrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'companies' && $is_super): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Empresas do Ecossistema</h2>
                    <button class="btn btn-p" onclick="document.getElementById('modalComp').style.display='flex'"><i class="fas fa-plus"></i> Cadastrar Nova</button>
                </div>
                <table>
                    <thead><tr><th>Nome Fantasia</th><th>Status</th><th>Expiração Trial</th><th>Ações</th></tr></thead>
                    <tbody>
                        <?php 
                        $comps = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trh_empresas ORDER BY criado_em DESC");
                        if($comps): foreach($comps as $c): ?>
                        <tr>
                            <td><strong><?= esc_html($c->nome_fantasia) ?></strong></td>
                            <td><span class="badge" style="background:<?= $c->status=='ativo'?'#dcfce7':'#fee2e2' ?>; color:<?= $c->status=='ativo'?'#166534':'#991b1b' ?>;"><?= strtoupper($c->status) ?></span></td>
                            <td><?= $c->trial_ends_at ? date('d/m/Y', strtotime($c->trial_ends_at)) : '-' ?></td>
                            <td><button class="btn-icon"><i class="fas fa-ellipsis-v"></i></button></td>
                        </tr>
                        <?php endforeach; else: ?>
                                <tr><td colspan="4" style="text-align:center; padding:40px; color:#94a3b8;">Nenhuma empresa cadastrada.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Modal -->
            <div id="modalComp" style="display:none; position:fixed; inset:0; background:rgba(15, 23, 42, 0.8); align-items:center; justify-content:center; z-index:10000; backdrop-filter:blur(4px);">
                <div style="background:white; padding:40px; border-radius:20px; width:100%; max-width:450px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);">
                    <h3 style="margin-bottom:25px; font-size:1.5rem;">Nova Empresa</h3>
                    <form method="POST">
                        <input type="hidden" name="trh_action" value="register_company">
                        <label>Nome da Empresa (Fantasia)</label>
                        <input type="text" name="company_name" placeholder="Ex: Thriveo Tech" required>
                        <label>E-mail do Administrador</label>
                        <input type="email" name="email" placeholder="rh@empresa.com" required>
                        <p style="font-size:0.8rem; color:#64748b; margin-bottom:20px;">* A senha padrão será enviada para o e-mail: <strong>Kyew@1802</strong></p>
                        <div style="display:flex; gap:10px; justify-content:flex-end;">
                            <button type="button" class="btn" style="background:#f1f5f9;" onclick="document.getElementById('modalComp').style.display='none'">Cancelar</button>
                            <button type="submit" class="btn btn-p">Criar Empresa</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
