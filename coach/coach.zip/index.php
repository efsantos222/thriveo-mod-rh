<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Plataforma de Coaching profissional para desenvolvimento pessoal e profissional">
    <meta name="keywords" content="coaching, desenvolvimento profissional, carreira, DISC, MBTI">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#3a7bd5">
    <title>Plataforma de Coaching - Cresça e Evolua</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            color: #fff;
            background: linear-gradient(120deg, #3a7bd5, #00d2ff);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            text-align: center;
            line-height: 1.6;
        }

        .container {
            padding: 20px;
            max-width: 800px;
            width: 90%;
        }

        h1 {
            font-size: clamp(32px, 5vw, 48px);
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
            animation: fadeInDown 2s;
            margin-bottom: 20px;
        }

        p {
            font-size: clamp(16px, 2.5vw, 20px);
            max-width: 600px;
            margin: 20px auto;
            animation: fadeInUp 2s;
        }

        .btn-login {
            display: inline-block;
            margin-top: 40px;
            padding: 15px 35px;
            background-color: #ffffff;
            color: #3a7bd5;
            border: none;
            border-radius: 30px;
            font-size: clamp(14px, 2vw, 16px);
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            background-color: #f8f9fa;
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .footer-message {
            position: fixed;
            bottom: 20px;
            font-size: clamp(12px, 1.5vw, 14px);
            opacity: 0.9;
            padding: 10px;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-height: 500px) {
            .footer-message {
                position: static;
                margin-top: 30px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Plataforma de Coaching</h1>
        <p>Desenvolva suas competências, alcance seus objetivos e impulsione sua carreira. Sua transformação começa aqui!</p>

        <a href="auth/login.php" class="btn-login">Acesse Agora</a>

        <div class="footer-message">Apoio e evolução constante para você e sua equipe.</div>
    </div>
</body>

</html>
