<?php
session_start();
require_once '../../config/database.php';

// Verificar se o usuário está logado e é administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_profile'] !== 'administrador') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

// Obter dados do corpo da requisição
$data = json_decode(file_get_contents('php://input'), true);

// Validar dados obrigatórios
if (!isset($data['nome']) || !isset($data['email']) || !isset($data['senha']) || !isset($data['perfil'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
    exit;
}

try {
    $config = require '../../config/database.php';
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);

    // Verificar se o email já existe
    $stmt = $pdo->prepare('SELECT id_usuario FROM usuarios WHERE email = ?');
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'E-mail já cadastrado']);
        exit;
    }

    // Inserir novo usuário
    $stmt = $pdo->prepare('
        INSERT INTO usuarios (nome, email, senha, perfil, data_criacao)
        VALUES (?, ?, ?, ?, NOW())
    ');

    $stmt->execute([
        $data['nome'],
        $data['email'],
        $data['senha'], // Senha sem hash conforme solicitado
        $data['perfil']
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Usuário criado com sucesso',
        'id' => $pdo->lastInsertId()
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao criar usuário']);
}
