<?php
session_start();
require_once '../../config/database.php';

// Verificar se o usuário está logado e é administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_profile'] !== 'administrador') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

try {
    $config = require '../../config/database.php';
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);

    // Buscar todos os usuários exceto o próprio administrador
    $query = '
        SELECT 
            id_usuario,
            nome,
            email,
            perfil,
            data_criacao
        FROM usuarios
        WHERE id_usuario != ?
        ORDER BY nome ASC
    ';

    $stmt = $pdo->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $users,
        'debug' => [
            'query' => $query,
            'params' => [$_SESSION['user_id']],
            'user_id' => $_SESSION['user_id'],
            'user_profile' => $_SESSION['user_profile']
        ]
    ]);

} catch (PDOException $e) {
    error_log("Erro ao listar usuários: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Erro ao listar usuários: ' . $e->getMessage(),
        'debug' => [
            'error_code' => $e->getCode(),
            'error_file' => $e->getFile(),
            'error_line' => $e->getLine()
        ]
    ]);
}
