// Carregar usuários ao iniciar a página
document.addEventListener('DOMContentLoaded', loadUsers);

// Adicionar event listeners para filtros
document.getElementById('searchUser').addEventListener('input', filterUsers);
document.getElementById('filterProfile').addEventListener('change', filterUsers);

// Função para carregar usuários
async function loadUsers() {
    try {
        const response = await fetch('../api/users/list.php');
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.message || 'Erro ao carregar usuários');
        }

        displayUsers(result.data);
    } catch (error) {
        const grid = document.getElementById('usersGrid');
        grid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>${error.message}</p>
            </div>
        `;
    }
}

// Função para exibir usuários
function displayUsers(users) {
    const grid = document.getElementById('usersGrid');
    
    if (!users || users.length === 0) {
        grid.innerHTML = `
            <div class="no-users">
                <i class="fas fa-users"></i>
                <p>Nenhum usuário encontrado</p>
            </div>
        `;
        return;
    }
    
    const usersHTML = users.map(user => `
        <div class="user-card ${user.perfil.toLowerCase()}" data-name="${user.nome.toLowerCase()}" data-profile="${user.perfil.toLowerCase()}">
            <div class="user-header">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <h3 class="user-name">${user.nome}</h3>
                    <span class="user-profile">${user.perfil}</span>
                </div>
            </div>
            <div class="user-body">
                <div class="user-email">
                    <i class="fas fa-envelope"></i>
                    ${user.email}
                </div>
                <div class="user-created">
                    <i class="fas fa-calendar"></i>
                    Criado em: ${new Date(user.data_criacao).toLocaleDateString('pt-BR')}
                </div>
            </div>
            <div class="user-actions">
                <button class="btn-edit" onclick="editUser(${user.id_usuario})">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn-delete" onclick="deleteUser(${user.id_usuario})">
                    <i class="fas fa-trash"></i> Excluir
                </button>
            </div>
        </div>
    `).join('');
    
    grid.innerHTML = usersHTML;
}

// Função para filtrar usuários
function filterUsers() {
    const searchTerm = document.getElementById('searchUser').value.toLowerCase();
    const profileFilter = document.getElementById('filterProfile').value.toLowerCase();
    const cards = document.querySelectorAll('.user-card');
    
    cards.forEach(card => {
        const name = card.dataset.name;
        const profile = card.dataset.profile;
        const matchesSearch = name.includes(searchTerm);
        const matchesProfile = !profileFilter || profile === profileFilter;
        
        card.style.display = matchesSearch && matchesProfile ? 'flex' : 'none';
    });
}

// Função para abrir modal de novo usuário
function openNewUserModal() {
    // Implementar depois
    alert('Em desenvolvimento');
}

// Função para editar usuário
function editUser(userId) {
    // Implementar depois
    alert('Em desenvolvimento: Editar usuário ' + userId);
}

// Função para deletar usuário
async function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este usuário?')) {
        return;
    }

    try {
        const response = await fetch('../api/users/delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: userId })
        });

        const result = await response.json();

        if (result.success) {
            // Recarregar a lista de usuários
            loadUsers();
        } else {
            throw new Error(result.message || 'Erro ao excluir usuário');
        }
    } catch (error) {
        alert(error.message);
    }
}

// Funções do modal
function openNewUserModal() {
    document.getElementById('newUserModal').style.display = 'block';
}

function closeNewUserModal() {
    document.getElementById('newUserModal').style.display = 'none';
    document.getElementById('newUserForm').reset();
}

// Função para submeter novo usuário
function submitNewUser(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const userData = {
        nome: formData.get('nome'),
        email: formData.get('email'),
        senha: formData.get('senha'),
        perfil: formData.get('perfil')
    };
    
    fetch('../api/users/create.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showMessage('Usuário criado com sucesso!', 'success');
            closeNewUserModal();
            loadUsers();
        } else {
            showMessage(data.message || 'Erro ao criar usuário.', 'error');
        }
    })
    .catch(error => {
        showMessage('Erro ao criar usuário.', 'error');
    });
    
    return false;
}

// Função para exibir mensagens
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;
    
    const header = document.querySelector('.dashboard-header');
    header.insertAdjacentElement('afterend', messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}
