<?php
/**
 * Database Schema for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_DB {
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // 1. Empresas (Multi-tenancy primary table)
        $table_empresas = $wpdb->prefix . 'trh_empresas';
        $sql_empresas = "CREATE TABLE $table_empresas (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nome_fantasia VARCHAR(200) NOT NULL,
            razao_social VARCHAR(200),
            cnpj VARCHAR(20),
            status VARCHAR(20) DEFAULT 'ativo',
            trial_ends_at DATETIME,
            max_users INT DEFAULT 5,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 2. Usuarios da Plataforma (Link entre WP User e Empresa)
        $table_users = $wpdb->prefix . 'trh_usuarios';
        $sql_users = "CREATE TABLE $table_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            wp_user_id BIGINT(20) UNSIGNED NOT NULL,
            empresa_id INT UNSIGNED,
            role VARCHAR(30) NOT NULL, -- trh_super_admin, trh_admin, trh_colaborador
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY wp_user_id (wp_user_id)
        ) $charset_collate;";

        // 3. DISC Results
        $table_disc = $wpdb->prefix . 'trh_disc_results';
        $sql_disc = "CREATE TABLE $table_disc (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            nome VARCHAR(200) NOT NULL,
            email VARCHAR(200) NOT NULL,
            scores_json TEXT NOT NULL,
            perfil VARCHAR(10),
            concluido_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 4. ZBB (Budgets)
        $table_zbb = $wpdb->prefix . 'trh_zbb_budgets';
        $sql_zbb = "CREATE TABLE $table_zbb (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            cc_id INT UNSIGNED,
            cat_id INT UNSIGNED,
            mes TINYINT(2),
            ano SMALLINT(4),
            planejado DECIMAL(15,2),
            realizado DECIMAL(15,2),
            status VARCHAR(20) DEFAULT 'pendente',
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // 5. PDI
        $table_pdi = $wpdb->prefix . 'trh_pdi';
        $sql_pdi = "CREATE TABLE $table_pdi (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            empresa_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            meta TEXT NOT NULL,
            prazo DATE,
            status VARCHAR(20) DEFAULT 'em_andamento',
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql_empresas);
        dbDelta($sql_users);
        dbDelta($sql_disc);
        dbDelta($sql_zbb);
        dbDelta($sql_pdi);
    }
}
