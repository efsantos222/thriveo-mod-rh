<?php
/**
 * Admin Panel and Manual Registration for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_Admin {
    
    public static function init() {
        add_action('wp_footer', [__CLASS__, 'render_dashboard_trigger']);
        add_filter('query_vars', [__CLASS__, 'add_query_vars']);
        add_action('template_include', [__CLASS__, 'load_dashboard_template']);
        add_action('init', [__CLASS__, 'handle_form_submissions']);
    }

    public static function add_query_vars($vars) {
        $vars[] = 'thriveo_rh';
        $vars[] = 'trh_tab';
        return $vars;
    }

    public static function load_dashboard_template($template) {
        if (get_query_var('thriveo_rh')) {
            $dashboard = THRIVEO_RH_PATH . 'templates/rh-dashboard.php';
            if (file_exists($dashboard)) return $dashboard;
        }
        return $template;
    }

    public static function handle_form_submissions() {
        if (!isset($_POST['trh_action'])) return;
        global $wpdb;

        // Cadastro Manual de Empresa (Apenas Super Admin)
        if ($_POST['trh_action'] === 'register_company' && current_user_can('trh_super_admin')) {
            $email = sanitize_email($_POST['email']);
            $name = sanitize_text_field($_POST['company_name']);
            $password = 'Kyew@1802';

            $user_id = wp_create_user($email, $password, $email);
            if (!is_wp_error($user_id)) {
                $user = new WP_User($user_id);
                $user->set_role('trh_admin');

                $wpdb->insert($wpdb->prefix . 'trh_empresas', [
                    'nome_fantasia' => $name,
                    'status' => 'ativo',
                    'trial_ends_at' => date('Y-m-d H:i:s', strtotime('+30 days'))
                ]);
                $empresa_id = $wpdb->insert_id;

                $wpdb->insert($wpdb->prefix . 'trh_usuarios', [
                    'wp_user_id' => $user_id,
                    'empresa_id' => $empresa_id,
                    'role' => 'trh_admin'
                ]);
            }
        }
    }

    public static function render_dashboard_trigger() {
        if (current_user_can('trh_super_admin') || current_user_can('trh_admin')) {
            echo '<a href="' . home_url('?thriveo_rh=1') . '" style="position:fixed; bottom:20px; right:20px; background:#0052cc; color:white; padding:10px 20px; border-radius:50px; text-decoration:none; box-shadow:0 4px 10px rgba(0,0,0,0.2); z-index:9999; font-weight:700;"><i class="fas fa-rocket"></i> Painel RH Pro</a>';
        }
    }
}
