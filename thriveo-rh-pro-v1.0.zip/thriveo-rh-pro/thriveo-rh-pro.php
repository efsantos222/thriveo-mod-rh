<?php
/**
 * Plugin Name: Thriveo RH Pro
 * Description: Sistema completo de Gestão de RH (DISC, ZBB, PDI) com integração Mercado Pago.
 * Version: 1.0.0
 * Author: Thriveo
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

// Definição de constantes
define('THRIVEO_RH_PATH', plugin_dir_path(__FILE__));
define('THRIVEO_RH_URL', plugin_dir_url(__FILE__));
define('THRIVEO_RH_VERSION', '1.0.0');

// Autoload de classes (simples para este projeto)
require_once THRIVEO_RH_PATH . 'includes/class-rh-db.php';
require_once THRIVEO_RH_PATH . 'includes/class-rh-auth.php';
require_once THRIVEO_RH_PATH . 'includes/class-rh-admin.php';
require_once THRIVEO_RH_PATH . 'includes/class-rh-mp.php';

/**
 * Inicialização do Plugin
 */
class Thriveo_RH_Pro {
    public function __construct() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('init', [$this, 'init']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public static function activate() {
        Thriveo_RH_DB::create_tables();
        Thriveo_RH_Auth::setup_roles();
    }

    public function init() {
        // Inicialização de componentes
        Thriveo_RH_Auth::init();
        Thriveo_RH_Admin::init();
    }

    public function enqueue_assets() {
        wp_enqueue_style('thriveo-rh-style', THRIVEO_RH_URL . 'assets/css/rh-style.css', [], THRIVEO_RH_VERSION);
        wp_enqueue_script('thriveo-rh-js', THRIVEO_RH_URL . 'assets/js/rh-main.js', ['jquery'], THRIVEO_RH_VERSION, true);
    }
}

new Thriveo_RH_Pro();
