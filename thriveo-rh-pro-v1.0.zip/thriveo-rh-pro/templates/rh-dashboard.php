<?php
/**
 * Standalone Dashboard Template for Thriveo RH Pro
 */

if (!defined('ABSPATH')) exit;

$user_data = Thriveo_RH_Auth::get_current_user_data();
$tab = $_GET['trh_tab'] ?? 'overview';
$is_super = current_user_can('trh_super_admin');
$emp_id = $user_data ? $user_data->empresa_id : 0;

global $wpdb;

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thriveo RH Pro | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --p:#0052cc; --s:#0f172a; --bg:#f8fafc; --sidebar:#1e293b; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Plus Jakarta Sans', sans-serif; background:var(--bg); display:flex; height:100vh; overflow:hidden; }
        
        .sidebar { width:260px; background:var(--sidebar); color:white; padding:30px 20px; }
        .logo { font-size:1.5rem; font-weight:800; margin-bottom:40px; display:flex; align-items:center; gap:10px; }
        .logo span { color:var(--p); }
        
        .nav-item { display:flex; align-items:center; gap:12px; padding:12px 15px; color:#94a3b8; text-decoration:none; border-radius:8px; margin-bottom:5px; transition:0.3s; }
        .nav-item:hover, .nav-item.active { background:rgba(255,255,255,0.05); color:white; }
        .nav-item.active { border-left:4px solid var(--p); }

        .main { flex:1; padding:40px; overflow-y:auto; }
        .header { display:flex; justify-content:space-between; align-items:center; margin-bottom:40px; }
        
        .card { background:white; padding:30px; border-radius:16px; box-shadow:0 10px 15px -3px rgba(0,0,0,0.05); margin-bottom:30px; }
        .btn { padding:10px 20px; border-radius:8px; font-weight:600; cursor:pointer; border:none; text-decoration:none; display:inline-flex; align-items:center; gap:8px; }
        .btn-p { background:var(--p); color:white; }
        
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        th { text-align:left; padding:15px; color:#64748b; font-size:0.85rem; border-bottom:2px solid #f1f5f9; }
        td { padding:15px; border-bottom:1px solid #f1f5f9; font-size:0.95rem; }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo">Thriveo<span>RH</span></div>
        <nav>
            <a href="?thriveo_rh=1&trh_tab=overview" class="nav-item <?= $tab=='overview'?'active':'' ?>"><i class="fas fa-chart-line"></i> Início</a>
            <?php if ($is_super): ?>
                <a href="?thriveo_rh=1&trh_tab=companies" class="nav-item <?= $tab=='companies'?'active':'' ?>"><i class="fas fa-building"></i> Empresas</a>
            <?php endif; ?>
            <a href="?thriveo_rh=1&trh_tab=disc" class="nav-item <?= $tab=='disc'?'active':'' ?>"><i class="fas fa-brain"></i> DISC</a>
            <a href="?thriveo_rh=1&trh_tab=zbb" class="nav-item <?= $tab=='zbb'?'active':'' ?>"><i class="fas fa-wallet"></i> ZBB</a>
            <a href="?thriveo_rh=1&trh_tab=pdi" class="nav-item <?= $tab=='pdi'?'active':'' ?>"><i class="fas fa-user-graduate"></i> PDI</a>
            <hr style="margin:20px 0; opacity:0.1;">
            <a href="<?= wp_logout_url(home_url()) ?>" class="nav-item" style="color:#ef4444;"><i class="fas fa-sign-out-alt"></i> Sair</a>
        </nav>
    </aside>

    <main class="main">
        <div class="header">
            <div>
                <h1>Olá, <?= wp_get_current_user()->display_name ?></h1>
                <p style="color:#64748b;">Bem-vindo ao Thriveo RH Pro.</p>
            </div>
        </div>

        <?php if ($tab == 'overview'): ?>
            <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:20px;">
                <div class="card"><h3>Candidatos DISC</h3><div style="font-size:2rem; font-weight:800;">0</div></div>
                <div class="card"><h3>Orçamento ZBB</h3><div style="font-size:2rem; font-weight:800;">R$ 0,00</div></div>
                <div class="card"><h3>Metas PDI</h3><div style="font-size:2rem; font-weight:800;">0</div></div>
            </div>

        <?php elseif ($tab == 'disc'): ?>
            <div class="card">
                <h2>Resultados DISC</h2>
                <table>
                    <thead><tr><th>Data</th><th>Colaborador</th><th>E-mail</th><th>Perfil</th><th>Ações</th></tr></thead>
                    <tbody>
                        <?php 
                        $res = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_disc_results WHERE empresa_id = %d ORDER BY concluido_em DESC", $emp_id));
                        foreach($res as $r): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($r->concluido_em)) ?></td>
                            <td><strong><?= esc_html($r->nome) ?></strong></td>
                            <td><?= esc_html($r->email) ?></td>
                            <td><span style="background:var(--p); color:white; padding:4px 8px; border-radius:4px;"><?= $r->perfil ?></span></td>
                            <td><button class="btn btn-icon"><i class="fas fa-file-pdf"></i></button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'zbb'): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h2>Zero-Based Budgeting</h2>
                    <button class="btn btn-p">+ Novo Lançamento</button>
                </div>
                <table>
                    <thead><tr><th>Mês/Ano</th><th>Previsto</th><th>Realizado</th><th>Diferença</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php 
                        $budgets = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_zbb_budgets WHERE empresa_id = %d ORDER BY ano DESC, mes DESC", $emp_id));
                        foreach($budgets as $b): 
                            $diff = $b->planejado - $b->realizado;
                        ?>
                        <tr>
                            <td><?= sprintf('%02d/%d', $b->mes, $b->ano) ?></td>
                            <td>R$ <?= number_format($b->planejado, 2, ',', '.') ?></td>
                            <td>R$ <?= number_format($b->realizado, 2, ',', '.') ?></td>
                            <td style="color: <?= $diff >= 0 ? 'green' : 'red' ?>">R$ <?= number_format($diff, 2, ',', '.') ?></td>
                            <td><?= $b->status ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'pdi'): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h2>Plano de Desenvolvimento (PDI)</h2>
                    <button class="btn btn-p">+ Nova Meta</button>
                </div>
                <table>
                    <thead><tr><th>Colaborador</th><th>Objetivo</th><th>Prazo</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php 
                        $pdis = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}trh_pdi WHERE empresa_id = %d", $emp_id));
                        foreach($pdis as $p): ?>
                        <tr>
                            <td>Usuário ID #<?= $p->user_id ?></td>
                            <td><?= esc_html($p->meta) ?></td>
                            <td><?= date('d/m/Y', strtotime($p->prazo)) ?></td>
                            <td><?= $p->status ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($tab == 'companies' && $is_super): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h2>Empresas Licenciadas</h2>
                    <button class="btn btn-p" onclick="document.getElementById('modalComp').style.display='flex'">+ Nova Empresa</button>
                </div>
                <table>
                    <thead><tr><th>Empresa</th><th>Status</th><th>Trial Até</th><th>Ações</th></tr></thead>
                    <tbody>
                        <?php 
                        $comps = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trh_empresas ORDER BY criado_em DESC");
                        foreach($comps as $c): ?>
                        <tr>
                            <td><strong><?= esc_html($c->nome_fantasia) ?></strong></td>
                            <td><?= $c->status ?></td>
                            <td><?= date('d/m/Y', strtotime($c->trial_ends_at)) ?></td>
                            <td><button class="btn btn-icon"><i class="fas fa-edit"></i></button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Modal Simples -->
            <div id="modalComp" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); align-items:center; justify-content:center;">
                <div style="background:white; padding:30px; border-radius:12px; width:400px;">
                    <h3>Cadastrar Empresa</h3>
                    <form method="POST" style="margin-top:20px;">
                        <input type="hidden" name="trh_action" value="register_company">
                        <label>Nome Fantasia</label>
                        <input type="text" name="company_name" required style="width:100%; padding:10px; margin-bottom:15px; border:1px solid #ddd; border-radius:6px;">
                        <label>E-mail (Login)</label>
                        <input type="email" name="email" required style="width:100%; padding:10px; margin-bottom:20px; border:1px solid #ddd; border-radius:6px;">
                        <div style="text-align:right;">
                            <button type="button" class="btn" onclick="this.parentElement.parentElement.parentElement.parentElement.style.display='none'">Cancelar</button>
                            <button type="submit" class="btn btn-p">Salvar</button>
                        </div>
                    </form>
                </div>
            </div>

        <?php endif; ?>
    </main>
</body>
</html>
