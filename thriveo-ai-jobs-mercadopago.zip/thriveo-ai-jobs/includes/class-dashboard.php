<?php
/**
 * Dashboard Handler for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Dashboard
{
    public static function init()
    {
        // Intercept template redirect to load our custom dashboard PHP file
        add_action('template_redirect', [__CLASS__, 'load_dashboard_template']);
    }

    public static function load_dashboard_template()
    {
        // 1. Personal Candidate Dashboard (Profile)
        if (isset($_GET['thriveo_dashboard']) && $_GET['thriveo_dashboard'] == '1') {
            self::render_template('dashboard.php');
        }

        // 2. Talent Bank (Admin / Employer view of candidates)
        if (isset($_GET['thriveo_talentos']) && $_GET['thriveo_talentos'] == '1') {
            self::render_template('talentos.php');
        }

        // 3. Employer Job Management
        if (isset($_GET['thriveo_empresa_vagas']) && $_GET['thriveo_empresa_vagas'] == '1') {
            if (isset($_GET['mp_status']) && $_GET['mp_status'] === 'success' && !empty($_GET['payment_id'])) {
                Thriveo_AI_Jobs_Pagamentos_Controller::verificar_pagamento_sincrono($_GET['payment_id']);
            }
            self::render_template('empresa-vagas.php');
        }

        // 4. Public Job Board
        if (isset($_GET['thriveo_vagas']) && $_GET['thriveo_vagas'] == '1') {
            self::render_template('public-vagas.php');
        }

        // 5. Certification Dashboard
        if (isset($_GET['thriveo_certificacoes']) && $_GET['thriveo_certificacoes'] == '1') {
            self::render_template('certificacoes.php');
        }

        // 6. Test Environment (M2: Avaliação Técnica)
        if (isset($_GET['thriveo_teste'])) {
            self::render_template('teste-ambiente.php');
        }

        // 7. Soft Skills Assessment
        if (isset($_GET['thriveo_softskills'])) {
            self::render_template('softskills.php');
        }

        // 8. References Management
        if (isset($_GET['thriveo_referencias'])) {
            self::render_template('referencias.php');
        }

        // 9. Public Certificate Verification
        if (isset($_GET['thriveo_verificar'])) {
            self::render_template('verificar-certificado.php');
        }

        // 10. M1: Trilhas de Aprendizagem
        if (isset($_GET['thriveo_trilhas'])) {
            if (isset($_GET['trilha_id'])) {
                self::render_template('trilha-detalhe.php');
            } else {
                self::render_template('trilhas.php');
            }
        }

        // 11. M3: Matching Inteligente
        if (isset($_GET['thriveo_matching'])) {
            self::render_template('matching.php');
        }

        // 12. M4: Entrevista com IA
        if (isset($_GET['thriveo_entrevista'])) {
            self::render_template('entrevista.php');
        }
    }

    private static function render_template($file)
    {
        $template_path = THRIVEO_AI_JOBS_DIR . 'templates/' . $file;
        if (file_exists($template_path)) {
            status_header(200);
            include($template_path);
            exit;
        }
    }
}
