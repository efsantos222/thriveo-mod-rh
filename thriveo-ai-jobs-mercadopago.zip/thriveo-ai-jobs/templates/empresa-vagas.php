<?php
/**
 * Company Jobs Management Template
 */
if (!defined('ABSPATH'))
    exit;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Vagas - Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1a2e4a;
            --accent: #00c896;
            --bg: #f5f7fa;
            --white: #ffffff;
            --text: #334e68;
            --text-light: #627d98;
            --navy: #102a43;
            --danger: #ef4444;
            --warning: #f59e0b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
        }

        .app-container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        /* Sidebar similar to talentos.php */
        aside {
            background: var(--primary);
            color: var(--white);
            padding: 2rem;
            position: sticky;
            top: 0;
            height: 100vh;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo i {
            color: var(--accent);
        }

        .nav-menu {
            list-style: none;
        }

        .nav-menu li {
            margin-bottom: 1rem;
        }

        .nav-menu a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 8px;
            transition: 0.3s;
        }

        .nav-menu a:hover,
        .nav-menu a.active {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
        }

        main {
            padding: 3rem;
        }

        /* Quota Section */
        .quota-card {
            background: var(--white);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            margin-bottom: 3rem;
            border: 1px solid #e2e8f0;
        }

        .quota-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .quota-header h2 {
            font-size: 1.2rem;
            color: var(--navy);
        }

        .quota-progress {
            background: #edf2f7;
            height: 12px;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }

        .quota-fill {
            background: var(--accent);
            height: 100%;
            border-radius: 10px;
            transition: 1s ease-in-out;
        }

        .quota-text {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 0.85rem;
            color: var(--text-light);
        }

        /* Actions Header */
        .actions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .btn-new {
            background: var(--accent);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
            text-decoration: none;
        }

        .btn-new:hover {
            background: #00b386;
            transform: translateY(-2px);
        }

        /* Jobs Table */
        .table-container {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background: #f8fafc;
            padding: 1.2rem;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-light);
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 1.2rem;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-green {
            background: #dcfce7;
            color: #15803d;
        }

        .badge-yellow {
            background: #ffedd5;
            color: #9a3412;
        }

        .badge-gray {
            background: #f1f5f9;
            color: #475569;
        }

        .badge-blue {
            background: #e0f2fe;
            color: #0369a1;
        }

        .btn-icon {
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1.1rem;
            padding: 5px;
            transition: 0.2s;
        }

        .btn-icon:hover {
            color: var(--primary);
        }

        .btn-delete:hover {
            color: var(--danger);
        }

        /* Modal / Form */
        #vaga-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        }

        .modal-body {
            background: var(--white);
            width: 95%;
            max-width: 1000px;
            height: 90vh;
            border-radius: 20px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .modal-header {
            padding: 1.5rem 2.5rem;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-form {
            flex-grow: 1;
            overflow-y: auto;
            padding: 2.5rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group.full {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            outline: none;
        }

        .form-group input:focus {
            border-color: var(--accent);
        }

        .form-footer {
            padding: 1.5rem 2.5rem;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }

        .btn-ghost {
            background: none;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
        }

        @media (max-width: 1024px) {
            .app-container {
                grid-template-columns: 1fr;
            }

            aside {
                display: none;
            }
        }
    </style>
</head>

<body>

    <div class="app-container">
        <aside>
            <div class="logo">
                <a href="<?php echo home_url(); ?>" style="text-decoration:none;">
                    <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_branco_transparente.png"
                        alt="Thriveo" style="width: 140px; height: auto; display: block;">
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="?thriveo_talentos=1"
                        title="Explore o banco de especialistas em IA para encontrar o match perfeito."><i
                            class="fas fa-users"></i> Banco de Talentos</a></li>
                <li><a href="?thriveo_empresa_vagas=1" class="active"
                        title="Visualize e gerencie as vagas publicadas pela sua empresa e suas candidaturas."><i
                            class="fas fa-briefcase"></i> Gestão de Vagas</a></li>
                <li><a href="?thriveo_dashboard=1"
                        title="Retorne ao seu painel principal de métricas e perfil profissional."><i
                            class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="?thriveo_certificacoes=1" title="Confira e gerencie os selos de certificação."><i
                            class="fas fa-certificate"></i> Certificações</a></li>
                <li><a href="<?php echo home_url('?thriveo_vagas=1'); ?>"
                        title="Veja como os candidatos visualizam o seu portal de vagas público."><i
                            class="fas fa-eye"></i> Ver Portal de Vagas</a></li>
                <li><a href="<?php echo home_url(); ?>" title="Retornar para a página inicial do portal."><i
                            class="fas fa-home"></i> Voltar ao Site</a></li>
                <li><a href="<?php echo wp_logout_url(home_url()); ?>" id="th-btnLogout-company" title="Encerrar sua sessão atual com segurança."><i
                            class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
            </ul>
        </aside>

        <main>
            <div class="page-intro"
                style="margin-bottom: 2.5rem; background: var(--white); padding: 2rem; border-radius: 20px; border-left: 5px solid var(--accent); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <h1 style="font-size: 1.8rem; color: var(--navy); margin-bottom: 0.5rem;">Gestão Estratégica de
                    Oportunidades</h1>
                <p style="color: var(--text-light); font-size: 1.05rem; max-width: 800px;">Publique e gerencie suas
                    vagas de forma simplificada. Acompanhe as candidaturas em tempo real e impulsione o crescimento da
                    sua equipe com talentos de elite em IA.</p>
            </div>

            <div class="quota-card"
                title="Seu limite mensal de publicações gratuitas. Após o uso da cota, cada nova vaga custará R$ 99,00.">
                <div class="quota-header">
                    <h2>Cota Mensal Freemium</h2>
                    <span id="quota-badge" class="badge badge-blue">Plano Gratuito</span>
                </div>
                <div class="quota-progress">
                    <div id="quota-fill" class="quota-fill" style="width: 0%"></div>
                </div>
                <div class="quota-text">
                    <span id="quota-usage">Você usou 0 de 1 vaga gratuita este mês</span>
                    <span>Vagas adicionais: a partir de R$ 99,00</span>
                </div>
                <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
                    <button class="btn-new" onclick="document.getElementById('modal-pagamento').style.display='flex'" style="background:var(--navy);"><i class="fas fa-rocket"></i> Fazer Upgrade (Múltiplas Vagas)</button>
                </div>
            </div>

            <div class="actions-header">
                <h1>Minhas Vagas</h1>
                <button class="btn-new" onclick="openVagaModal()"
                    title="Crie uma nova publicação para atrair talentos. A primeira do mês é gratuita!"><i
                        class="fas fa-plus"></i> Publicar Nova Vaga</button>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Vaga</th>
                            <th>Status</th>
                            <th>Candidaturas</th>
                            <th>Tipo</th>
                            <th>Expira em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="vagas-list">
                        <!-- Loaded via JS -->
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- Modal Formulário de Vaga -->
    <div id="vaga-modal">
        <div class="modal-body">
            <div class="modal-header">
                <h2 id="modal-title">Nova Vaga</h2>
                <button onclick="closeVagaModal()" class="btn-icon"><i class="fas fa-times"></i></button>
            </div>
            <form id="vaga-form" class="modal-form">
                <input type="hidden" name="id" id="vaga-id">

                <div class="form-grid">
                    <div class="form-group full">
                        <label>Título da Vaga *</label>
                        <input type="text" name="titulo" required placeholder="Ex: AI Engineer Senior">
                    </div>
                    <div class="form-group">
                        <label>Área de Atuação *</label>
                        <select name="area_atuacao" required>
                            <option value="Backend">Backend</option>
                            <option value="Frontend">Frontend</option>
                            <option value="Full-Stack">Full-Stack</option>
                            <option value="Data/IA">Data/IA</option>
                            <option value="Mobile">Mobile</option>
                            <option value="DevOps">DevOps</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nível *</label>
                        <select name="nivel" required>
                            <option value="Júnior">Júnior</option>
                            <option value="Pleno">Pleno</option>
                            <option value="Sênior">Sênior</option>
                            <option value="Especialista">Especialista</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Regime *</label>
                        <select name="regime" required>
                            <option value="CLT">CLT</option>
                            <option value="PJ">PJ</option>
                            <option value="Freelancer">Freelancer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Modalidade *</label>
                        <select name="modalidade" required>
                            <option value="Remoto">Remoto</option>
                            <option value="Híbrido">Híbrido</option>
                            <option value="Presencial">Presencial</option>
                        </select>
                    </div>
                    <div class="form-group full">
                        <label>Descrição *</label>
                        <textarea name="descricao" rows="5" required></textarea>
                    </div>
                    <div class="form-group full">
                        <label>Requisitos Obrigatórios *</label>
                        <textarea name="requisitos_obrigatorios" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Salário Mínimo (R$)</label>
                        <input type="number" name="salario_min">
                    </div>
                    <div class="form-group">
                        <label>Salário Máximo (R$)</label>
                        <input type="number" name="salario_max">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="ativa">Ativa (Publicar)</option>
                            <option value="rascunho">Rascunho</option>
                            <option value="pausada">Pausada</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Prazo Candidatura</label>
                        <input type="date" name="prazo_candidatura">
                    </div>
                </div>

                <div id="payment-warning"
                    style="display:none; background: #fffbeb; padding: 20px; border-radius: 12px; border: 1px solid #fef3c7; color: #92400e; margin-top: 20px;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Atenção:</strong> Você já atingiu sua cota de 1 vaga gratuita este mês. Para publicar esta
                    vaga como <strong>Ativa</strong>, será gerada uma cobrança de <strong>R$ 99,00</strong>.
                </div>
            </form>
            <div class="form-footer">
                <button class="btn-ghost" onclick="closeVagaModal()">Cancelar</button>
                <button class="btn-new" id="btn-save-vaga" onclick="saveVaga()">Salvar Vaga</button>
            </div>
        </div>
    </div>

    <script>
        // Utiliza a origem crua gerada pelo WP, forçando o envio de cookies de terceiros se necessário
        const rawAjaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';

        async function loadVagas() {
            const response = await fetch(rawAjaxUrl + '?action=thriveo_get_vagas_empresa', {
                credentials: 'include'
            });
            const data = await response.json();

            if (data.success) {
                renderVagas(data.data.vagas);
                renderQuota(data.data.quota);
            }
        }

        function renderVagas(vagas) {
            const list = document.getElementById('vagas-list');
            if (vagas.length === 0) {
                list.innerHTML = '<tr><td colspan="6" style="text-align:center">Nenhuma vaga cadastrada.</td></tr>';
                return;
            }

            list.innerHTML = vagas.map(v => {
                const statusClass = v.status === 'ativa' ? 'badge-green' : (v.status === 'rascunho' ? 'badge-blue' : 'badge-yellow');
                const dataExp = v.expira_em ? new Date(v.expira_em).toLocaleDateString() : 'Sem prazo';

                return `
                <tr>
                    <td>
                        <strong>${v.titulo}</strong><br>
                        <small style="color:var(--text-light)">${v.area_atuacao} • ${v.nivel}</small>
                    </td>
                    <td><span class="badge ${statusClass}">${v.status.toUpperCase()}</span></td>
                    <td><a href="#" onclick="viewApplications(${v.id})" style="color:var(--accent); font-weight:600">Ver Candidaturas</a></td>
                    <td>${v.tipo_publicacao === 'paga' ? '💎 Paga' : '🆓 Grátis'}</td>
                    <td>${dataExp}</td>
                    <td>
                        <button class="btn-icon" onclick="editVaga(${JSON.stringify(v).replace(/"/g, '&quot;')})"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon btn-delete" onclick="deleteVaga(${v.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `;
            }).join('');
        }

        function renderQuota(quota) {
            const fill = document.getElementById('quota-fill');
            const text = document.getElementById('quota-usage');
            const badge = document.getElementById('quota-badge');

            const limite = quota.limite || 1;
            const perc = (quota.usadas / limite) * 100;
            fill.style.width = Math.min(perc, 100) + '%';
            
            const tipoVaga = limite > 1 ? 'vagas' : 'vaga gratuita';
            text.innerText = `Você usou ${quota.usadas} de ${limite} ${tipoVaga} este mês`;

            if (!quota.pode_gratis) {
                badge.innerText = "Cota Esgotada";
                badge.className = "badge badge-yellow";
                document.getElementById('payment-warning').style.display = 'block';
            } else if (limite > 1) {
                badge.innerText = "Plano Premium";
                badge.className = "badge badge-green";
                document.getElementById('payment-warning').style.display = 'none';
            } else {
                badge.innerText = "Plano Gratuito";
                badge.className = "badge badge-blue";
                document.getElementById('payment-warning').style.display = 'none';
            }
        }

        function openVagaModal() {
            document.getElementById('vaga-form').reset();
            document.getElementById('vaga-id').value = '';
            document.getElementById('modal-title').innerText = "Nova Vaga";
            document.getElementById('vaga-modal').style.display = 'flex';
        }

        function closeVagaModal() {
            document.getElementById('vaga-modal').style.display = 'none';
        }

        function editVaga(v) {
            openVagaModal();
            document.getElementById('modal-title').innerText = "Editar Vaga";
            document.getElementById('vaga-id').value = v.id;

            const form = document.getElementById('vaga-form');
            form.titulo.value = v.titulo;
            form.area_atuacao.value = v.area_atuacao;
            form.nivel.value = v.nivel;
            form.regime.value = v.regime;
            form.modalidade.value = v.modalidade;
            form.descricao.value = v.descricao;
            form.requisitos_obrigatorios.value = v.requisitos_obrigatorios;
            form.salario_min.value = v.salario_min;
            form.salario_max.value = v.salario_max;
            form.status.value = v.status;
            form.prazo_candidatura.value = v.prazo_candidatura ? v.prazo_candidatura.split(' ')[0] : '';
        }

        async function deleteVaga(id) {
            if (!confirm("Tem certeza que deseja excluir esta vaga? Esta ação é irreversível.")) {
                return;
            }

            const fd = new FormData();
            fd.append('action', 'thriveo_delete_vaga');
            fd.append('id', id);

            try {
                const response = await fetch(rawAjaxUrl, {
                    method: 'POST',
                    credentials: 'include',
                    body: fd
                });
                const data = await response.json();
                if (data.success) {
                    alert(data?.data?.message || "Excluída com sucesso.");
                    loadVagas();
                } else {
                    alert("Erro ao excluir: " + (data?.data?.message || JSON.stringify(data)));
                }
            } catch (e) {
                console.error("Delete exception", e);
                alert("Erro de rede ao tentar excluir.");
            }
        }

        async function saveVaga() {
            const form = document.getElementById('vaga-form');
            const fd = new FormData(form);
            fd.append('action', 'thriveo_save_vaga');

            const btn = document.getElementById('btn-save-vaga');
            btn.disabled = true;
            btn.innerText = "Salvando...";

            try {
                const response = await fetch(rawAjaxUrl, {
                    method: 'POST',
                    credentials: 'include',
                    body: fd
                });
                
                const rawText = await response.text();
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch(err) {
                    console.error("Raw response:", rawText);
                    alert("Erro interno no servidor: " + rawText.substring(0, 150));
                    return;
                }

                if (data.success) {
                    alert(data?.data?.message || "Salvo com sucesso!");
                    closeVagaModal();
                    loadVagas();
                } else if (data?.data?.code === 'quota_exceeded') {
                    // Cota esgotada. Fechar modal de vaga e abrir modal de planos.
                    closeVagaModal();
                    document.getElementById('modal-pagamento').style.display = 'flex';
                } else {
                    const errorMsg = data?.data?.message || data?.message || data?.data || JSON.stringify(data);
                    alert("Erro do Servidor: " + errorMsg);
                }
            } catch (e) {
                console.error("Fetch Exception:", e);
                alert("Erro de Rede ou Catch: " + (e.message || e));
            } finally {
                btn.disabled = false;
                btn.innerText = "Salvar Vaga";
            }
        }

        function viewApplications(vagaId) {
            alert("Carregando candidatos para a vaga #" + vagaId);
            // Aqui abriríamos uma lista de candidatos filtrada por essa vaga
        }

        loadVagas();

        // Verificar parâmetro para abrir modal de nova vaga
        window.addEventListener('load', () => {
            const params = new URLSearchParams(window.location.search);
            if (params.get('nova_vaga') === '1') {
                openVagaModal();
            }
        });
    </script>
    
    <?php include THRIVEO_AI_JOBS_DIR . 'templates/modal-pagamento.php'; ?>
</body>

</html>