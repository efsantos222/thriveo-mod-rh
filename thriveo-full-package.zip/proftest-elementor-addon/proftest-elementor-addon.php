<?php
/**
 * Plugin Name: Proftest Elementor Addon
 * Description: Widget de Abas personalizado para o layout Proftest.
 * Version: 1.0.0
 * Author: Proftest
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Register Tabs Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_proftest_tabs_widget($widgets_manager)
{

    require_once(__DIR__ . '/widgets/proftest-tabs-widget.php');
    require_once(__DIR__ . '/widgets/proftest-social-proof-widget.php');
    require_once(__DIR__ . '/widgets/proftest-feature-steps-widget.php');
    require_once(__DIR__ . '/widgets/proftest-contact-widget.php');

    $widgets_manager->register(new \Proftest_Tabs_Widget());
    $widgets_manager->register(new \Proftest_Social_Proof_Widget());
    $widgets_manager->register(new \Proftest_Features_Steps_Widget());
    $widgets_manager->register(new \Proftest_Contact_Widget());

}
add_action('elementor/widgets/register', 'register_proftest_tabs_widget');

/**
 * Register Scripts and Styles.
 */
function proftest_tabs_widget_scripts()
{
    wp_register_style('proftest-tabs-style', plugins_url('assets/css/style.css', __FILE__), [], '1.2.0');
}
add_action('wp_enqueue_scripts', 'proftest_tabs_widget_scripts');
add_action('elementor/editor/after_enqueue_styles', 'proftest_tabs_widget_scripts');
