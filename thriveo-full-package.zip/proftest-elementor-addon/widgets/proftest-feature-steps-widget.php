<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Proftest_Features_Steps_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'proftest_features_steps';
    }

    public function get_title()
    {
        return esc_html__('Proftest Features & Steps', 'proftest-elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-flow';
    }

    public function get_categories()
    {
        return ['general'];
    }

    public function get_style_depends()
    {
        return ['proftest-tabs-style'];
    }

    protected function register_controls()
    {

        // ==========================================
        // 1. CARDS DE CARACTERÍSTICAS (TOPO)
        // ==========================================
        $this->start_controls_section(
            'section_features_top',
            [
                'label' => esc_html__('1. Características da Empresa (Topo)', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater_features_top = new \Elementor\Repeater();

        $repeater_features_top->add_control(
            'feature_icon',
            [
                'label' => esc_html__('Ícone', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-lock',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater_features_top->add_control(
            'feature_title',
            [
                'label' => esc_html__('Título', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'LGPD Compliant',
            ]
        );

        $repeater_features_top->add_control(
            'feature_desc',
            [
                'label' => esc_html__('Texto', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Dados protegidos',
            ]
        );

        $this->add_control(
            'features_top_list',
            [
                'label' => esc_html__('Lista de Cards', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_features_top->get_controls(),
                'default' => [
                    ['feature_title' => 'LGPD Compliant', 'feature_desc' => 'Dados protegidos', 'feature_icon' => ['value' => 'fas fa-lock', 'library' => 'fa-solid']],
                    ['feature_title' => 'Cloud Seguro', 'feature_desc' => 'Infraestrutura confiável', 'feature_icon' => ['value' => 'fas fa-cloud', 'library' => 'fa-solid']],
                    ['feature_title' => 'Empresa Brasileira', 'feature_desc' => 'Suporte em português', 'feature_icon' => ['value' => 'fas fa-flag', 'library' => 'fa-solid']],
                    ['feature_title' => '99.9% Uptime', 'feature_desc' => 'Alta disponibilidade', 'feature_icon' => ['value' => 'fas fa-bolt', 'library' => 'fa-solid']],
                ],
                'title_field' => '{{{ feature_title }}}',
            ]
        );

        $this->end_controls_section();


        // ==========================================
        // 2. SEÇÃO DE FUNCIONAMENTO (MEIO) - CABEÇALHO
        // ==========================================
        $this->start_controls_section(
            'section_how_it_works_header',
            [
                'label' => esc_html__('2. Como Funciona - Cabeçalho', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'hiw_badge',
            [
                'label' => esc_html__('Badge', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'COMO FUNCIONA',
            ]
        );

        $this->add_control(
            'hiw_title',
            [
                'label' => esc_html__('Título Principal', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Simples e Eficiente em 4 Passos',
            ]
        );

        $this->add_control(
            'hiw_desc',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Implementação rápida e suporte completo para você começar a transformar sua gestão de pessoas em poucos dias',
            ]
        );

        $this->end_controls_section();


        // ==========================================
        // 2. SEÇÃO DE FUNCIONAMENTO (MEIO) - CARDS (STEPS)
        // ==========================================
        $this->start_controls_section(
            'section_how_it_works_steps',
            [
                'label' => esc_html__('2. Como Funciona - Passos', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater_steps = new \Elementor\Repeater();

        $repeater_steps->add_control(
            'step_number',
            [
                'label' => esc_html__('Número do Passo', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '1',
            ]
        );

        $repeater_steps->add_control(
            'step_icon',
            [
                'label' => esc_html__('Ícone', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-comments',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater_steps->add_control(
            'step_title',
            [
                'label' => esc_html__('Título', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Título do Passo',
            ]
        );

        $repeater_steps->add_control(
            'step_desc',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Descrição do passo.',
            ]
        );

        $repeater_steps->add_control(
            'step_features',
            [
                'label' => esc_html__('Lista de Checkpoints', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'description' => 'Um item por linha',
                'default' => "✓ Item 1\n✓ Item 2",
            ]
        );

        $this->add_control(
            'steps_list',
            [
                'label' => esc_html__('Lista de Passos', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_steps->get_controls(),
                'default' => [
                    [
                        'step_number' => '1',
                        'step_title' => 'Análise de Necessidades',
                        'step_desc' => 'Conversamos com sua equipe para entender seus desafios.',
                        'step_features' => "✓ Reunião de diagnóstico\n✓ Análise de processos",
                        'step_icon' => ['value' => 'fas fa-comments', 'library' => 'fa-solid']
                    ],
                    [
                        'step_number' => '2',
                        'step_title' => 'Configuração',
                        'step_desc' => 'Nossa equipe configura a plataforma de acordo com suas necessidades.',
                        'step_features' => "✓ Setup completo\n✓ Personalização visual",
                        'step_icon' => ['value' => 'fas fa-cog', 'library' => 'fa-solid']
                    ],
                    [
                        'step_number' => '3',
                        'step_title' => 'Treinamento',
                        'step_desc' => 'Capacitamos sua equipe de RH e gestores.',
                        'step_features' => "✓ Sessões online\n✓ Material de apoio",
                        'step_icon' => ['value' => 'fas fa-graduation-cap', 'library' => 'fa-solid']
                    ],
                    [
                        'step_number' => '4',
                        'step_title' => 'Go Live',
                        'step_desc' => 'Acompanhamos os primeiros ciclos e otimizamos.',
                        'step_features' => "✓ Suporte prioritário\n✓ Monitoramento",
                        'step_icon' => ['value' => 'fas fa-rocket', 'library' => 'fa-solid']
                    ],
                ],
                'title_field' => 'Passo {{{ step_number }}} - {{{ step_title }}}',
            ]
        );

        $this->end_controls_section();


        // ==========================================
        // 3. SEÇÃO DE VANTAGENS (RODAPÉ)
        // ==========================================
        $this->start_controls_section(
            'section_benefits_footer',
            [
                'label' => esc_html__('3. Vantagens (Rodapé)', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater_benefits = new \Elementor\Repeater();

        $repeater_benefits->add_control(
            'benefit_icon',
            [
                'label' => esc_html__('Ícone', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-bolt',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater_benefits->add_control(
            'benefit_title',
            [
                'label' => esc_html__('Título', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Implementação Rápida',
            ]
        );

        $repeater_benefits->add_control(
            'benefit_desc',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'De 3 a 10 dias úteis',
            ]
        );

        $this->add_control(
            'benefits_list',
            [
                'label' => esc_html__('Lista de Vantagens', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_benefits->get_controls(),
                'default' => [
                    ['benefit_title' => 'Implementação Rápida', 'benefit_desc' => 'De 3 a 10 dias úteis', 'benefit_icon' => ['value' => 'fas fa-bolt', 'library' => 'fa-solid']],
                    ['benefit_title' => 'ROI em 90 dias', 'benefit_desc' => 'Retorno rápido garantido', 'benefit_icon' => ['value' => 'fas fa-bullseye', 'library' => 'fa-solid']],
                    ['benefit_title' => 'Suporte Contínuo', 'benefit_desc' => 'Equipe disponível sempre', 'benefit_icon' => ['value' => 'fas fa-headset', 'library' => 'fa-solid']],
                ],
                'title_field' => '{{{ benefit_title }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>

        <div class="proftest-features-steps">

            <!-- 1. TOP FEATURES ROW -->
            <div class="top-features-grid">
                <?php foreach ($settings['features_top_list'] as $feature): ?>
                    <div class="top-feature-card">
                        <div class="tf-icon-wrapper">
                            <?php \Elementor\Icons_Manager::render_icon($feature['feature_icon'], ['aria-hidden' => 'true']); ?>
                        </div>
                        <div class="tf-content">
                            <h4 class="tf-title"><?php echo esc_html($feature['feature_title']); ?></h4>
                            <p class="tf-desc"><?php echo esc_html($feature['feature_desc']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- SEPARATOR -->
            <div class="hiw-separator"></div>

            <!-- 2. HOW IT WORKS SECTION -->
            <div class="how-it-works-section">
                <!-- Header -->
                <div class="hiw-header">
                    <span class="hiw-badge"><?php echo esc_html($settings['hiw_badge']); ?></span>
                    <h2 class="hiw-title"><?php echo esc_html($settings['hiw_title']); ?></h2>
                    <p class="hiw-subtitle"><?php echo esc_html($settings['hiw_desc']); ?></p>
                </div>

                <!-- Steps Grid -->
                <div class="hiw-steps-grid">
                    <?php foreach ($settings['steps_list'] as $step):
                        $step_features = explode("\n", $step['step_features']);
                        ?>
                        <div class="hiw-step-card">
                            <!-- Step Number Badge -->
                            <div class="step-badge"><?php echo esc_html($step['step_number']); ?></div>

                            <div class="step-icon">
                                <?php \Elementor\Icons_Manager::render_icon($step['step_icon'], ['aria-hidden' => 'true']); ?>
                            </div>

                            <h3 class="step-title"><?php echo esc_html($step['step_title']); ?></h3>
                            <p class="step-desc"><?php echo esc_html($step['step_desc']); ?></p>

                            <ul class="step-features-list">
                                <?php foreach ($step_features as $sf): ?>
                                    <?php if (!empty(trim($sf))): ?>
                                        <li><?php echo esc_html($sf); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 3. BOTTOM BENEFITS FOOTER -->
            <div class="bottom-benefits-container">
                <div class="bottom-benefits-grid">
                    <?php foreach ($settings['benefits_list'] as $benefit): ?>
                        <div class="bottom-benefit-item">
                            <div class="bb-icon">
                                <?php \Elementor\Icons_Manager::render_icon($benefit['benefit_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="bb-content">
                                <h5 class="bb-title"><?php echo esc_html($benefit['benefit_title']); ?></h5>
                                <p class="bb-desc"><?php echo esc_html($benefit['benefit_desc']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

        <?php
    }
}
