<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Proftest_Tabs_Widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'proftest_tabs';
	}

	public function get_title()
	{
		return esc_html__('Proftest Tabs', 'proftest-elementor-addon');
	}

	public function get_icon()
	{
		return 'eicon-tabs';
	}

	public function get_categories()
	{
		return ['general'];
	}

	protected function register_controls()
	{

		// ==========================================
		// HEADERS
		// ==========================================
		$this->start_controls_section(
			'section_header',
			[
				'label' => esc_html__('Cabeçalho da Seção', 'proftest-elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'badge_text',
			[
				'label' => esc_html__('Texto do Badge', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Nossas Soluções', 'proftest-elementor-addon'),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__('Título Principal', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Plataforma Completa para Gestão de Pessoas', 'proftest-elementor-addon'),
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtítulo', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__('Soluções integradas com IA que cobrem todo o ciclo de vida do colaborador.', 'proftest-elementor-addon'),
			]
		);

		$this->end_controls_section();

		// ==========================================
		// CONFIGURAÇÃO DAS ABAS (CATEGORIAS)
		// ==========================================
		$this->start_controls_section(
			'section_tabs_config',
			[
				'label' => esc_html__('1. Categorias (Abas)', 'proftest-elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater_tabs = new \Elementor\Repeater();

		$repeater_tabs->add_control(
			'tab_label',
			[
				'label' => esc_html__('Nome da Categoria', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Nova Aba',
				'label_block' => true,
			]
		);

		$repeater_tabs->add_control(
			'tab_icon',
			[
				'label' => esc_html__('Ícone (Emoji ou Texto)', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '🎯',
			]
		);

		$repeater_tabs->add_control(
			'tab_id',
			[
				'label' => esc_html__('ID Único da Categoria', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'description' => 'Crie um código simples e único para esta aba (ex: rh, vendas, ti). Você usará este mesmo ID nos Cards para vincular eles a esta aba.',
				'default' => 'aba1',
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs_list',
			[
				'label' => esc_html__('Gerenciar Categorias', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater_tabs->get_controls(),
				'default' => [
					[
						'tab_label' => 'Atração de Talentos',
						'tab_icon' => '🎯',
						'tab_id' => 'atracao',
					],
					[
						'tab_label' => 'Desenvolvimento',
						'tab_icon' => '📈',
						'tab_id' => 'desenvolvimento',
					],
					[
						'tab_label' => 'Performance',
						'tab_icon' => '⚡',
						'tab_id' => 'performance',
					],
					[
						'tab_label' => 'Cultura e Engajamento',
						'tab_icon' => '❤️',
						'tab_id' => 'cultura',
					],
				],
				'title_field' => '{{{ tab_label }}} (ID: {{{ tab_id }}})',
			]
		);

		$this->end_controls_section();

		// ==========================================
		// CONFIGURAÇÃO DOS CARDS
		// ==========================================
		$this->start_controls_section(
			'section_solutions_cards',
			[
				'label' => esc_html__('2. Cards de Soluções', 'proftest-elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater_cards = new \Elementor\Repeater();

		$repeater_cards->add_control(
			'solution_tab_id',
			[
				'label' => esc_html__('Vincular à Categoria (ID)', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'description' => 'Digite o ID da Categoria onde este card deve aparecer (ex: atracao).',
				'label_block' => true,
			]
		);

		$repeater_cards->add_control(
			'card_title',
			[
				'label' => esc_html__('Título do Card', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Título da Solução',
				'label_block' => true,
			]
		);

		$repeater_cards->add_control(
			'card_description',
			[
				'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Descrição curta da solução.',
			]
		);

		$repeater_cards->add_control(
			'card_features_text',
			[
				'label' => esc_html__('Lista de Funcionalidades', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'description' => 'Digite uma funcionalidade por linha.',
				'default' => "✓ Funcionalidade 1\n✓ Funcionalidade 2\n✓ Funcionalidade 3",
			]
		);

		$repeater_cards->add_control(
			'card_icon',
			[
				'label' => esc_html__('Ícone (Emoji ou Texto)', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '🤖',
			]
		);

		$repeater_cards->add_control(
			'is_featured',
			[
				'label' => esc_html__('Destacar Card?', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$repeater_cards->add_control(
			'show_ai_badge',
			[
				'label' => esc_html__('Selo de IA?', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$repeater_cards->add_control(
			'cta_text',
			[
				'label' => esc_html__('Texto do Link', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Conhecer Solução →',
			]
		);

		$repeater_cards->add_control(
			'cta_url',
			[
				'label' => esc_html__('URL do Link', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => 'https://...',
				'default' => [
					'url' => '#',
				],
			]
		);

		$this->add_control(
			'cards_list',
			[
				'label' => esc_html__('Gerenciar Cards', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater_cards->get_controls(),
				'title_field' => '{{{ card_title }}} [{{{ solution_tab_id }}}]',
				'default' => [
					// ATRACAO (4 cards)
					[
						'solution_tab_id' => 'atracao',
						'is_featured' => 'yes',
						'show_ai_badge' => 'yes',
						'card_icon' => '🤖',
						'card_title' => 'Avaliação de Candidatos',
						'card_description' => 'Gere testes personalizados com IA a partir de especificações de cargo. Elimine vieses.',
						'card_features_text' => "✓ Geração automática com IA\n✓ Testes técnicos por área\n✓ Gestão completa",
						'cta_url' => ['url' => 'https://proftest.com.br/avaliacao-candidatos'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'atracao',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '📋',
						'card_title' => 'Recrutamento e Seleção',
						'card_description' => 'Plataforma completa para gerenciar todo processo seletivo com eficiência.',
						'card_features_text' => "✓ Testes técnicos específicos\n✓ Entrevistas virtuais\n✓ Banco de talentos",
						'cta_url' => ['url' => 'https://proftest.com.br/recruta/login.php'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'atracao',
						'is_featured' => '',
						'show_ai_badge' => 'yes',
						'card_icon' => '💬',
						'card_title' => 'Roteiro de Entrevistas',
						'card_description' => 'Crie roteiros estruturados e profissionais em minutos. Automatize suas entrevistas com IA.',
						'card_features_text' => "✓ Roteiros inteligentes com IA\n✓ Entrevistas estruturadas\n✓ Personalização por cargo",
						'cta_url' => ['url' => 'https://proftest.com.br/roteiro-de-entrevistas/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'atracao',
						'is_featured' => '',
						'show_ai_badge' => 'yes',
						'card_icon' => '🧠',
						'card_title' => 'Soft Skills',
						'card_description' => 'Avalie competências comportamentais com precisão através de testes especializados.',
						'card_features_text' => "✓ Testes comportamentais\n✓ Pré-análise com IA\n✓ Recomendações",
						'cta_url' => ['url' => 'https://proftest.com.br/disc'],
						'cta_text' => 'Conhecer Solução →'
					],
					// DESENVOLVIMENTO (4 cards)
					[
						'solution_tab_id' => 'desenvolvimento',
						'is_featured' => 'yes',
						'show_ai_badge' => '',
						'card_icon' => '🎓',
						'card_title' => 'Desenvolvimento (PDI)',
						'card_description' => 'Estruture planos individuais alinhados aos objetivos da empresa e aspirações.',
						'card_features_text' => "✓ PDI estruturado\n✓ Ferramentas de coaching\n✓ Cursos de liderança",
						'cta_url' => ['url' => 'https://proftest.com.br/pdi/public/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'desenvolvimento',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '🚀',
						'card_title' => 'Coaching',
						'card_description' => 'Desbloqueie o potencial com coaching estruturado. Alcance objetivos com clareza.',
						'card_features_text' => "✓ Metodologia passo a passo\n✓ Acompanhamento estruturado\n✓ Desenvolvimento de skills",
						'cta_url' => ['url' => 'https://proftest.com.br/coach/dashboard.php'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'desenvolvimento',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '👔',
						'card_title' => 'Plano de Lideranças',
						'card_description' => 'Forme líderes excepcionais através de diagnóstico, capacitação e acompanhamento.',
						'card_features_text' => "✓ Diagnóstico de competências\n✓ Capacitação personalizada\n✓ Acompanhamento de evolução",
						'cta_url' => ['url' => 'https://sysmanager.proftest.com.br/pdl/login.php'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'desenvolvimento',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '🏆',
						'card_title' => 'Certificação Profissional',
						'card_description' => 'Acelere a aprovação em certificações com simulados e planos de estudo.',
						'card_features_text' => "✓ Simulados especializados\n✓ Planos de estudo\n✓ Tracking de progresso",
						'cta_url' => ['url' => '#'],
						'cta_text' => 'Conhecer Solução →'
					],
					// PERFORMANCE (4 cards)
					[
						'solution_tab_id' => 'performance',
						'is_featured' => 'yes',
						'show_ai_badge' => '',
						'card_icon' => '📊',
						'card_title' => 'Avaliação de Desempenho',
						'card_description' => 'Avaliações 360 graus com feedback contínuo. Mensure performance técnica.',
						'card_features_text' => "✓ Avaliação 360 graus\n✓ Competências técnicas\n✓ Feedback contínuo",
						'cta_url' => ['url' => 'https://proftest.com.br/avaliacao-de-desempenho/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'performance',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '🎯',
						'card_title' => 'OKR',
						'card_description' => 'Gerencie objetivos e resultados-chave. Alinhe estratégia à execução.',
						'card_features_text' => "✓ Criação de OKRs\n✓ Planos de ação\n✓ Acompanhamento",
						'cta_url' => ['url' => 'https://sysmanager.proftest.com.br/okr/auth/login'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'performance',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '🔍',
						'card_title' => 'Avaliação Comportamental',
						'card_description' => 'Desbloqueie potencial através do autoconhecimento e diagnósticos precisos.',
						'card_features_text' => "✓ Perfil comportamental\n✓ Autoconhecimento\n✓ Desenvolvimento pessoal",
						'cta_url' => ['url' => 'https://proftest.com.br/avaliacao-comportamental/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'performance',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '⭐',
						'card_title' => 'Gestão de Carreira',
						'card_description' => 'Identifique talentos, planeje sucessões e garanta continuidade estratégica.',
						'card_features_text' => "✓ Mapeamento de talentos\n✓ Planejamento sucessório\n✓ Fit cultural",
						'cta_url' => ['url' => 'https://proftest.com.br/coach/dashboard.php'],
						'cta_text' => 'Conhecer Solução →'
					],
					// CULTURA (4 cards)
					[
						'solution_tab_id' => 'cultura',
						'is_featured' => 'yes',
						'show_ai_badge' => 'yes',
						'card_icon' => '🏢',
						'card_title' => 'Cultura Empresarial',
						'card_description' => 'Identifique e fortaleça sua cultura organizacional com análise baseada em IA.',
						'card_features_text' => "✓ Identificação com IA\n✓ Análise de aderência\n✓ Planos de fortalecimento",
						'cta_url' => ['url' => 'https://proftest.com.br/cultura-empresarial/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'cultura',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '😊',
						'card_title' => 'Clima Organizacional',
						'card_description' => 'Pesquisas automatizadas com dashboard. Transforme feedback em ações.',
						'card_features_text' => "✓ Pesquisas automatizadas\n✓ Dashboard de satisfação\n✓ Gestão de ações",
						'cta_url' => ['url' => 'https://proftest.com.br/clima/public/'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'cultura',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '🚪',
						'card_title' => 'OffBoarding',
						'card_description' => 'Estruture saídas com segurança e respeito. Desligamentos estratégicos.',
						'card_features_text' => "✓ Processo estruturado\n✓ Coleta de feedback\n✓ Insights",
						'cta_url' => ['url' => '#'],
						'cta_text' => 'Conhecer Solução →'
					],
					[
						'solution_tab_id' => 'cultura',
						'is_featured' => '',
						'show_ai_badge' => '',
						'card_icon' => '📄',
						'card_title' => 'Gerador de Currículos',
						'card_description' => 'Ajude candidatos a criar currículos profissionais em minutos.',
						'card_features_text' => "✓ Templates profissionais\n✓ Criação rápida\n✓ Formatação otimizada",
						'cta_url' => ['url' => 'https://proftest.com.br/gerador-de-curriculo/'],
						'cta_text' => 'Conhecer Solução →'
					],
				]
			]
		);

		$this->end_controls_section();

		// ==========================================
		// RODAPÉ (CTA)
		// ==========================================
		$this->start_controls_section(
			'section_footer_cta',
			[
				'label' => esc_html__('Rodapé da Seção (CTA)', 'proftest-elementor-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'footer_cta_title',
			[
				'label' => esc_html__('Título', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Não sabe qual solução é ideal para sua empresa?', 'proftest-elementor-addon'),
			]
		);

		$this->add_control(
			'footer_cta_desc',
			[
				'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__('Converse com nossos especialistas e receba uma recomendação personalizada', 'proftest-elementor-addon'),
			]
		);

		$this->add_control(
			'footer_cta_btn_text',
			[
				'label' => esc_html__('Texto do Botão', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Falar com Especialista', 'proftest-elementor-addon'),
			]
		);

		$this->add_control(
			'footer_cta_link',
			[
				'label' => esc_html__('Link do Botão', 'proftest-elementor-addon'),
				'type' => \Elementor\Controls_Manager::URL,
				'default' => [
					'url' => '#contato',
					'is_external' => false,
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		?>

		<div class="proftest-solutions" id="solucoes">
			<div class="solutions-header">
				<span class="section-badge"><?php echo esc_html($settings['badge_text']); ?></span>
				<h2 class="section-title"><?php echo esc_html($settings['title']); ?></h2>
				<p class="section-subtitle">
					<?php echo esc_html($settings['subtitle']); ?>
				</p>
			</div>

			<div class="solutions-tabs">
				<!-- RENDERIZAÇÃO DOS BOTÕES DAS ABAS -->
				<div class="tab-buttons">
					<?php
					$loop_index = 0;
					$first_tab = true;
					foreach ($settings['tabs_list'] as $tab):
						$active_class = $first_tab ? 'active' : '';
						?>
						<button class="tab-btn <?php echo $active_class; ?>" data-tab-index="<?php echo $loop_index; ?>">
							<span class="tab-icon"><?php echo esc_html($tab['tab_icon']); ?></span>
							<span class="tab-label"><?php echo esc_html($tab['tab_label']); ?></span>
						</button>
						<?php
						$first_tab = false;
						$loop_index++;
					endforeach;
					?>
				</div>

				<!-- RENDERIZAÇÃO DO CONTEÚDO DAS ABAS -->
				<?php
				$loop_index = 0;
				$first_content = true;
				foreach ($settings['tabs_list'] as $tab):
					$active_class_content = $first_content ? 'active' : '';
					$current_tab_id = $tab['tab_id'];
					?>
					<div class="tab-content <?php echo $active_class_content; ?>" data-content-index="<?php echo $loop_index; ?>">
						<div class="solutions-grid">

							<?php
							$cards_found = false;
							if (!empty($settings['cards_list'])):
								foreach ($settings['cards_list'] as $card):
									// Normaliza os IDs para comparação (remove espaços e poe em minusculo)
									$tab_id_clean = sanitize_title($current_tab_id);
									$card_id_clean = sanitize_title($card['solution_tab_id']);

									// COMPARAÇÃO RELAXADA: Se os IDs sanitizados baterem, exibe.
									if ($tab_id_clean === $card_id_clean):
										$cards_found = true;
										$featured_class = ('yes' === $card['is_featured']) ? 'featured' : '';

										// CTA Link Attributes
										$target = $card['cta_url']['is_external'] ? ' target="_blank"' : '';
										$nofollow = $card['cta_url']['nofollow'] ? ' rel="nofollow"' : '';

										// Process Features Text
										$features = explode("\n", $card['card_features_text']);
										?>
										<div class="solution-card <?php echo esc_attr($featured_class); ?>">
											<div class="card-header">
												<div class="card-icon"><?php echo esc_html($card['card_icon']); ?></div>
												<?php if ('yes' === $card['show_ai_badge']): ?>
													<span class="ai-badge">IA</span>
												<?php endif; ?>
											</div>
											<h3><?php echo esc_html($card['card_title']); ?></h3>
											<p><?php echo esc_html($card['card_description']); ?></p>

											<ul class="feature-list">
												<?php foreach ($features as $feature): ?>
													<?php if (!empty(trim($feature))): ?>
														<li><?php echo esc_html($feature); ?></li>
													<?php endif; ?>
												<?php endforeach; ?>
											</ul>

											<a href="<?php echo esc_url($card['cta_url']['url']); ?>" class="card-btn" <?php echo $target . $nofollow; ?>>
												<?php echo esc_html($card['cta_text']); ?>
											</a>
										</div>
										<?php
									endif;
								endforeach;
							endif;

							// Mensagem caso não existam cards para esta aba (apenas no editor)
							if (!$cards_found && \Elementor\Plugin::$instance->editor->is_edit_mode()):
								?>
								<div
									style="grid-column: 1 / -1; padding: 20px; border: 2px dashed #ccc; text-align: center; color: #666;">
									Nenhum card encontrado para a aba: <strong><?php echo esc_html($current_tab_id); ?></strong>.<br>
									(ID normalizado buscado: <em><?php echo esc_html($tab_id_clean); ?></em>)
								</div>
							<?php endif; ?>

						</div>
					</div>
					<?php
					$first_content = false;
					$loop_index++;
				endforeach;
				?>
			</div>

			<div class="solutions-cta">
				<h3><?php echo esc_html($settings['footer_cta_title']); ?></h3>
				<p><?php echo esc_html($settings['footer_cta_desc']); ?></p>
				<?php
				$footer_target = $settings['footer_cta_link']['is_external'] ? ' target="_blank"' : '';
				$footer_nofollow = $settings['footer_cta_link']['nofollow'] ? ' rel="nofollow"' : '';
				?>
				<a href="<?php echo esc_url($settings['footer_cta_link']['url']); ?>" class="btn-primary" <?php echo $footer_target . $footer_nofollow; ?>>
					<?php echo esc_html($settings['footer_cta_btn_text']); ?>
				</a>
			</div>
		</div>

		<script>
			jQuery(document).ready(function ($) {
				// Usando delegação de evento para garantir que funcione mesmo com AJAX/Elementor
				$(document).on('click', '.tab-btn', function (e) {
					e.preventDefault();

					var $btn = $(this);
					var $container = $btn.closest('.solutions-tabs');
					var index = $btn.data('tab-index');

					// Debug
					// console.log('Tab Click Index:', index);

					// 1. Remove active class de todos os botões e conteúdos DENTRO deste container
					$container.find('.tab-btn').removeClass('active');
					$container.find('.tab-content').removeClass('active').hide();

					// 2. Adiciona active no botão clicado
					$btn.addClass('active');

					// 3. Mostra o conteúdo correspondente
					var $target = $container.find('.tab-content[data-content-index="' + index + '"]');
					$target.addClass('active').fadeIn(300); // fadeIn para suavidade e garantir display:block
				});

				// Garantir que a primeira aba esteja visível ao carregar (fallback)
				$('.solutions-tabs').each(function () {
					if ($(this).find('.tab-content.active').length === 0) {
						$(this).find('.tab-content').first().addClass('active').show();
						$(this).find('.tab-btn').first().addClass('active');
					}
				});
			});
		</script>

		<?php
	}
}
