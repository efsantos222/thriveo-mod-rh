<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Proftest_Contact_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'proftest_contact';
    }

    public function get_title()
    {
        return esc_html__('Proftest Contact Form', 'proftest-elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    public function get_categories()
    {
        return ['general'];
    }

    public function get_style_depends()
    {
        return ['proftest-tabs-style'];
    }

    protected function register_controls()
    {

        // ==========================================
        // COLUNA 1: Informações
        // ==========================================
        $this->start_controls_section(
            'section_contact_info',
            [
                'label' => esc_html__('Coluna 1: Informações', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'contact_title',
            [
                'label' => esc_html__('Título Principal', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Agende uma Demonstração Gratuita', 'proftest-elementor-addon'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'contact_description',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Veja na prática como a ProfTest pode transformar sua gestão de pessoas. Nossa equipe vai apresentar as soluções ideais para sua empresa.', 'proftest-elementor-addon'),
            ]
        );

        // Repeater for Benefits (Green Checks)
        $repeater_benefits = new \Elementor\Repeater();

        $repeater_benefits->add_control(
            'benefit_title',
            [
                'label' => esc_html__('Título do Benefício', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Demo Personalizada',
            ]
        );

        $repeater_benefits->add_control(
            'benefit_desc',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Focada nas suas necessidades específicas',
            ]
        );

        $this->add_control(
            'benefits_list',
            [
                'label' => esc_html__('Lista de Benefícios (Checks)', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_benefits->get_controls(),
                'default' => [
                    ['benefit_title' => 'Demo Personalizada', 'benefit_desc' => 'Focada nas suas necessidades específicas'],
                    ['benefit_title' => 'Sem Compromisso', 'benefit_desc' => 'Conhecer a plataforma é totalmente gratuito'],
                    ['benefit_title' => 'Proposta em 24h', 'benefit_desc' => 'Receba uma proposta personalizada rapidamente'],
                ],
                'title_field' => '{{{ benefit_title }}}',
            ]
        );

        // Separator
        $this->add_control(
            'hr_contacts',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'contact_subtitle',
            [
                'label' => esc_html__('Subtítulo Contato', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Ou entre em contato direto:',
            ]
        );

        $this->add_control(
            'phone_number',
            [
                'label' => esc_html__('Telefone', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '(11) 99999-9999',
            ]
        );

        $this->add_control(
            'email_address',
            [
                'label' => esc_html__('E-mail', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'contato@proftest.com.br',
            ]
        );

        $this->add_control(
            'whatsapp_btn_text',
            [
                'label' => esc_html__('Texto Botão WhatsApp', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'WhatsApp',
            ]
        );

        $this->add_control(
            'whatsapp_link',
            [
                'label' => esc_html__('Link WhatsApp', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => 'https://wa.me/...',
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // ==========================================
        // COLUNA 2: Formulário (Shortcode)
        // ==========================================
        $this->start_controls_section(
            'section_contact_form',
            [
                'label' => esc_html__('Coluna 2: Formulário', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'cf7_shortcode',
            [
                'label' => esc_html__('Shortcode do Contact Form 7', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => '[contact-form-7 id="123" title="Form"]',
                'description' => 'Cole aqui o shortcode do seu formulário.',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>

        <div class="proftest-contact-section">
            <div class="proftest-contact-container">

                <!-- COLUMN 1: INFO -->
                <div class="contact-info-col">
                    <h2 class="contact-title"><?php echo esc_html($settings['contact_title']); ?></h2>
                    <p class="contact-desc"><?php echo esc_html($settings['contact_description']); ?></p>

                    <div class="contact-benefits">
                        <?php foreach ($settings['benefits_list'] as $item): ?>
                            <div class="benefit-item">
                                <div class="benefit-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="benefit-text">
                                    <h4 class="benefit-title"><?php echo esc_html($item['benefit_title']); ?></h4>
                                    <p class="benefit-desc"><?php echo esc_html($item['benefit_desc']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="contact-direct">
                        <p class="direct-subtitle"><?php echo esc_html($settings['contact_subtitle']); ?></p>

                        <?php if (!empty($settings['phone_number'])): ?>
                            <div class="direct-item">
                                <i class="fas fa-phone-alt"></i>
                                <span><?php echo esc_html($settings['phone_number']); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($settings['email_address'])): ?>
                            <div class="direct-item">
                                <i class="fas fa-envelope"></i>
                                <span><?php echo esc_html($settings['email_address']); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($settings['whatsapp_btn_text'])):
                            $wa_target = $settings['whatsapp_link']['is_external'] ? ' target="_blank"' : '';
                            ?>
                            <a href="<?php echo esc_url($settings['whatsapp_link']['url']); ?>" class="whatsapp-btn" <?php echo $wa_target; ?>>
                                <i class="fab fa-whatsapp"></i>
                                <?php echo esc_html($settings['whatsapp_btn_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- COLUMN 2: FORM -->
                <div class="contact-form-col">
                    <div class="form-wrapper">
                        <?php
                        if (!empty($settings['cf7_shortcode'])) {
                            echo do_shortcode($settings['cf7_shortcode']);
                        } else {
                            echo '<div class="elementor-alert elementor-alert-info">Insira o shortcode do Contact Form 7 nas configurações do widget.</div>';
                        }
                        ?>

                        <div class="form-footer-lock">
                            <i class="fas fa-lock"></i> Seus dados estão seguros. Respeitamos sua privacidade conforme a LGPD.
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php
    }
}
