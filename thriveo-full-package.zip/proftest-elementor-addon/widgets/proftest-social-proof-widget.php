<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Proftest_Social_Proof_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'proftest_social_proof';
    }

    public function get_title()
    {
        return esc_html__('Proftest Social Proof', 'proftest-elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-star-o';
    }

    public function get_categories()
    {
        return ['general'];
    }

    public function get_style_depends()
    {
        return ['proftest-tabs-style']; // We reuse the main stylesheet
    }

    protected function register_controls()
    {

        // ==========================================
        // Header (Título)
        // ==========================================
        $this->start_controls_section(
            'section_header',
            [
                'label' => esc_html__('Cabeçalho', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__('Título', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('CONFIADO POR EMPRESAS LÍDERES:', 'proftest-elementor-addon'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'title_alignment',
            [
                'label' => esc_html__('Alinhamento', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Esquerda', 'proftest-elementor-addon'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Centro', 'proftest-elementor-addon'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Direita', 'proftest-elementor-addon'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
            ]
        );

        $this->end_controls_section();

        // ==========================================
        // Logos das Empresas
        // ==========================================
        $this->start_controls_section(
            'section_logos',
            [
                'label' => esc_html__('Logos de Clientes', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater_logos = new \Elementor\Repeater();

        $repeater_logos->add_control(
            'logo_image',
            [
                'label' => esc_html__('Logo', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater_logos->add_control(
            'logo_name',
            [
                'label' => esc_html__('Nome da Empresa (Alt)', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'logos_list',
            [
                'label' => esc_html__('Lista de Logos', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_logos->get_controls(),
                'default' => [
                    [
                        'logo_name' => 'Cliente 1',
                    ],
                    [
                        'logo_name' => 'Cliente 2',
                    ],
                ],
                'title_field' => '{{{ logo_name }}}',
            ]
        );

        $this->add_control(
            'show_extra_badge',
            [
                'label' => esc_html__('Mostrar Texto Extra ao lado?', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Sim',
                'label_off' => 'Não',
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'extra_badge_text',
            [
                'label' => esc_html__('Texto Extra (ex: +500 empresas)', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '+ 500 empresas',
                'condition' => [
                    'show_extra_badge' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // ==========================================
        // Cards de Estatísticas
        // ==========================================
        $this->start_controls_section(
            'section_stats',
            [
                'label' => esc_html__('Cards de Estatísticas', 'proftest-elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater_stats = new \Elementor\Repeater();

        $repeater_stats->add_control(
            'stat_icon',
            [
                'label' => esc_html__('Ícone', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater_stats->add_control(
            'stat_number',
            [
                'label' => esc_html__('Número (Destaque)', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '50.000+',
                'label_block' => true,
            ]
        );

        $repeater_stats->add_control(
            'stat_title',
            [
                'label' => esc_html__('Título', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Colaboradores Avaliados',
                'label_block' => true,
            ]
        );

        $repeater_stats->add_control(
            'stat_description',
            [
                'label' => esc_html__('Descrição', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Processos de avaliação realizados com sucesso',
            ]
        );

        $this->add_control(
            'stats_list',
            [
                'label' => esc_html__('Lista de Estatísticas', 'proftest-elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_stats->get_controls(),
                'default' => [
                    [
                        'stat_number' => '50.000+',
                        'stat_title' => 'Colaboradores',
                        'stat_description' => 'Avaliados com sucesso na plataforma',
                    ],
                    [
                        'stat_number' => '500+',
                        'stat_title' => 'Empresas',
                        'stat_description' => 'De startups a grandes corporações',
                    ],
                ],
                'title_field' => '{{{ stat_number }}} - {{{ stat_title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        // Alignment Class
        $align_class = 'text-' . $settings['title_alignment'];
        ?>

        <div class="proftest-social-proof">
            <!-- Header & Logos -->
            <div class="social-proof-header <?php echo esc_attr($align_class); ?>">
                <?php if (!empty($settings['section_title'])): ?>
                    <h4 class="sp-title"><?php echo esc_html($settings['section_title']); ?></h4>
                <?php endif; ?>

                <div class="sp-logos-container">
                    <?php if (!empty($settings['logos_list'])): ?>
                        <?php foreach ($settings['logos_list'] as $logo): ?>
                            <?php if (!empty($logo['logo_image']['url'])): ?>
                                <div class="sp-logo-item">
                                    <img src="<?php echo esc_url($logo['logo_image']['url']); ?>"
                                        alt="<?php echo esc_attr($logo['logo_name']); ?>" class="sp-logo-img">
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if ('yes' === $settings['show_extra_badge']): ?>
                        <div class="sp-extra-badge">
                            <?php echo esc_html($settings['extra_badge_text']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Separator -->
            <div class="sp-separator"></div>

            <!-- Stats Grid -->
            <div class="sp-stats-grid">
                <?php if (!empty($settings['stats_list'])): ?>
                    <?php foreach ($settings['stats_list'] as $stat): ?>
                        <div class="sp-stat-card">
                            <div class="sp-stat-icon-wrapper">
                                <?php \Elementor\Icons_Manager::render_icon($stat['stat_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="sp-stat-content">
                                <span class="sp-stat-number"><?php echo esc_html($stat['stat_number']); ?></span>
                                <h5 class="sp-stat-title"><?php echo esc_html($stat['stat_title']); ?></h5>
                                <p class="sp-stat-desc"><?php echo esc_html($stat['stat_description']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php
    }
}
