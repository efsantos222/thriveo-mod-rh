jQuery(window).on('elementor/frontend/init', function () {
    elementorFrontend.hooks.addAction('frontend/element_ready/proftest_tabs.default', function ($scope, $) {
        // console.log('Proftest Tabs Widget (Index-Based) Initialized');

        const tabButtons = $scope.find('.tab-btn');
        const tabContents = $scope.find('.tab-content');

        tabButtons.on('click', function (e) {
            e.preventDefault();

            // Remove active from all
            tabButtons.removeClass('active');
            tabContents.removeClass('active').hide();

            // Add active to clicked
            $(this).addClass('active');

            // Get Index 
            const index = $(this).data('tab-index');
            // console.log('Switching to index:', index);

            // Activate content with matching index
            const targetContent = $scope.find('.tab-content[data-content-index="' + index + '"]');

            if (targetContent.length > 0) {
                targetContent.addClass('active').show(); // Force show
            } else {
                console.warn('No content found for index:', index);
            }
        });
    });
});
