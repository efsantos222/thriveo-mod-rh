<?php
/**
 * Unified Platform Dashboard for Admins
 */

if (!defined('ABSPATH')) exit;

// Check security
$user_id = get_current_user_id();
if (!$user_id) {
    wp_redirect(wp_login_url());
    exit;
}

global $wpdb;

// Identify user role in the platform
$plt_user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE wp_user_id = %d",
    $user_id
));

if (!$plt_user) {
    // If user is WP Admin but not in our table, auto-register as super_admin for convenience
    if (current_user_can('manage_options')) {
        $wpdb->insert("{$wpdb->prefix}thriveo_plataforma_usuarios", [
            'wp_user_id' => $user_id,
            'role' => 'super_admin'
        ]);
        $plt_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE wp_user_id = %d", $user_id));
    } else {
        echo "Acesso negado. Você não tem permissões de plataforma.";
        exit;
    }
}

$role = $plt_user->role;
$is_super = ($role === 'super_admin');
$empresa_id = $plt_user->empresa_id;

// Logic for switching tabs
$active_tab = $_GET['tab'] ?? 'dashboard';

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thriveo Pro | Plataforma Unificada</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0052cc;
            --sidebar: #0f172a;
            --bg: #f8fafc;
            --card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
        }

        * { margin:0; padding:0; box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text-main); display: flex; height: 100vh; overflow: hidden; }

        /* Sidebar */
        .sidebar { width: 260px; background: var(--sidebar); color: white; display: flex; flex-direction: column; padding: 30px 0; }
        .logo { padding: 0 30px 40px; font-size: 1.5rem; font-weight: 800; display: flex; align-items: center; gap: 10px; }
        .logo span { color: var(--primary); }

        .menu { list-style: none; flex-grow: 1; }
        .menu-item a { 
            display: flex; align-items: center; gap: 15px; padding: 15px 30px; 
            color: #94a3b8; text-decoration: none; transition: 0.3s; font-weight: 500;
        }
        .menu-item a:hover, .menu-item.active a { color: white; background: rgba(255,255,255,0.05); border-left: 4px solid var(--primary); }

        /* Main Content */
        .main { flex-grow: 1; overflow-y: auto; padding: 40px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px; }
        .welcome h1 { font-size: 1.8rem; font-weight: 800; }
        .welcome p { color: var(--text-muted); }

        /* Dashboard Cards */
        .grid-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px; margin-bottom: 40px; }
        .stat-card { background: white; padding: 24px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .stat-card h3 { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 10px; }
        .stat-card .value { font-size: 2rem; font-weight: 800; }

        .btn { padding: 10px 20px; border-radius: 8px; font-weight: 600; border: none; cursor: pointer; transition: 0.3s; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: var(--primary); color: white; }
        
        /* Table Styles */
        .table-area { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { text-align: left; padding: 15px; border-bottom: 2px solid #f1f5f9; color: var(--text-muted); font-weight: 600; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; }
        
        .badge { padding: 4px 10px; border-radius: 100px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
        .badge-active { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div class="logo">Thriveo<span>Pro</span></div>
        <ul class="menu">
            <li class="menu-item <?php echo $active_tab == 'dashboard' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=dashboard"><i class="fas fa-chart-pie"></i> Dashboard</a>
            </li>
            <?php if ($is_super): ?>
            <li class="menu-item <?php echo $active_tab == 'empresas' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=empresas"><i class="fas fa-building"></i> Empresas</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'modulos' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=modulos"><i class="fas fa-cubes"></i> Módulos</a>
            </li>
            <?php endif; ?>
            <li class="menu-item <?php echo $active_tab == 'usuarios' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=usuarios"><i class="fas fa-users"></i> Usuários</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'pagamentos' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=pagamentos"><i class="fas fa-credit-card"></i> Pagamentos</a>
            </li>
        </ul>
        <div style="padding: 20px 30px; border-top: 1px solid rgba(255,255,255,0.05);">
            <a href="<?php echo wp_logout_url(home_url()); ?>" style="color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.9rem;">
                <i class="fas fa-sign-out-alt"></i> Sair da Plataforma
            </a>
        </div>
    </aside>

    <main class="main">
        <header class="header">
            <div class="welcome">
                <h1>Painel Administrativo</h1>
                <p>Gerencie sua operação Thriveo com inteligência.</p>
            </div>
            <div class="user-profile" style="display:flex; align-items:center; gap:15px;">
                <div style="text-align:right;">
                    <div style="font-weight:700;"><?php echo esc_html(wp_get_current_user()->display_name); ?></div>
                    <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo strtoupper($role); ?></div>
                </div>
                <div style="width:40px; height:40px; background:var(--primary); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:800;">
                    <?php echo strtoupper(substr(wp_get_current_user()->display_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <?php if ($active_tab == 'dashboard'): ?>
            <div class="grid-stats">
                <div class="stat-card">
                    <h3>Empresas (AI Jobs)</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_ai_companies"); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Candidatos (IA)</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_ai_candidates"); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total de Vagas</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_vagas"); ?></div>
                </div>
            </div>

            <div class="table-area">
                <h2>Ações Recentes</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Ação</th>
                            <th>Usuário</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo date('d/m/Y'); ?></td>
                            <td>Acesso ao Sistema IA</td>
                            <td>Super Admin</td>
                            <td><span class="badge badge-active">Log OK</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>

        <?php elseif ($active_tab == 'empresas'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Gestão de Empresas</h2>
                    <button class="btn btn-primary" onclick="openNewCompanyModal()"><i class="fas fa-plus"></i> Nova Empresa</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Empresa</th>
                            <th>CNPJ</th>
                            <th>Plataforma</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Buscamos as empresas da Inteligência Artificial (Job Board)
                        $empresas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}thriveo_ai_companies ORDER BY created_at DESC");
                        
                        // Fallback para a tabela unificada se houver algo lá também
                        $empresas_uni = $wpdb->get_results("SELECT id, nome_fantasia as company_name, cnpj, criado_em as created_at FROM {$wpdb->prefix}thriveo_empresas");
                        
                        if ($empresas): foreach($empresas as $emp):
                        ?>
                        <tr>
                            <td>#<?php echo $emp->id; ?></td>
                            <td><strong><?php echo esc_html($emp->company_name); ?></strong></td>
                            <td><?php echo esc_html($emp->cnpj ?: 'Não inf.'); ?></td>
                            <td><span class="badge badge-active">IA Jobs</span></td>
                            <td>
                                <a href="#" style="color:var(--primary);margin-right:10px;" title="Editar"><i class="fas fa-edit"></i></a>
                                <a href="#" style="color:#ef4444;" title="Excluir"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding: 40px;">Nenhuma empresa cadastrada na Inteligência Artificial.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($active_tab == 'pagamentos'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Pagamentos e Dados para NF-e</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Empresa / Razão Social</th>
                            <th>Plano</th>
                            <th>Valor</th>
                            <th>Status</th>
                            <th>Dados de Cobrança (NF-e)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $pagamentos = $wpdb->get_results("
                            SELECT f.*, a.empresa_id, c.razao_social, c.cnpj, c.endereco, c.bairro, c.cidade, c.estado, c.cep, p.nome as plano_nome
                            FROM {$wpdb->prefix}thriveo_pagbank_faturas f
                            LEFT JOIN {$wpdb->prefix}thriveo_pagbank_assinaturas a ON f.assinatura_id = a.id
                            LEFT JOIN {$wpdb->prefix}thriveo_ai_companies c ON a.empresa_id = c.id
                            LEFT JOIN {$wpdb->prefix}thriveo_pagbank_planos p ON a.plano_id = p.id
                            ORDER BY f.criado_em DESC
                        ");
                        if ($pagamentos): foreach($pagamentos as $pg):
                        ?>
                        <tr>
                            <td><?php echo date('d/m/Y H:i', strtotime($pg->criado_em)); ?></td>
                            <td>
                                <strong><?php echo esc_html($pg->razao_social ?: 'Pendente'); ?></strong><br>
                                <small>CNPJ: <?php echo esc_html($pg->cnpj); ?></small>
                            </td>
                            <td><?php echo esc_html($pg->plano_nome); ?></td>
                            <td>R$ <?php echo number_format($pg->valor, 2, ',', '.'); ?></td>
                            <td>
                                <span class="badge <?php echo ($pg->status == 'pago' || $pg->status == 'ativa') ? 'badge-active' : ''; ?>" style="background:<?php echo ($pg->status == 'pago' || $pg->status == 'ativa') ? '#dcfce7' : '#fee2e2'; ?>; color:<?php echo ($pg->status == 'pago' || $pg->status == 'ativa') ? '#166534' : '#991b1b'; ?>">
                                    <?php echo strtoupper($pg->status); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.8rem; line-height: 1.4;">
                                <?php if ($pg->endereco): ?>
                                    <i class="fas fa-map-marker-alt" style="color:var(--primary);"></i> <?php echo esc_html($pg->endereco); ?><br>
                                    <?php echo esc_html($pg->bairro); ?> - <?php echo esc_html($pg->cidade); ?>/<?php echo esc_html($pg->estado); ?><br>
                                    CEP: <?php echo esc_html($pg->cep); ?>
                                <?php else: ?>
                                    <span style="color:var(--text-muted);">Dados não preenchidos</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="6" style="text-align:center; padding: 40px;">Nenhum pagamento encontrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </main>

    <!-- Modal Nova Empresa -->
    <div id="modalNewCompany" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:500px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);">
            <h2 style="margin-bottom:20px;">Cadastrar Nova Empresa</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('new_company_admin'); ?>
                <input type="hidden" name="thriveo_action" value="create_company">
                
                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Nome da Empresa *</label>
                    <input type="text" name="company_name" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                
                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Email do Administrador *</label>
                    <input type="email" name="admin_email" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;" placeholder="Este usuário será o dono da empresa">
                </div>

                <div style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Plano Inicial</label>
                    <select name="is_paying" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <option value="0">Grátis (1 vaga)</option>
                        <option value="1">Premium (Liberar cota)</option>
                    </select>
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px;">
                    <button type="button" class="btn" onclick="closeNewCompanyModal()" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar Empresa</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openNewCompanyModal() {
            document.getElementById('modalNewCompany').style.display = 'flex';
        }
        function closeNewCompanyModal() {
            document.getElementById('modalNewCompany').style.display = 'none';
        }
    </script>
</body>
</html>

<?php 
// Logic for handling the creation form (simple implementation)
if (isset($_POST['thriveo_action']) && $_POST['thriveo_action'] === 'create_company' && wp_verify_nonce($_POST['_wpnonce'], 'new_company_admin')) {
    $email = sanitize_email($_POST['admin_email']);
    $name = sanitize_text_field($_POST['company_name']);
    $is_paying = intval($_POST['is_paying']);

    $user = get_user_by('email', $email);
    if (!$user) {
        $username = explode('@', $email)[0] . time();
        $user_id = wp_create_user($username, wp_generate_password(), $email);
    } else {
        $user_id = $user->ID;
    }

    if (!is_wp_error($user_id)) {
        $wpdb->insert($wpdb->prefix . 'thriveo_ai_companies', [
            'wp_user_id' => $user_id,
            'company_name' => $name,
            'is_paying' => $is_paying
        ]);
        echo "<script>window.location.href = window.location.href + '&success=1';</script>";
        exit;
    }
}
?>
