# Thriveo AI Jobs - Ecossistema de Recrutamento Tech

O **Thriveo AI Jobs** é um plugin robusto para WordPress focado na conexão entre profissionais de Inteligência Artificial e empresas inovadoras. Este projeto utiliza IA para otimizar o processo de recrutamento através de avaliações técnicas, comportamentais e entrevistas automatizadas.

## 🚀 Principais Funcionalidades

- **Unified Design System**: Interface moderna com Sidebar e Bento Grid, unificada em todos os módulos para uma experiência de usuário fluida.
- **Portal de Vagas**: Listagem inteligente com sistema de fallback para logos (usando iniciais da empresa) e carregamento otimizado.
- **Matching IA**: Algoritmo que analisa semanticamente a compatibilidade entre o perfil do candidato e os requisitos da vaga.
- **Entrevista IA**: Módulo de simulação onde o candidato pratica entrevistas com um recrutador virtual baseado em GPT.
- **Central de Ajuda (FAQ)**: Base de conhecimento integrada com respostas rápidas sobre o uso da plataforma para candidatos e empresas.
- **Painel da Empresa**: Gestão simplificada de publicações com integração de pagamento Checkout Pro (Mercado Pago).
- **Certificações D1 a D4**: Sistema de selos (Elite Certified) que valida Perfil, Hard Skills, Soft Skills e Reputação.

## 📂 Estrutura do Projeto

- `/assets`: Recursos estáticos (CSS unificado, JavaScript de widgets).
- `/includes`: Core do plugin (Controllers, Schemas de DB, Integração OpenAI e Mercado Pago).
- `/templates`: Arquivos de interface do usuário segmentados por módulo (Dashboard, Vagas, FAQ, etc).
- `thriveo-ai-jobs.php`: Arquivo principal de ativação e registro de componentes.

## 🛠️ Tecnologias Utilizadas

- **PHP**: Back-end (WordPress/WooCommerce hooks).
- **JavaScript**: Lógica de interface e chamadas assíncronas (Fetch API).
- **CSS3 / Flexbox / Grid**: Design responsivo com variáveis unificadas.
- **OpenAI API**: Processamento de linguagem natural para matching e entrevistas.
- **Mercado Pago API**: Integração de pagamentos para serviços premium.

## 📦 Instalação

1. Comprima a pasta `thriveo-ai-jobs` em um arquivo `.zip`.
2. No painel WordPress, vá em `Plugins > Adicionar Novo > Enviar Plugin`.
3. Ative o plugin e configure as constantes de API no arquivo principal.

## 🔒 Segurança e Versionamento

O projeto conta com um arquivo `.gitignore` configurado para proteger logs e arquivos de sistema, garantindo um repositório Git limpo.

---
© 2026 Thriveo - Sistemas de Planejamento e Gestão de Pessoas.
