<?php
/**
 * Controller for Payments (Mercado Pago / PagSeguro)
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Pagamentos_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        add_action('wp_ajax_nopriv_thriveo_get_pagbank_key', [__CLASS__, 'get_public_key']);
        
        add_action('wp_ajax_thriveo_create_subscription', [__CLASS__, 'create_subscription_ajax']);

        add_action('rest_api_init', function () {
            register_rest_route('thriveo/v1', '/mp-webhook', array(
                'methods' => 'POST',
                'callback' => [__CLASS__, 'mp_webhook_handler'],
                'permission_callback' => '__return_true',
            ));
        });
    }

    /**
     * Retorna a Chave Pública para criptografia no Frontend
     */
    public static function get_public_key()
    {
        // Mercado Pago não usa Public Key client-side na abordagem de Checkout Pro com redirects.
        wp_send_json_success([
            'public_key' => 'mercadopago_bypass',
            'environment' => 'sandbox'
        ]);
    }

    /**
     * Cria a Preferência (AJAX) - Substituindo Assinatura PagBank por Checkout Pro MP
     */
    public static function create_subscription_ajax()
    {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Usuário não autenticado.']);
        }

        $plano_slug = sanitize_text_field($_POST['plano_slug']);
        $current_user = wp_get_current_user();

        global $wpdb;
        $tabela_planos = "{$wpdb->prefix}thriveo_pagbank_planos";
        $plano = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabela_planos WHERE slug = %s", $plano_slug));

        if (!$plano) {
            $planos_iniciais = [
                ['nome' => 'Básico', 'slug' => 'basico', 'preco_mensal' => 99.00, 'pagbank_plan_id' => 'PLN_BASICO_TEST', 'descricao' => '1 Vaga Adicional'],
                ['nome' => 'Profissional', 'slug' => 'profissional', 'preco_mensal' => 199.00, 'pagbank_plan_id' => 'PLN_PRO_TEST', 'descricao' => '3 Vagas Adicionais + Destaque'],
                ['nome' => 'Enterprise', 'slug' => 'enterprise', 'preco_mensal' => 499.00, 'pagbank_plan_id' => 'PLN_ENT_TEST', 'descricao' => 'Vagas Ilimitadas + Triagem IA']
            ];
            foreach ($planos_iniciais as $p) {
                $wpdb->insert($tabela_planos, $p);
            }
            $plano = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabela_planos WHERE slug = %s", $plano_slug));
            
            if (!$plano) {
                wp_send_json_error(['message' => 'Plano inválido e falha ao auto-criar.']);
            }
        }

        $tax_id = sanitize_text_field($_POST['tax_id'] ?? '');

        // Prepara dados pro MP
        $subscription_data = [
            'plan_name'      => 'Thriveo - Plano ' . $plano->nome,
            'price'          => $plano->preco_mensal,
            'reference_id'   => 'USER_' . $current_user->ID . '_' . time(),
            'customer_name'  => $current_user->display_name,
            'customer_email' => $current_user->user_email,
            'customer_tax_id'=> $tax_id,
        ];

        // Chamada ao Handler M.Pago
        $response = Thriveo_AI_Jobs_MercadoPago_Handler::criar_preferencia($subscription_data);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'Erro interno de conexão: ' . $response->get_error_message()
            ]);
        }

        if (!$response['success']) {
            $msg = $response['data']['message'] ?? 'Erro desconhecido.';
            wp_send_json_error([
                'message' => 'Erro no Mercado Pago: ' . $msg,
                'debug' => $response['data'],
                'url' => $response['debug_url'] ?? 'N/A'
            ]);
        }

        // Recupera o link de checkout do Mercado Pago
        $payment_link = $response['data']['init_point'] ?? '';

        $sub_id = $response['data']['id'] ?? '';
        $wpdb->insert($wpdb->prefix . 'thriveo_pagbank_assinaturas', [
            'empresa_id' => $current_user->ID,
            'plano_id'   => $plano->id,
            'pagbank_subscription_id' => $sub_id, // armazenamos o pref_id aqui temporariamente
            'status'     => 'pendente',
            'criado_em'  => current_time('mysql')
        ]);

        wp_send_json_success([
            'message' => 'Redirecionando para Mercado Pago...',
            'subscription_id' => $sub_id,
            'payment_link' => $payment_link
        ]);
    }

    /**
     * Webhook Handler - Mercado Pago
     */
    public static function mp_webhook_handler(WP_REST_Request $request)
    {
        $payload = $request->get_json_params() ?: $_POST;
        if (empty($payload)) {
            $payload = json_decode($request->get_body(), true) ?: [];
        }
        
        $topic = $request->get_param('topic') ?? $request->get_param('type') ?? $payload['type'] ?? $payload['topic'] ?? '';
        $action = $request->get_param('action') ?? $payload['action'] ?? '';
        
        $payment_id = '';

        // Try to get payment ID from data -> id
        if (isset($payload['data']['id'])) {
            $payment_id = $payload['data']['id'];
        } 
        // Try flat data.id
        elseif ($request->get_param('data.id')) {
            $payment_id = $request->get_param('data.id');
        } 
        // Try GET id
        elseif (isset($_GET['data_id'])) {
            $payment_id = $_GET['data_id'];
        } 
        elseif (isset($_GET['id']) && (isset($_GET['topic']) || isset($_GET['type']))) {
            $payment_id = $_GET['id'];
        }

        if (empty($payment_id)) {
            // Still return 200 so Mercado Pago doesn't register a failure for ping events
            return new WP_REST_Response('Evento ignorado ou sem ID', 200);
        }

        global $wpdb;
        $event_name = !empty($action) ? $action : $topic;
        $wpdb->insert($wpdb->prefix . 'thriveo_pagbank_webhook_logs', [
            'evento'    => $event_name,
            'payload'   => wp_json_encode($payload ?: $_GET),
            'criado_em' => current_time('mysql')
        ]);
        $log_id = $wpdb->insert_id;

        // Validar na API do Mercado Pago
        $payment_details = Thriveo_AI_Jobs_MercadoPago_Handler::get_payment($payment_id);
        if (!$payment_details['success'] || empty($payment_details['data'])) {
            return new WP_REST_Response('Falha ao validar pagamento no MP', 200); // 200 pra não reenviar
        }

        $payment_data = $payment_details['data'];
        $status = $payment_data['status'] ?? '';
        $external_reference = $payment_data['external_reference'] ?? ''; // ex: USER_123_170000

        if ($status === 'approved' && $external_reference) {
            // Em vez de procurar por sub_id, a gente aprova a vaga do user se der.
            // Para simplificar, Mercado Pago pode informar na preference qual userID.
            // O `external_reference` é USER_$empresa_id_TIME
            if (strpos($external_reference, 'USER_') === 0) {
                $partes = explode('_', $external_reference);
                $empresa_id = $partes[1] ?? 0;

                // Como a tabela de assinaturas foi inserida por este user_id na hora da preferencia, vamos ativa-la
                $assinatura = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}thriveo_pagbank_assinaturas WHERE empresa_id = %d ORDER BY id DESC LIMIT 1", 
                    $empresa_id
                ));

                if ($assinatura) {
                    $wpdb->update($wpdb->prefix . 'thriveo_pagbank_assinaturas', 
                        ['status' => 'ativa'], 
                        ['id' => $assinatura->id]
                    );
                    
                    // Lógica de liberar as vagas fica a encargo da Cota. Como está ativa, ele ganha a cota.
                }
            }
        }

        $wpdb->update($wpdb->prefix . 'thriveo_pagbank_webhook_logs', 
            ['processado' => 1], 
            ['id' => $log_id]
        );

        return new WP_REST_Response('Processado com sucesso', 200);
    }

    /**
     * Sincronously process Mercado Pago's payment when returned to the success URL
     */
    public static function verificar_pagamento_sincrono($payment_id)
    {
        $payment_details = Thriveo_AI_Jobs_MercadoPago_Handler::get_payment($payment_id);
        if (!$payment_details['success'] || empty($payment_details['data'])) {
            return false;
        }

        $payment_data = $payment_details['data'];
        $status = $payment_data['status'] ?? '';
        $external_reference = $payment_data['external_reference'] ?? ''; 

        if ($status === 'approved' && $external_reference) {
            if (strpos($external_reference, 'USER_') === 0) {
                global $wpdb;
                $partes = explode('_', $external_reference);
                $empresa_id = $partes[1] ?? 0;

                $assinatura = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}thriveo_pagbank_assinaturas WHERE empresa_id = %d ORDER BY id DESC LIMIT 1", 
                    $empresa_id
                ));

                if ($assinatura && $assinatura->status !== 'ativa') {
                    $wpdb->update($wpdb->prefix . 'thriveo_pagbank_assinaturas', 
                        ['status' => 'ativa'], 
                        ['id' => $assinatura->id]
                    );
                    return true;
                }
            }
        }
        return false;
    }
}
