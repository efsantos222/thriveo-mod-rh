<?php
/**
 * Controller for Job (Vagas) management
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Vagas_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_save_vaga', [__CLASS__, 'save_vaga']);
        add_action('wp_ajax_nopriv_thriveo_save_vaga', [__CLASS__, 'save_vaga']);
        add_action('wp_ajax_thriveo_get_vagas_empresa', [__CLASS__, 'get_vagas_empresa']);
        add_action('wp_ajax_nopriv_thriveo_get_vagas_empresa', [__CLASS__, 'get_vagas_empresa']);
        add_action('wp_ajax_thriveo_get_vaga_public', [__CLASS__, 'get_vaga_public']);
        add_action('wp_ajax_nopriv_thriveo_get_vagas_list', [__CLASS__, 'get_vagas_list']); // Public list
        add_action('wp_ajax_thriveo_get_vagas_list', [__CLASS__, 'get_vagas_list']);
        add_action('wp_ajax_thriveo_delete_vaga', [__CLASS__, 'delete_vaga']);
    }

    public static function get_vagas_empresa()
    {
        if (!is_user_logged_in())
            wp_send_json_error('Não autorizado', 401);

        global $wpdb;
        $company_table = $wpdb->prefix . 'thriveo_ai_companies';
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';

        $user_id = get_current_user_id();
        $company = $wpdb->get_row($wpdb->prepare("SELECT id FROM $company_table WHERE wp_user_id = %d", $user_id));
        if (!$company) {
            $user_info = get_userdata($user_id);
            $wpdb->insert($company_table, [
                'wp_user_id' => $user_id,
                'company_name' => $user_info->display_name ?: $user_info->user_login,
                'is_paying' => 0
            ]);
            $company = (object) ['id' => $wpdb->insert_id];
        }

        $vagas = $wpdb->get_results($wpdb->prepare("SELECT * FROM $vagas_table WHERE empresa_id = %d ORDER BY criado_em DESC", $company->id), ARRAY_A);

        // Get quota info
        $quota = self::verificar_cota_mensal($company->id);

        wp_send_json_success([
            'vagas' => $vagas,
            'quota' => $quota
        ]);
    }

    public static function save_vaga()
    {
        if (!is_user_logged_in())
            wp_send_json_error('Não autorizado');

        global $wpdb;
        $company_table = $wpdb->prefix . 'thriveo_ai_companies';
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';

        $user_id = get_current_user_id();
        $company = $wpdb->get_row($wpdb->prepare("SELECT id FROM $company_table WHERE wp_user_id = %d", $user_id));
        if (!$company) {
            $user_info = get_userdata($user_id);
            $wpdb->insert($company_table, [
                'wp_user_id' => $user_id,
                'company_name' => $user_info->display_name ?: $user_info->user_login,
                'is_paying' => 0
            ]);
            $company = (object) ['id' => $wpdb->insert_id];
        }

        // Verify quota
        $quota = self::verificar_cota_mensal($company->id);
        $is_new = empty($_POST['id']);
        $status = sanitize_text_field($_POST['status'] ?? 'rascunho');

        if ($is_new && $status === 'ativa' && !$quota['pode_gratis'] && empty($_POST['pagamento_confirmado'])) {
            wp_send_json_error([
                'code' => 'quota_exceeded',
                'message' => 'Cota gratuita mensal atingida. Esta vaga requer pagamento.',
                'custo' => 99.00
            ]);
        }

        $data = [
            'empresa_id' => $company->id,
            'titulo' => sanitize_text_field($_POST['titulo']),
            'slug' => sanitize_title($_POST['titulo']) . '-' . time(),
            'area_atuacao' => sanitize_text_field($_POST['area_atuacao']),
            'nivel' => sanitize_text_field($_POST['nivel']),
            'regime' => sanitize_text_field($_POST['regime']),
            'modalidade' => sanitize_text_field($_POST['modalidade']),
            'cidade' => sanitize_text_field($_POST['cidade']),
            'estado' => sanitize_text_field($_POST['estado']),
            'descricao' => wp_kses_post($_POST['descricao']),
            'responsabilidades' => wp_kses_post($_POST['responsabilidades']),
            'requisitos_obrigatorios' => wp_kses_post($_POST['requisitos_obrigatorios']),
            'requisitos_desejaveis' => wp_kses_post($_POST['requisitos_desejaveis']),
            'stack_json' => wp_json_encode($_POST['stack'] ?? []),
            'salario_min' => floatval($_POST['salario_min'] ?? 0),
            'salario_max' => floatval($_POST['salario_max'] ?? 0),
            'salario_a_combinar' => isset($_POST['salario_a_combinar']) ? 1 : 0,
            'beneficios_json' => wp_json_encode($_POST['beneficios'] ?? []),
            'etapas_processo_json' => wp_json_encode($_POST['etapas'] ?? []),
            'prazo_candidatura' => sanitize_text_field($_POST['prazo_candidatura']),
            'como_candidatar' => sanitize_text_field($_POST['como_candidatar']),
            'status' => $status,
            'tipo_publicacao' => $quota['pode_gratis'] ? 'gratuita' : 'paga',
            'expira_em' => date('Y-m-d H:i:s', strtotime('+30 days'))
        ];

        if (!$is_new) {
            $id = intval($_POST['id']);
            $vaga_anterior = $wpdb->get_row($wpdb->prepare("SELECT status FROM $vagas_table WHERE id = %d AND empresa_id = %d", $id, $company->id));
            
            // Verifica se a vaga está sendo ativada AGORA
            if ($vaga_anterior && $vaga_anterior->status !== 'ativa' && $status === 'ativa') {
                if ($quota['pode_gratis']) {
                    self::atualizar_uso_cota($company->id, 'gratuita');
                    $data['tipo_publicacao'] = 'gratuita';
                } else {
                    wp_send_json_error([
                        'code' => 'quota_exceeded',
                        'message' => 'Cota mensal atingida. Você não pode ativar mais vagas sem renovar seu plano.',
                        'custo' => 99.00
                    ]);
                }
            }

            unset($data['slug'], $data['criado_em']);
            $wpdb->update($vagas_table, $data, ['id' => $id, 'empresa_id' => $company->id]);
            $vaga_id = $id;
        } else {
            $wpdb->insert($vagas_table, $data);
            $vaga_id = $wpdb->insert_id;
        }

        wp_send_json_success(['id' => $vaga_id, 'message' => 'Vaga salva com sucesso!']);
    }

    public static function get_vagas_list()
    {
        global $wpdb;
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';
        $company_table = $wpdb->prefix . 'thriveo_ai_companies';

        $sql = "SELECT v.*, c.company_name, c.logo_url 
                FROM $vagas_table v 
                JOIN $company_table c ON v.empresa_id = c.id 
                WHERE v.status = 'ativa' AND (v.expira_em IS NULL OR v.expira_em > NOW())";

        // Add filters here if needed (area, nivel, modalidade, busca)

        $sql .= " ORDER BY (v.tipo_publicacao = 'paga') DESC, v.criado_em DESC";

        $vagas = $wpdb->get_results($sql, ARRAY_A);

        wp_send_json_success(['vagas' => $vagas]);
    }

    public static function verificar_cota_mensal($empresa_id)
    {
        global $wpdb;

        // Check user subscriptions
        $wp_user_id = $wpdb->get_var($wpdb->prepare("SELECT wp_user_id FROM {$wpdb->prefix}thriveo_ai_companies WHERE id = %d", $empresa_id));
        
        $extra_jobs = 0;
        if ($wp_user_id) {
            $assinaturas = $wpdb->get_results($wpdb->prepare(
                "SELECT p.slug FROM {$wpdb->prefix}thriveo_pagbank_assinaturas a 
                 JOIN {$wpdb->prefix}thriveo_pagbank_planos p ON a.plano_id = p.id
                 WHERE a.empresa_id = %d AND a.status = 'ativa'", 
                 $wp_user_id
            ), ARRAY_A);
            
            foreach ($assinaturas as $ass) {
                if ($ass['slug'] === 'basico') $extra_jobs += 1;
                if ($ass['slug'] === 'profissional') $extra_jobs += 3;
                if ($ass['slug'] === 'enterprise') $extra_jobs += 999;
            }
        }

        $limite = 1 + $extra_jobs;

        // O consumo de vagas agora é simultâneo, quantas vagas ATIVAS a empresa tem?
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';
        $vagas_ativas_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(id) FROM $vagas_table WHERE empresa_id = %d AND status = 'ativa'", 
            $empresa_id
        ));

        if ($vagas_ativas_count < $limite) {
            return ['pode_gratis' => true, 'usadas' => $vagas_ativas_count, 'custo' => 0, 'limite' => $limite];
        }

        return ['pode_gratis' => false, 'usadas' => $vagas_ativas_count, 'custo' => 99.00, 'limite' => $limite];
    }

    public static function delete_vaga()
    {
        if (!is_user_logged_in() || empty($_POST['id'])) {
            wp_send_json_error('Requisição inválida ou não autorizado', 400);
        }

        global $wpdb;
        $company_table = $wpdb->prefix . 'thriveo_ai_companies';
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';

        $user_id = get_current_user_id();
        $company_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $company_table WHERE wp_user_id = %d", $user_id));

        if (!$company_id) {
            wp_send_json_error('Empresa não encontrada', 404);
        }

        $vaga_id = intval($_POST['id']);
        
        // Verifica se a vaga pertence a esta empresa antes de deletar
        $vaga = $wpdb->get_row($wpdb->prepare("SELECT id FROM $vagas_table WHERE id = %d AND empresa_id = %d", $vaga_id, $company_id));
        
        if (!$vaga) {
            wp_send_json_error('Vaga não encontrada ou não pertence a esta empresa', 404);
        }

        $deleted = $wpdb->delete($vagas_table, ['id' => $vaga_id, 'empresa_id' => $company_id]);

        if ($deleted !== false) {
            wp_send_json_success(['message' => 'Vaga excluída com sucesso!']);
        } else {
            wp_send_json_error('Erro ao excluir a vaga no banco de dados', 500);
        }
    }
}
