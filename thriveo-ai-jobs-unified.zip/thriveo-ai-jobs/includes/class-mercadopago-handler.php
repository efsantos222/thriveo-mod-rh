<?php
/**
 * Mercado Pago API Handler for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_MercadoPago_Handler
{
    public static function get_config()
    {
        // By default, it will use the access token configured by the user.
        $token = get_option('thriveo_mp_access_token', 'APP_USR-6889124565101665-031509-11f3e1538e4d1f6a086886c345796a92-16244527');
        return [
            'token' => $token
        ];
    }

    private static function request($method, $endpoint, $body = [])
    {
        $config = self::get_config();
        $url = 'https://api.mercadopago.com' . $endpoint;

        $args = [
            'method'     => $method,
            'timeout'    => 45,
            'sslverify'  => false,
            'headers'    => [
                'Authorization'   => 'Bearer ' . $config['token'],
                'Content-Type'    => 'application/json',
                'User-Agent'      => 'ThriveoAIJobs/1.0.0'
            ],
        ];

        if (!empty($body)) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $data = json_decode($raw_body, true);

        return [
            'success'     => ($code >= 200 && $code < 300),
            'code'        => $code,
            'data'        => $data ?? [],
            'debug_url'   => $url
        ];
    }

    /**
     * Cria a Preferência de Pagamento (Checkout Pro)
     */
    public static function criar_preferencia($dados)
    {
        $payload = [
            'items' => [
                [
                    'title'       => $dados['plan_name'],
                    'quantity'    => 1,
                    'unit_price'  => (float) $dados['price'],
                    'currency_id' => 'BRL'
                ]
            ],
            'payer' => [
                'email' => $dados['customer_email'],
                'name'  => $dados['customer_name']
            ],
            'back_urls' => [
                'success' => home_url('/?thriveo_empresa_vagas=1&mp_status=success'),
                'failure' => home_url('/?thriveo_empresa_vagas=1&mp_status=failure'),
                'pending' => home_url('/?thriveo_empresa_vagas=1&mp_status=pending'),
            ],
            'auto_return' => 'approved',
            'external_reference' => $dados['reference_id']
        ];
        
        // Remove empty payer identification if none is provided
        if (!empty($dados['customer_tax_id'])) {
            $tax_id = preg_replace('/[^0-9]/', '', $dados['customer_tax_id']);
            $type = strlen($tax_id) > 11 ? 'CNPJ' : 'CPF';
            $payload['payer']['identification'] = [
                'type'   => $type,
                'number' => $tax_id
            ];
        }

        return self::request('POST', '/checkout/preferences', $payload);
    }

    /**
     * Busca dados do pagamento no Mercado Pago
     */
    public static function get_payment($payment_id)
    {
        return self::request('GET', '/v1/payments/' . $payment_id);
    }
}
