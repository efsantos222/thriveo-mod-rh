/**
 * Candidatos Talent Bank JS
 */

const initTalentos = () => {
    const talentGrid = document.getElementById('talent-results');
    const searchInput = document.getElementById('search-input');
    const filters = document.querySelectorAll('.filter-section select');

    const load = async (paged = 1) => {
        const query = new URLSearchParams({
            action: 'thriveo_get_candidatos',
            busca: searchInput.value,
            paged: paged
        });
        
        filters.forEach(f => query.append(f.id.replace('filter-', ''), f.value));

        const response = await fetch(`${thriveoAiObj.ajaxurl}?${query}`);
        const data = await response.json();
        
        if (data.success) {
            // Render logic...
        }
    };

    if (searchInput) {
        searchInput.addEventListener('input', () => load());
        filters.forEach(f => f.addEventListener('change', () => load()));
        load();
    }
};

document.addEventListener('DOMContentLoaded', initTalentos);
