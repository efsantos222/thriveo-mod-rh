jQuery(document).ready(function ($) {

    // Helper functions
    function th_showError(msg) {
        const el = document.getElementById('th-errorAlert');
        if (el) {
            el.textContent = msg;
            el.classList.add('th-visible');
            setTimeout(() => {
                el.classList.remove('th-visible');
            }, 5000);
        }
    }

    function th_errorMessage(code) {
        const map = {
            state_mismatch: 'Erro de segurança (state inválido). Tente novamente.',
            token_error: 'Não foi possível obter o token de acesso. Tente novamente.',
            linkedin_denied: 'Você cancelou a autorização do LinkedIn.',
            default: 'Ocorreu um erro inesperado. Tente novamente.',
        };
        return map[code] || map.default;
    }

    function th_cleanUrl() {
        if (window.history.replaceState) {
            const url = new URL(window.location);
            url.searchParams.delete('thriveo_token');
            url.searchParams.delete('thriveo_provider');
            url.searchParams.delete('oauth_error');
            url.hash = '';
            window.history.replaceState({}, '', url);
        }
    }

    function th_esc(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function th_renderDashboard(user) {
        $('#th-loginBox').hide();
        $('#th-dashboard').show();
        $('#th-left-dashboard-links').show();

        const provider = localStorage.getItem('thriveo_provider') || user.provider;
        const initial = (user.name || 'U')[0].toUpperCase();

        const avatarHtml = user.avatar
            ? `<img src="${th_esc(user.avatar)}" class="th-profile-avatar" alt="Avatar">`
            : `<div class="th-profile-avatar-placeholder">${initial}</div>`;

        const providerBadge = provider === 'github'
            ? `<div class="th-provider-badge th-github">GITHUB</div>`
            : `<div class="th-provider-badge th-linkedin">LINKEDIN</div>`;

        const rows = [
            user.email ? ['E-mail', th_esc(user.email)] : null,
            user.username ? ['Username', '@' + th_esc(user.username)] : null,
            user.location ? ['Localização', th_esc(user.location)] : null,
            user.company ? ['Empresa', th_esc(user.company)] : null,
            user.public_repos > 0 ? ['Repositórios', user.public_repos] : null,
            user.followers > 0 ? ['Seguidores', user.followers] : null,
        ].filter(Boolean);

        const rowsHtml = rows.map(([label, value]) => `
            <div class="th-profile-row">
                <span class="th-profile-row-label">${label}</span>
                <span class="th-profile-row-value">${value}</span>
            </div>
        `).join('');

        $('#th-profileCard').html(`
            <div class="th-profile-header">
                ${avatarHtml}
                <div>
                    <div class="th-profile-name">${th_esc(user.name || 'Profissional')}</div>
                    <div class="th-profile-email">${th_esc(user.email || '')}</div>
                    ${providerBadge}
                </div>
            </div>
            ${rowsHtml}
            ${user.bio ? `<div style="padding-top:12px;font-size:13px;color:#888;line-height:1.6">${th_esc(user.bio)}</div>` : ''}
        `);

        // Repositórios GitHub
        if (user.top_repos && Array.isArray(user.top_repos) && user.top_repos.length > 0) {
            $('#th-reposSection').show();
            $('#th-reposList').html(user.top_repos.slice(0, 5).map(r => `
                <a href="${th_esc(r.url)}" target="_blank" rel="noopener" class="th-repo-item">
                    <div class="th-repo-name">${th_esc(r.name)}</div>
                    ${r.description ? `<div class="th-repo-desc">${th_esc(r.description)}</div>` : ''}
                    <div class="th-repo-meta">
                        ${r.language ? `<span class="th-repo-tag">⬡ ${th_esc(r.language)}</span>` : ''}
                        ${r.stars > 0 ? `<span class="th-repo-tag">★ ${r.stars}</span>` : ''}
                    </div>
                </a>
            `).join(''));
        } else {
            $('#th-reposSection').hide();
        }
    }

    async function th_loadProfile() {
        const token = localStorage.getItem('thriveo_token');
        if (!token) return;

        try {
            const res = await fetch(`${thriveoAiObj.ajaxurl}?action=thriveo_get_me`, {
                headers: { 'Authorization': 'Bearer ' + token }
            });
            const data = await res.json();

            if (!res.ok || !data.success) {
                localStorage.removeItem('thriveo_token');
                // th_showError('Sessão expirada. Faça login novamente.');
                return;
            }

            th_renderDashboard(data.data.user);
        } catch (e) {
            console.error('Erro ao carregar perfil:', e);
            // th_showError('Erro ao conectar com o servidor.');
        }
    }

    // Checking URL parameters for OAuth redirect
    const params = new URLSearchParams(window.location.search);
    const token = params.get('thriveo_token');
    const error = params.get('oauth_error');
    const provider = params.get('thriveo_provider');

    if (error) {
        th_showError(th_errorMessage(error));
        th_cleanUrl();
    } else if (token) {
        localStorage.setItem('thriveo_token', token);
        localStorage.setItem('thriveo_provider', provider || '');
        th_cleanUrl();
        th_loadProfile();
    } else {
        const saved = localStorage.getItem('thriveo_token');
        if (saved) th_loadProfile();
    }

    // Loading internal actions
    $('.th-oauth-btn').on('click', function () {
        $(this).addClass('th-loading');
    });

    $('#th-btnLogout, #th-btnLogout-left, #th-btnLogout-top, #th-btnLogout-company, #th-btnLogout-talents').on('click', function () {
        localStorage.removeItem('thriveo_token');
        localStorage.removeItem('thriveo_provider');
        $('#th-dashboard').hide();
        $('#th-left-dashboard-links').hide();
        $('#th-loginBox').show();
        // Clear cached profile html to avoid flashing
        $('#th-profileCard').empty();
        $('#th-reposSection').hide();

        // Redirecionar para a home para limpar o estado
        window.location.href = '/';
    });

});
