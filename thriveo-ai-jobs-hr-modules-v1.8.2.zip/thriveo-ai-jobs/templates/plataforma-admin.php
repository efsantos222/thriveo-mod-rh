<?php
/**
 * Unified Platform Dashboard for Admins
 */

if (!defined('ABSPATH')) exit;

// Check security
$user_id = get_current_user_id();
if (!$user_id) {
    wp_redirect(wp_login_url());
    exit;
}

global $wpdb;

// Identify user role (pre-fetching for purchase logic)
$temp_plt_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE wp_user_id = %d", $user_id));
$temp_role = $temp_plt_user ? $temp_plt_user->role : '';
$temp_emp_id = $temp_plt_user ? $temp_plt_user->empresa_id : 0;

// Handle Buy Package
if (isset($_GET['buy']) && $temp_role == 'empresa' && $temp_emp_id) {
    $plan_type = sanitize_text_field($_GET['buy']);
    $plans = [
        'start'      => ['name' => 'Pack START (15 usuários)', 'price' => 89.90, 'users' => 15],
        'growth'     => ['name' => 'Pack GROWTH (50 usuários)', 'price' => 199.90, 'users' => 50],
        'business'   => ['name' => 'Pack BUSINESS (200 usuários)', 'price' => 499.90, 'users' => 200],
        'enterprise' => ['name' => 'Pack ENTERPRISE (Ilimitado)', 'price' => 999.90, 'users' => 9999],
    ];

    if (isset($plans[$plan_type])) {
        $plan = $plans[$plan_type];
        $user = wp_get_current_user();
        
        $preference_data = [
            'plan_name'      => $plan['name'],
            'price'          => $plan['price'],
            'customer_name'  => $user->display_name,
            'customer_email' => $user->user_email,
            'reference_id'   => 'TRANS_' . $temp_emp_id . '_' . time(),
            'customer_tax_id' => '', // Could be fetched from company table
        ];

        require_once dirname(__DIR__) . '/includes/class-mercadopago-handler.php';
        $result = Thriveo_AI_Jobs_MercadoPago_Handler::criar_preferencia($preference_data);

        if ($result['success'] && isset($result['data']['init_point'])) {
            wp_redirect($result['data']['init_point']);
            exit;
        }
    }
}

global $wpdb;

// Identify user role in the platform
$plt_user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE wp_user_id = %d",
    $user_id
));

if (!$plt_user) {
    // If user is WP Admin but not in our table, auto-register as super_admin for convenience
    if (current_user_can('manage_options')) {
        $wpdb->insert("{$wpdb->prefix}thriveo_plataforma_usuarios", [
            'wp_user_id' => $user_id,
            'role' => 'super_admin'
        ]);
        $plt_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE wp_user_id = %d", $user_id));
    } else {
        echo "Acesso negado. Você não tem permissões de plataforma.";
        exit;
    }
}

$role = $plt_user->role;
$is_super = ($role === 'super_admin');
$empresa_id = $plt_user->empresa_id;

// Logic for switching tabs
$active_tab = $_GET['tab'] ?? 'dashboard';

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thriveo Pro | Plataforma Unificada</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0052cc;
            --sidebar: #0f172a;
            --bg: #f8fafc;
            --card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
        }

        * { margin:0; padding:0; box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text-main); display: flex; height: 100vh; overflow: hidden; }

        /* Sidebar */
        .sidebar { width: 260px; background: var(--sidebar); color: white; display: flex; flex-direction: column; padding: 30px 0; }
        .logo { padding: 0 30px 40px; font-size: 1.5rem; font-weight: 800; display: flex; align-items: center; gap: 10px; }
        .logo span { color: var(--primary); }

        .menu { list-style: none; flex-grow: 1; }
        .menu-item a { 
            display: flex; align-items: center; gap: 15px; padding: 15px 30px; 
            color: #94a3b8; text-decoration: none; transition: 0.3s; font-weight: 500;
        }
        .menu-item a:hover, .menu-item.active a { color: white; background: rgba(255,255,255,0.05); border-left: 4px solid var(--primary); }

        /* Main Content */
        .main { flex-grow: 1; overflow-y: auto; padding: 40px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px; }
        .welcome h1 { font-size: 1.8rem; font-weight: 800; }
        .welcome p { color: var(--text-muted); }

        /* Dashboard Cards */
        .grid-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px; margin-bottom: 40px; }
        .stat-card { background: white; padding: 24px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .stat-card h3 { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 10px; }
        .stat-card .value { font-size: 2rem; font-weight: 800; }

        .btn { padding: 10px 20px; border-radius: 8px; font-weight: 600; border: none; cursor: pointer; transition: 0.3s; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: var(--primary); color: white; }
        
        /* Table Styles */
        .table-area { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { text-align: left; padding: 15px; border-bottom: 2px solid #f1f5f9; color: var(--text-muted); font-weight: 600; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; }
        
        .badge { padding: 4px 10px; border-radius: 100px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
        .badge-active { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div class="logo">Thriveo<span>Pro</span></div>
        <ul class="menu">
            <li class="menu-item <?php echo $active_tab == 'dashboard' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=dashboard"><i class="fas fa-chart-pie"></i> Dashboard</a>
            </li>
            <?php if ($is_super): ?>
            <li class="menu-item <?php echo $active_tab == 'empresas' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=empresas"><i class="fas fa-building"></i> Empresas</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'modulos' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=modulos"><i class="fas fa-cubes"></i> Módulos</a>
            </li>
            <?php endif; ?>
            <li class="menu-item <?php echo $active_tab == 'usuarios' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=usuarios"><i class="fas fa-users"></i> Usuários</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'pagamentos' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=pagamentos"><i class="fas fa-credit-card"></i> Pagamentos</a>
            </li>
            
            <li style="padding: 20px 30px 10px; color: #475569; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">Módulos RH</li>
            
            <li class="menu-item <?php echo $active_tab == 'disc' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=disc"><i class="fas fa-brain"></i> DISC Assessment</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'zbb' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=zbb"><i class="fas fa-calculator"></i> ZBB (Budget)</a>
            </li>
            <li class="menu-item <?php echo $active_tab == 'pdi' ? 'active' : ''; ?>">
                <a href="?thriveo_pla_admin=1&tab=pdi"><i class="fas fa-user-graduate"></i> PDI & Performance</a>
            </li>
        </ul>
        <div style="padding: 20px 30px; border-top: 1px solid rgba(255,255,255,0.05);">
            <a href="<?php echo wp_logout_url(home_url()); ?>" style="color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.9rem;">
                <i class="fas fa-sign-out-alt"></i> Sair da Plataforma
            </a>
        </div>
    </aside>

    <main class="main">
        <header class="header">
            <div class="welcome">
                <h1>Painel Administrativo</h1>
                <p>Gerencie sua operação Thriveo com inteligência.</p>
            </div>
            <div class="user-profile" style="display:flex; align-items:center; gap:15px;">
                <div style="text-align:right;">
                    <div style="font-weight:700;"><?php echo esc_html(wp_get_current_user()->display_name); ?></div>
                    <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo strtoupper($role); ?></div>
                </div>
                <div style="width:40px; height:40px; background:var(--primary); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:800;">
                    <?php echo strtoupper(substr(wp_get_current_user()->display_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <?php 
        // Trial Alert for Companies
        if (!$is_super && $empresa_id) {
            $company = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_empresas WHERE id = %d", $empresa_id));
            if ($company && !$company->is_paying) {
                $trial_end = strtotime($company->trial_ends_at);
                $days_left = round(($trial_end - time()) / (60 * 60 * 24));
                if ($days_left > 0) {
                    echo "<div class='notice-trial' style='background:#eff6ff; border-left:4px solid #3b82f6; padding:15px; border-radius:8px; margin-bottom:25px; display:flex; justify-content:space-between; align-items:center;'>";
                    echo "<div><strong>Período de Teste:</strong> Você tem $days_left dias restantes de acesso gratuito.</div>";
                    echo "<a href='#' class='btn btn-primary' style='font-size:0.8rem;'>Upgrade Profissional</a>";
                    echo "</div>";
                } else {
                    echo "<div class='notice-trial' style='background:#fff1f2; border-left:4px solid #ef4444; padding:15px; border-radius:8px; margin-bottom:25px; display:flex; justify-content:space-between; align-items:center;'>";
                    echo "<div><strong>Trial Expirado:</strong> Seu período de graça acabou. Adquira um pacote para continuar.</div>";
                    echo "<a href='#' class='btn btn-primary' style='background:#ef4444; font-size:0.8rem;'>Renovar Acesso</a>";
                    echo "</div>";
                }
            }
        }
        ?>

        <?php if ($active_tab == 'dashboard'): ?>
            <div class="grid-stats">
                <div class="stat-card">
                    <h3>Empresas (AI Jobs)</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_ai_companies"); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Candidatos (IA)</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_ai_candidates"); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total de Vagas</h3>
                    <div class="value"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_vagas"); ?></div>
                </div>
            </div>

            <div class="table-area">
                <h2>Ações Recentes</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Ação</th>
                            <th>Usuário</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo date('d/m/Y'); ?></td>
                            <td>Acesso ao Sistema IA</td>
                            <td>Super Admin</td>
                            <td><span class="badge badge-active">Log OK</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>

        <?php elseif ($active_tab == 'empresas'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Gestão de Empresas</h2>
                    <button class="btn btn-primary" onclick="openNewCompanyModal()"><i class="fas fa-plus"></i> Nova Empresa</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Empresa / Razão Social</th>
                            <th>CNPJ</th>
                            <th>Endereço</th>
                            <th>Plataforma</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $empresas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}thriveo_empresas ORDER BY criado_em DESC");
                        
                        if ($empresas): foreach($empresas as $emp):
                        ?>
                        <tr>
                            <td>#<?php echo $emp->id; ?></td>
                            <td>
                                <strong><?php echo esc_html($emp->company_name); ?></strong><br>
                                <small><?php echo esc_html($emp->razao_social); ?></small>
                            </td>
                            <td><?php echo esc_html($emp->cnpj ?: 'Não inf.'); ?></td>
                            <td style="font-size: 0.8rem;"><?php echo esc_html($emp->endereco ? $emp->endereco . ', ' . $emp->cidade . '/' . $emp->estado : 'Não inf.'); ?></td>
                            <td><span class="badge badge-active">IA Jobs</span></td>
                            <td>
                                <button class="btn-icon" style="color:var(--primary); background:none; border:none; cursor:pointer; font-size:1.1rem; margin-right:10px;" onclick='openEditCompanyModal(<?php echo htmlspecialchars(json_encode($emp), ENT_QUOTES, 'UTF-8'); ?>)' title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Excluir esta empresa e todas as suas vagas?');">
                                    <?php wp_nonce_field('delete_company_admin'); ?>
                                    <input type="hidden" name="thriveo_action" value="delete_company">
                                    <input type="hidden" name="company_id" value="<?php echo $emp->id; ?>">
                                    <button type="submit" class="btn-icon" style="color:#ef4444; background:none; border:none; cursor:pointer; font-size:1.1rem;" title="Excluir"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="6" style="text-align:center; padding: 40px;">Nenhuma empresa cadastrada na Inteligência Artificial.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($active_tab == 'pagamentos'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Planos e Upgrade</h2>
                </div>

                <?php if ($role == 'empresa' && $empresa_id): 
                    $comp_info = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_ai_companies WHERE id = %d", $empresa_id));
                    if (!$comp_info->is_paying):
                ?>
                    <div style="background:var(--blue-light); border:1px solid var(--primary); padding:20px; border-radius:12px; margin-bottom:30px;">
                        <h3 style="margin-bottom:10px; color:var(--primary);"><i class="fas fa-rocket"></i> Aproveite mais com o Plano Profissional</h3>
                        <p>Você está no período de teste. Adquira um pacote de usuários para manter acesso a todos os módulos (DISC, ZBB, PDI).</p>
                        
                        <div class="grid-stats" style="grid-template-columns: repeat(4, 1fr); margin-top:20px; gap:15px;">
                            <div class="stat-card" style="border:1px solid #ddd; background:white;">
                                <h4 style="font-size:1.1rem;">Pack START</h4>
                                <div style="font-size:0.8rem; color:var(--text-muted);">Até 15 usuários</div>
                                <div class="value" style="font-size:1.5rem; margin:10px 0;">R$ 89,90<small>/mês</small></div>
                                <button class="btn btn-primary" style="width:100%; font-size:0.8rem;" onclick="location.href='?tab=pagamentos&buy=start'">Comprar</button>
                            </div>
                            <div class="stat-card" style="border:1.5px solid var(--primary); background:white; position:relative;">
                                <span style="position:absolute; top:-10px; right:10px; background:var(--primary); color:white; font-size:0.6rem; padding:2px 8px; border-radius:10px;">POPULAR</span>
                                <h4 style="font-size:1.1rem;">Pack GROWTH</h4>
                                <div style="font-size:0.8rem; color:var(--text-muted);">Até 50 usuários</div>
                                <div class="value" style="font-size:1.5rem; margin:10px 0;">R$ 199,90<small>/mês</small></div>
                                <button class="btn btn-primary" style="width:100%; font-size:0.8rem;" onclick="location.href='?tab=pagamentos&buy=growth'">Comprar</button>
                            </div>
                            <div class="stat-card" style="border:1px solid #ddd; background:white;">
                                <h4 style="font-size:1.1rem;">Pack BUSINESS</h4>
                                <div style="font-size:0.8rem; color:var(--text-muted);">Até 200 usuários</div>
                                <div class="value" style="font-size:1.5rem; margin:10px 0;">R$ 499,90<small>/mês</small></div>
                                <button class="btn btn-primary" style="width:100%; font-size:0.8rem;" onclick="location.href='?tab=pagamentos&buy=business'">Comprar</button>
                            </div>
                            <div class="stat-card" style="border:1px solid #ddd; background:white;">
                                <h4 style="font-size:1.1rem;">Pack ENTERPRISE</h4>
                                <div style="font-size:0.8rem; color:var(--text-muted);">Usuários Ilimitados</div>
                                <div class="value" style="font-size:1.5rem; margin:10px 0;">R$ 999,90<small>/mês</small></div>
                                <button class="btn btn-primary" style="width:100%; font-size:0.8rem;" onclick="location.href='?tab=pagamentos&buy=enterprise'">Comprar</button>
                            </div>
                        </div>
                    </div>
                <?php endif; endif; ?>

                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Pagamentos e Faturas</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Empresa / Razão Social</th>
                            <th>Plano</th>
                            <th>Valor</th>
                            <th>Status</th>
                            <th>Dados de Cobrança (NF-e)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $pagamentos = $wpdb->get_results("
                            SELECT a.*, c.razao_social, c.cnpj, c.endereco, c.bairro, c.cidade, c.estado, c.cep, 
                                   p.nome as plano_nome, p.preco_mensal as valor_plano, 
                                   f.valor as valor_pago, f.status as fatura_status,
                                   u.user_email
                            FROM {$wpdb->prefix}thriveo_pagbank_assinaturas a
                            LEFT JOIN {$wpdb->prefix}thriveo_ai_companies c ON a.empresa_id = c.wp_user_id
                            LEFT JOIN {$wpdb->prefix}thriveo_pagbank_planos p ON a.plano_id = p.id
                            LEFT JOIN {$wpdb->prefix}thriveo_pagbank_faturas f ON a.id = f.assinatura_id
                            LEFT JOIN {$wpdb->users} u ON a.empresa_id = u.ID
                            ORDER BY a.criado_em DESC
                        ");
                        
                        if ($pagamentos): foreach($pagamentos as $pg):
                            $status_label = $pg->fatura_status ?: $pg->status;
                            $valor_exibicao = $pg->valor_pago ?: $pg->valor_plano;
                            $nf_status = $pg->nf_status ?: 'pendente';
                        ?>
                        <tr>
                            <td><?php echo date('d/m/Y H:i', strtotime($pg->criado_em)); ?></td>
                            <td>
                                <strong><?php echo esc_html($pg->razao_social ?: 'Pendente'); ?></strong><br>
                                <small>CNPJ: <?php echo esc_html($pg->cnpj); ?></small><br>
                                <small style="color:var(--primary);">Email: <?php echo esc_html($pg->user_email); ?></small>
                            </td>
                            <td><?php echo esc_html($pg->plano_nome); ?></td>
                            <td>R$ <?php echo number_format($valor_exibicao, 2, ',', '.'); ?></td>
                            <td>
                                <span class="badge" style="background:<?php echo ($status_label == 'pago' || $status_label == 'ativa' || $status_label == 'approved') ? '#dcfce7' : '#fee2e2'; ?>; color:<?php echo ($status_label == 'pago' || $status_label == 'ativa' || $status_label == 'approved') ? '#166534' : '#991b1b'; ?>">
                                    <?php echo strtoupper($status_label); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.8rem; line-height: 1.4;">
                                <?php if ($pg->endereco): ?>
                                    <i class="fas fa-map-marker-alt" style="color:var(--primary);"></i> <?php echo esc_html($pg->endereco); ?><br>
                                    <?php echo esc_html($pg->bairro); ?> - <?php echo esc_html($pg->cidade); ?>/<?php echo esc_html($pg->estado); ?><br>
                                    CEP: <?php echo esc_html($pg->cep); ?>
                                <?php else: ?>
                                    <span style="color:var(--text-muted);">Dados não preenchidos</span>
                                <?php endif; ?>
                            </td>
                            <td style="background:#f1f5f9; padding: 10px; border-radius: 8px;">
                                <form method="POST" style="display:flex; flex-direction:column; gap:5px;">
                                    <?php wp_nonce_field('update_nf_admin'); ?>
                                    <input type="hidden" name="thriveo_action" value="update_nf">
                                    <input type="hidden" name="assinatura_id" value="<?php echo $pg->id; ?>">
                                    <div style="display:flex; gap:5px; align-items:center;">
                                        <input type="text" name="nf_numero" value="<?php echo esc_attr($pg->nf_numero); ?>" placeholder="Nº NF" style="width:80px; font-size:0.8rem; padding:4px;">
                                        <select name="nf_status" style="font-size:0.8rem; padding:4px;">
                                            <option value="pendente" <?php selected($nf_status, 'pendente'); ?>>Pendente</option>
                                            <option value="emitida" <?php selected($nf_status, 'emitida'); ?>>Emitida</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary" style="padding:4px 0; font-size:0.75rem; width:100%;">Salvar NF</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="7" style="text-align:center; padding: 40px;">Nenhum pagamento registrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($active_tab == 'disc'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Resultados DISC</h2>
                    <a href="<?php echo home_url('/avaliacao-disc'); ?>" target="_blank" class="btn btn-outline btn-sm"><i class="fas fa-external-link-alt"></i> Ver Link de Avaliação</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Candidato/Colaborador</th>
                            <th>E-mail</th>
                            <th>Perfil</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $disc_results = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_disc_results WHERE empresa_id = %d ORDER BY completed_at DESC", $empresa_id));
                        if ($disc_results): foreach($disc_results as $res): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($res->completed_at)); ?></td>
                            <td><strong><?php echo esc_html($res->candidate_name); ?></strong></td>
                            <td><?php echo esc_html($res->candidate_email); ?></td>
                            <td><span class="badge" style="background:var(--primary); color:white;"><?php echo $res->predominant_type; ?></span></td>
                            <td><button class="btn btn-sm btn-outline"><i class="fas fa-file-pdf"></i> Laudo</button></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:40px;">Nenhum resultado DISC encontrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($active_tab == 'zbb'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>Zero-Based Budgeting (ZBB)</h2>
                    <?php if ($role == 'empresa' || $role == 'super_admin'): ?>
                        <div class="flex gap-sm">
                            <button class="btn btn-outline btn-sm" onclick="openModal('modalCC')"><i class="fas fa-plus"></i> Centro de Custo</button>
                            <button class="btn btn-outline btn-sm" onclick="openModal('modalCat')"><i class="fas fa-plus"></i> Categoria</button>
                            <button class="btn btn-primary btn-sm" onclick="openModal('modalBudget')"><i class="fas fa-file-invoice-dollar"></i> Novo Lançamento</button>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- ZBB Dashboard Snapshot -->
                <div class="grid-stats" style="grid-template-columns: repeat(3, 1fr); margin-bottom:30px;">
                    <div class="stat-card">
                        <div class="label">Orçado Total (Mês Atual)</div>
                        <div class="value">R$ 0,00</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Realizado Total</div>
                        <div class="value">R$ 0,00</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Variação</div>
                        <div class="value" style="color:#10b981;">0%</div>
                    </div>
                </div>

                <div style="margin-top:20px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Mês/Ano</th>
                                <th>Centro de Custo</th>
                                <th>Categoria</th>
                                <th>Previsto</th>
                                <th>Realizado</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $zbb_budgets = $wpdb->get_results($wpdb->prepare(
                                "SELECT b.*, c.name as cc_name, cat.name as cat_name 
                                 FROM {$wpdb->prefix}thriveo_zbb_budgets b
                                 LEFT JOIN {$wpdb->prefix}thriveo_zbb_cost_centers c ON b.cost_center_id = c.id
                                 LEFT JOIN {$wpdb->prefix}thriveo_zbb_categories cat ON b.category_id = cat.id
                                 WHERE b.empresa_id = %d ORDER BY b.year DESC, b.month DESC",
                                $empresa_id
                            ));
                            if ($zbb_budgets): foreach($zbb_budgets as $b): ?>
                            <tr>
                                <td><?php printf('%02d/%d', $b->month, $b->year); ?></td>
                                <td><?php echo esc_html($b->cc_name); ?></td>
                                <td><?php echo esc_html($b->cat_name); ?></td>
                                <td>R$ <?php echo number_format($b->planned_value, 2, ',', '.'); ?></td>
                                <td>R$ <?php echo number_format($b->actual_value, 2, ',', '.'); ?></td>
                                <td><span class="badge"><?php echo $b->status; ?></span></td>
                                <td><button class="btn btn-sm btn-outline"><i class="fas fa-edit"></i></button></td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="7" style="text-align:center; padding:40px;">Nenhum lançamento encontrado para o período.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php elseif ($active_tab == 'pdi'): ?>
            <div class="table-area">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2>PDI & Performance</h2>
                    <?php if ($role == 'empresa' || $role == 'super_admin'): ?>
                        <button class="btn btn-primary btn-sm" onclick="openModal('modalPDI')"><i class="fas fa-plus"></i> Novo Plano (PDI)</button>
                    <?php endif; ?>
                </div>

                <div class="grid-stats" style="grid-template-columns: repeat(4, 1fr); margin-bottom:30px;">
                    <div class="stat-card">
                        <div class="label">Total Planos</div>
                        <div class="value">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Em Andamento</div>
                        <div class="value" style="color:#f59e0b;">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Concluídos</div>
                        <div class="value" style="color:#10b981;">0</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Atrasados</div>
                        <div class="value" style="color:#ef4444;">0</div>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Colaborador</th>
                            <th>Competência</th>
                            <th>Prazo</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $pdi_plans = $wpdb->get_results($wpdb->prepare(
                            "SELECT p.*, u.display_name as user_name 
                             FROM {$wpdb->prefix}thriveo_pdi p
                             JOIN {$wpdb->users} u ON p.user_id = u.ID
                             WHERE p.empresa_id = %d ORDER BY p.created_at DESC",
                            $empresa_id
                        ));
                        if ($pdi_plans): foreach($pdi_plans as $p): ?>
                        <tr>
                            <td><strong><?php echo esc_html($p->user_name); ?></strong></td>
                            <td><?php echo esc_html($p->competency); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($p->deadline)); ?></td>
                            <td><span class="badge"><?php echo $p->status; ?></span></td>
                            <td><button class="btn btn-sm btn-outline"><i class="fas fa-eye"></i></button></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:40px;">Nenhum PDI cadastrado.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </main>

    <!-- Modal Nova Empresa -->
    <div id="modalNewCompany" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:500px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);">
            <h2 style="margin-bottom:20px;">Cadastrar Nova Empresa</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('new_company_admin'); ?>
                <input type="hidden" name="thriveo_action" value="create_company">
                
                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Nome da Empresa *</label>
                    <input type="text" name="company_name" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                
                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Email do Administrador *</label>
                    <input type="email" name="admin_email" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;" placeholder="Este usuário será o dono da empresa">
                </div>

                <div style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Plano Inicial</label>
                    <select name="is_paying" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <option value="0">Grátis (1 vaga)</option>
                        <option value="1">Premium (Liberar cota)</option>
                    </select>
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px;">
                    <button type="button" class="btn" onclick="closeNewCompanyModal()" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar Empresa</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar Empresa -->
    <div id="modalEditCompany" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:500px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1);">
            <h2 style="margin-bottom:20px;">Editar Empresa</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('edit_company_admin'); ?>
                <input type="hidden" name="thriveo_action" value="update_company">
                <input type="hidden" name="company_id" id="edit_company_id">
                
                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Nome Fantasia *</label>
                    <input type="text" name="company_name" id="edit_company_name" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>

                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Razão Social</label>
                    <input type="text" name="razao_social" id="edit_razao_social" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                
                <div style="margin-bottom:15px; display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:600;">CNPJ / CPF</label>
                        <input type="text" name="cnpj" id="edit_cnpj" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:600;">CEP</label>
                        <input type="text" name="cep" id="edit_cep" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                </div>

                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Logradouro (Rua, Número...)</label>
                    <input type="text" name="endereco" id="edit_endereco" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>

                <div style="margin-bottom:15px; display:grid; grid-template-columns: 1fr 1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:600;">Bairro</label>
                        <input type="text" name="bairro" id="edit_bairro" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:600;">Cidade</label>
                        <input type="text" name="cidade" id="edit_cidade" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:600;">UF</label>
                        <input type="text" name="estado" id="edit_estado" maxlength="2" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                </div>

                <div style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Status do Plano</label>
                    <select name="is_paying" id="edit_is_paying" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <option value="0">Grátis</option>
                        <option value="1">Premium</option>
                    </select>
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px;">
                    <button type="button" class="btn" onclick="closeEditCompanyModal()" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Atualizar Dados</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modais ZBB e PDI -->
    <div id="modalCC" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1001; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:400px;">
            <h2>Novo Centro de Custo</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('zbb_cc_action'); ?>
                <input type="hidden" name="thriveo_action" value="create_zbb_cc">
                <div style="margin-bottom:15px;">
                    <label>Nome *</label>
                    <input type="text" name="cc_name" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                <div class="flex gap-sm" style="justify-content:flex-end;">
                    <button type="button" class="btn" onclick="closeModal('modalCC')" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <div id="modalPDI" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1002; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:500px;">
            <h2>Novo PDI</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('pdi_action'); ?>
                <input type="hidden" name="thriveo_action" value="create_pdi">
                <div style="margin-bottom:15px;">
                    <label>Competência *</label>
                    <input type="text" name="pdi_competency" placeholder="Ex: Liderança, Python" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                <div style="margin-bottom:15px;">
                    <label>Prazo *</label>
                    <input type="date" name="pdi_deadline" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                <div class="flex gap-sm" style="justify-content:flex-end;">
                    <button type="button" class="btn" onclick="closeModal('modalPDI')" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Criar Plano</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Modal ZBB Categoria -->
    <div id="modalCat" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1003; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:400px;">
            <h2>Nova Categoria</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('zbb_cat_action'); ?>
                <input type="hidden" name="thriveo_action" value="create_zbb_cat">
                <div style="margin-bottom:15px;">
                    <label>Nome *</label>
                    <input type="text" name="cat_name" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>
                <div style="margin-bottom:15px;">
                    <label>Tipo</label>
                    <select name="cat_type" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <option value="fixa">Fixa</option>
                        <option value="variavel">Variável</option>
                    </select>
                </div>
                <div class="flex gap-sm" style="justify-content:flex-end;">
                    <button type="button" class="btn" onclick="closeModal('modalCat')" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal ZBB Lançamento -->
    <div id="modalBudget" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:1004; align-items:center; justify-content:center; padding:20px;">
        <div style="background:white; border-radius:16px; padding:30px; width:100%; max-width:500px;">
            <h2>Novo Lançamento Orçamentário</h2>
            <form action="" method="POST">
                <?php wp_nonce_field('zbb_budget_action'); ?>
                <input type="hidden" name="thriveo_action" value="create_zbb_budget">
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div>
                        <label>Mês</label>
                        <select name="b_month" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                            <?php for($m=1;$m<=12;$m++) echo "<option value='$m'>$m</option>"; ?>
                        </select>
                    </div>
                    <div>
                        <label>Ano</label>
                        <input type="number" name="b_year" value="<?php echo date('Y'); ?>" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                </div>
                <div style="margin-bottom:15px;">
                    <label>Centro de Custo</label>
                    <select name="b_cc" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <?php 
                        $ccs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_zbb_cost_centers WHERE empresa_id = %d", $empresa_id));
                        foreach($ccs as $cc) echo "<option value='{$cc->id}'>{$cc->name}</option>";
                        ?>
                    </select>
                </div>
                <div style="margin-bottom:15px;">
                    <label>Categoria</label>
                    <select name="b_cat" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <?php 
                        $cats = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_zbb_categories WHERE empresa_id = %d", $empresa_id));
                        foreach($cats as $cat) echo "<option value='{$cat->id}'>{$cat->name}</option>";
                        ?>
                    </select>
                </div>
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div>
                        <label>Valor Planejado</label>
                        <input type="number" step="0.01" name="b_planned" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                    <div>
                        <label>Valor Realizado</label>
                        <input type="number" step="0.01" name="b_actual" value="0" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px;">
                    </div>
                </div>
                <div class="flex gap-sm" style="justify-content:flex-end;">
                    <button type="button" class="btn" onclick="closeModal('modalBudget')" style="background:#eee;">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Lançar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        
        function openEditCompanyModal(emp) {
            document.getElementById('edit_company_id').value = emp.id;
            document.getElementById('edit_company_name').value = emp.company_name;
            document.getElementById('edit_is_paying').value = emp.is_paying;
            document.getElementById('modalEditCompany').style.display = 'flex';
        }
        function closeEditCompanyModal() { document.getElementById('modalEditCompany').style.display = 'none'; }
        function openNewCompanyModal() { document.getElementById('modalNewCompany').style.display = 'flex'; }
        function closeNewCompanyModal() { document.getElementById('modalNewCompany').style.display = 'none'; }
    </script>
</body>
</html>

<?php 
// Logic for handling forms
if (isset($_POST['thriveo_action'])) {
    
    // Create
    if ($_POST['thriveo_action'] === 'create_company' && wp_verify_nonce($_POST['_wpnonce'], 'new_company_admin')) {
        $email = sanitize_email($_POST['admin_email']);
        $name = sanitize_text_field($_POST['company_name']);
        $is_paying = intval($_POST['is_paying']);
        $password = 'Kyew@1802'; // Default password as per user requirements

        $user = get_user_by('email', $email);
        if (!$user) {
            $username = explode('@', $email)[0] . '_' . time();
            $user_id = wp_create_user($username, $password, $email);
        } else {
            $user_id = $user->ID;
            wp_set_password($password, $user_id);
        }

        if (!is_wp_error($user_id)) {
            // Set trial date (30 days from now)
            $trial_end = date('Y-m-d H:i:s', strtotime('+30 days'));

            // 1. Insert into unified companies table
            $wpdb->insert($wpdb->prefix . 'thriveo_empresas', [
                'nome_fantasia' => $name,
                'status'        => 'ativo',
                'trial_ends_at' => ($is_paying ? null : $trial_end),
                'max_users'     => ($is_paying ? 200 : 5)
            ]);
            $new_emp_id = $wpdb->insert_id;

            // 2. Insert into platform users (role link)
            $wpdb->insert($wpdb->prefix . 'thriveo_plataforma_usuarios', [
                'wp_user_id' => $user_id,
                'empresa_id' => $new_emp_id,
                'role'       => 'empresa'
            ]);

            echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=empresas&success=1';</script>";
            exit;
        }
    }

    // Update
    if ($_POST['thriveo_action'] === 'update_company' && wp_verify_nonce($_POST['_wpnonce'], 'edit_company_admin')) {
        $wpdb->update($wpdb->prefix . 'thriveo_empresas', [
            'nome_fantasia' => sanitize_text_field($_POST['company_name']),
            'razao_social' => sanitize_text_field($_POST['razao_social']),
            'cnpj'         => sanitize_text_field($_POST['cnpj']),
            'logo_url'     => '', 
            'status'       => 'ativo'
        ], ['id' => intval($_POST['company_id'])]);
        echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=empresas&updated=1';</script>";
        exit;
    }
    
    // Update Address (Specific logic if needed)
    if ($_POST['thriveo_action'] === 'update_address' && wp_verify_nonce($_POST['_wpnonce'], 'edit_company_admin')) {
         // Add detailed update logic for address fields if they are in separate table or columns
    }

    // Delete
    if ($_POST['thriveo_action'] === 'delete_company' && wp_verify_nonce($_POST['_wpnonce'], 'delete_company_admin')) {
        $id = intval($_POST['company_id']);
        $wpdb->delete($wpdb->prefix . 'thriveo_vagas', ['empresa_id' => $id]);
        $wpdb->delete($wpdb->prefix . 'thriveo_empresas', ['id' => $id]);
        $wpdb->delete($wpdb->prefix . 'thriveo_plataforma_usuarios', ['empresa_id' => $id]);
        echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=empresas&deleted=1';</script>";
        exit;
    }

    // Atualizar NF
    if ($_POST['thriveo_action'] === 'update_nf' && wp_verify_nonce($_POST['_wpnonce'], 'update_nf_admin')) {
        $wpdb->update($wpdb->prefix . 'thriveo_pagbank_assinaturas', [
            'nf_numero' => sanitize_text_field($_POST['nf_numero']),
            'nf_status' => sanitize_text_field($_POST['nf_status'])
        ], ['id' => intval($_POST['assinatura_id'])]);
        echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=pagamentos&nf_updated=1';</script>";
        exit;
    }
    // Create ZBB CC
    if ($_POST['thriveo_action'] === 'create_zbb_cc' && wp_verify_nonce($_POST['_wpnonce'], 'zbb_cc_action')) {
        $wpdb->insert($wpdb->prefix . 'thriveo_zbb_cost_centers', [
            'empresa_id' => $empresa_id,
            'name' => sanitize_text_field($_POST['cc_name'])
        ]);
        echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=zbb&success=1';</script>";
        exit;
    }

    // Create PDI
    if ($_POST['thriveo_action'] === 'create_pdi' && wp_verify_nonce($_POST['_wpnonce'], 'pdi_action')) {
        $wpdb->insert($wpdb->prefix . 'thriveo_pdi', [
            'empresa_id' => $empresa_id,
            'user_id' => intval($_POST['pdi_user_id']),
            'competency' => sanitize_text_field($_POST['pdi_competency']),
            'deadline' => sanitize_text_field($_POST['pdi_deadline']),
            'status' => 'em_andamento'
        ]);
        echo "<script>window.location.href = window.location.href.split('&')[0] + '&tab=pdi&success=1';</script>";
        exit;
    }
}
?>
```
