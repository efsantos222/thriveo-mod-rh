<?php
/**
 * Template for a single learning path (AI Lesson Module)
 */

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$trilha_id = isset($_GET['trilha_id']) ? intval($_GET['trilha_id']) : 0;
$trilha = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_trilhas WHERE id = %d", $trilha_id));

if (!$trilha) {
    echo "Trilha não encontrada.";
    return;
}
?>

<style>
    :root {
        --trail-blue: #003399;
        --trail-dark: #0a0a0a;
        --trail-gray: #f8fafc;
    }

    .lesson-header {
        background: linear-gradient(135deg, var(--trail-blue), #001a4d);
        color: white;
        padding: 60px 20px;
        text-align: center;
        border-radius: 0 0 30px 30px;
        margin-bottom: 40px;
    }

    .lesson-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 0 20px 60px;
    }

    .back-link {
        color: white;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 20px;
        font-size: 0.9rem;
        opacity: 0.8;
        transition: 0.3s;
    }

    .back-link:hover { opacity: 1; }

    .lesson-card {
        background: white;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        line-height: 1.8;
        font-size: 1.1rem;
        color: #334155;
    }

    .lesson-card h2, .lesson-card h3 {
        color: var(--trail-blue);
        margin-top: 30px;
    }

    .lesson-image {
        width: 100%;
        max-height: 400px;
        object-fit: cover;
        border-radius: 15px;
        margin-bottom: 30px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    .btn-finish {
        display: block;
        width: 100%;
        max-width: 300px;
        margin: 40px auto 0;
        padding: 15px 30px;
        background: var(--trail-blue);
        color: white;
        text-align: center;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 600;
        transition: 0.3s;
    }

    .btn-finish:hover {
        background: #002673;
        transform: translateY(-2px);
    }
</style>

<div class="lesson-header">
    <div class="lesson-container">
        <a href="?thriveo_trilhas=1" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Voltar para Trilhas
        </a>
        <h1><?php echo esc_html($trilha->titulo); ?></h1>
        <p>Módulo de Estudo Guiado por Inteligência Artificial</p>
    </div>
</div>

<div class="lesson-container">
    <div class="lesson-card">
        <?php if ($trilha->image_url): ?>
            <img src="<?php echo esc_url($trilha->image_url); ?>" class="lesson-image" alt="<?php echo esc_attr($trilha->titulo); ?>">
        <?php endif; ?>

        <div class="lesson-content">
            <?php echo nl2br($trilha->conteudo); ?>
        </div>

        <a href="?thriveo_trilhas=1" class="btn-finish">Concluir Módulo</a>
    </div>
</div>
