<?php
/**
 * Public Job Board Template
 */
if (!defined('ABSPATH'))
    exit;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vagas de IA e Tech - Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
    <style>
        :root {
            --primary: #0052cc;
            --accent: #00c896;
            --bg: #f8fafc;
            --white: #ffffff;
            --text: #1e293b;
            --text-light: #64748b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .hero {
            background: var(--primary);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            border-radius: 16px;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
            pointer-events: none;
        }

        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            font-weight: 800;
        }

        .hero p {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.85);
            max-width: 650px;
            margin: 0 auto;
        }

        /* Search & Filters */
        .search-box {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
            display: grid;
            grid-template-columns: 1fr 1fr 1fr auto;
            gap: 15px;
            margin-bottom: 2rem;
        }

        .search-box select,
        .search-box input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            outline: none;
            background: var(--bg);
            color: var(--text);
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        
        .search-box select:focus,
        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(0, 82, 204, 0.1);
        }

        .btn-search {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.2s;
        }
        
        .btn-search:hover {
            background: #003d99;
        }

        /* Job Cards */
        .job-grid {
            display: grid;
            gap: 1.5rem;
        }

        .job-card {
            background: var(--white);
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid #e2e8f0;
            transition: 0.3s;
            display: grid;
            grid-template-columns: 70px 1fr auto;
            gap: 20px;
            align-items: center;
        }

        .job-card:hover {
            border-color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }

        .job-card.featured {
            border-left: 4px solid var(--primary);
            background: #f8fbff;
        }

        .company-logo {
            width: 70px;
            height: 70px;
            border-radius: 10px;
            object-fit: cover;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
        }

        .job-info h2 {
            font-size: 1.2rem;
            margin-bottom: 5px;
            color: var(--text);
            font-weight: 700;
        }

        .job-info .company-name {
            font-weight: 600;
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .job-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .tag {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 20px;
            background: #e2e8f0;
            font-weight: 600;
            color: var(--text-light);
        }

        .job-meta {
            text-align: right;
        }

        .salary {
            font-weight: 700;
            color: var(--primary);
            font-size: 1.1rem;
            display: block;
            margin-bottom: 15px;
        }

        .btn-apply {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            transition: 0.2s;
        }

        .btn-apply:hover {
            background: #003d99;
        }

        .featured-badge {
            font-size: 0.65rem;
            background: var(--primary);
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            vertical-align: middle;
            margin-left: 10px;
        }
    </style>
</head>

<body>

    <div id="loading-overlay" style="display:none; position:fixed; inset:0; background:rgba(255,255,255,0.7); z-index:2000; align-items:center; justify-content:center;">
        <div class="spinner" style="width:40px; height:40px; border:4px solid #eee; border-top-color:var(--primary); border-radius:50%; animation:spin 1s linear infinite;"></div>
    </div>

    <div class="app-container">
        <aside class="app-sidebar">
            <div class="app-logo">
                <a href="<?php echo home_url(); ?>">
                    <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="?thriveo_dashboard=1" class=""><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="?thriveo_certificacoes=1" class=""><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
                <li><a href="?thriveo_vagas=1" class="active"><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
                <li><a href="?thriveo_talentos=1" class=""><i class="fas fa-users"></i> Banco de Talentos</a></li>
                <li><a href="?thriveo_empresa_vagas=1" class=""><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
                <li><a href="?thriveo_matching=1" class=""><i class="fas fa-bolt"></i> Matching IA</a></li>
                <li><a href="?thriveo_entrevista=1" class=""><i class="fas fa-comments"></i> Entrevista IA</a></li>
                <li><a href="?thriveo_faq=1" class=""><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
                <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
                <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
            </ul>
        </aside>

        <main class="app-main">
            <div class="hero">
                <h1>Sua Carreira em IA Começa Aqui</h1>
                <p>Explore as oportunidades mais disruptivas do mercado. Nossa plataforma conecta especialistas como você com
                    empresas que estão liderando a revolução tecnológica no Brasil.</p>
            </div>

    <div class="container">
        <div class="search-box">
            <input type="text" placeholder="Cargo ou palavra-chave..."
                title="Busque por termos como 'Machine Learning', 'LLM', 'Engenheiro', etc.">
            <select title="Selecione a área técnica de seu interesse.">
                <option value="">Todas as Áreas</option>
                <option value="Data/IA">Data / IA</option>
                <option value="Engineering">Engineering</option>
            </select>
            <select title="Escolha a localização desejada ou 'Remoto' para flexibilidade total.">
                <option value="">Todas as Cidades</option>
                <option value="SP">São Paulo</option>
                <option value="Remoto">Remoto</option>
            </select>
            <button class="btn-search" title="Clique para atualizar a lista com os filtros aplicados.">Buscar
                Vagas</button>
        </div>

        <div id="vagas-public-list" class="job-grid">
            <!-- Cards loaded via JS -->
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            loadPublicVagas();
        });

        async function loadPublicVagas() {
            document.getElementById('loading-overlay').style.display = 'flex';
            try {
                const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=thriveo_get_vagas_list');
                const data = await response.json();

                if (data.success) {
                    renderVagas(data.data.vagas);
                }
            } catch (err) {
                console.error(err);
            } finally {
                document.getElementById('loading-overlay').style.display = 'none';
            }
        }

        function renderVagas(vagas) {
            const list = document.getElementById('vagas-public-list');
            if (vagas.length === 0) {
                list.innerHTML = '<div style="text-align:center; padding: 3rem;">Nenhuma vaga aberta no momento. Volte em breve!</div>';
                return;
            }

            list.innerHTML = vagas.map(v => {
                const featured = v.tipo_publicacao === 'paga';
                const salario = v.salario_a_combinar == '1' ? 'A combinar' : `R$ ${v.salario_min} - R$ ${v.salario_max}`;
                const companyInitial = v.company_name ? v.company_name.charAt(0).toUpperCase() : '?';
                const placeholderUrl = `https://placehold.co/80x80/0052cc/ffffff?text=${companyInitial}`;

                return `
                <div class="job-card ${featured ? 'featured' : ''}">
                    <img src="${v.logo_url || placeholderUrl}" 
                         class="company-logo" 
                         onerror="this.onerror=null; this.src='${placeholderUrl}';">
                    <div class="job-info">
                        <h2>${v.titulo} ${featured ? '<span class="featured-badge">PATROCINADA</span>' : ''}</h2>
                        <p class="company-name">${v.company_name} • ${v.cidade || 'Remoto'} / ${v.estado || ''}</p>
                        <div class="job-tags">
                            <span class="tag">${v.modalidade}</span>
                            <span class="tag">${v.regime}</span>
                            <span class="tag">${v.nivel}</span>
                        </div>
                    </div>
                    <div class="job-meta">
                        <span class="salary">${salario}</span>
                        <a href="?thriveo_dashboard=1" class="btn-apply">Candidatar-se</a>
                    </div>
                </div>
            `;
            }).join('');
        }

        loadPublicVagas();

        // Logout logic for public page (simple version as hero.js might not load here)
        document.getElementById('th-btnLogout-public').addEventListener('click', function () {
            localStorage.removeItem('thriveo_token');
            localStorage.removeItem('thriveo_provider');
            window.location.href = '<?php echo home_url(); ?>';
        });

        // Show logout button if token exists
        if (localStorage.getItem('thriveo_token')) {
            document.getElementById('th-btnLogout-public').style.display = 'block';
        }
    </script>
        </main>
    </div>

</body>

</html>