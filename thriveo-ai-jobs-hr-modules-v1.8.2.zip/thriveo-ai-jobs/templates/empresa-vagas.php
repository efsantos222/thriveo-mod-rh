<?php
/**
 * Company Jobs Management Template
 */
if (!defined('ABSPATH'))
    exit;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Vagas - Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0052cc;
            --secondary: #003d99;
            --accent: #00c896; /* Ajustado para o verde de sucesso da marca */
            --navy: #0f172a;
            --white: #ffffff;
            --bg: #f8fafc;
            --text-main: #0f172a;
            --text-light: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
            --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text-main);
        }

        /* Quota Section */
        .quota-card {
            background: var(--white);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            margin-bottom: 3rem;
            border: 1px solid var(--border);
        }

        .quota-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .quota-header h2 {
            font-size: 1.2rem;
            color: var(--navy);
            font-weight: 700;
        }

        .quota-progress {
            background: #edf2f7;
            height: 12px;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }

        .quota-fill {
            background: var(--accent);
            height: 100%;
            border-radius: 10px;
            transition: 1s ease-in-out;
            box-shadow: 0 0 10px rgba(0, 200, 150, 0.3);
        }

        .quota-text {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 0.85rem;
            color: var(--text-light);
            font-weight: 500;
        }

        /* Actions Header */
        .actions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .actions-header h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--navy);
            letter-spacing: -0.02em;
        }

        .btn-new {
            background: var(--accent);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
            box-shadow: 0 4px 6px rgba(0, 200, 150, 0.2);
        }

        .btn-new:hover {
            background: #00b386;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 200, 150, 0.3);
        }

        /* Jobs Table */
        .table-container {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            border: 1px solid var(--border);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background: #f8fafc;
            padding: 1.2rem;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-light);
            border-bottom: 1px solid var(--border);
            font-weight: 700;
        }

        td {
            padding: 1.2rem;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
            color: var(--text-main);
            font-size: 0.95rem;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }

        .badge-green { background: #dcfce7; color: #15803d; }
        .badge-yellow { background: #ffedd5; color: #9a3412; }
        .badge-gray { background: #f1f5f9; color: #475569; }
        .badge-blue { background: #e0f2fe; color: #0369a1; }

        .btn-icon {
            background: #f1f5f9;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            font-size: 1rem;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            margin-left: 5px;
        }

        .btn-icon:hover {
            background: var(--blue-light);
            color: var(--primary);
            transform: scale(1.05);
        }

        .btn-delete:hover {
            background: #fee2e2;
            color: var(--danger);
        }

        /* Modal / Form */
        #vaga-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.7);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(8px);
            padding: 20px;
        }

        .modal-body {
            background: var(--white);
            width: 100%;
            max-width: 900px;
            max-height: 90vh;
            border-radius: 24px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            animation: modalFadeIn 0.3s ease-out;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            padding: 1.5rem 2.5rem;
            background: var(--navy);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            color: white;
            font-size: 1.4rem;
            font-weight: 700;
        }

        .modal-header .btn-icon {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .modal-form {
            flex-grow: 1;
            overflow-y: auto;
            padding: 2.5rem;
            background: #fdfdfd;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        .form-group {
            margin-bottom: 0.5rem;
        }

        .form-group.full {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--navy);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 2px solid #eef2f6;
            background: #f8fafc;
            outline: none;
            font-size: 0.95rem;
            transition: all 0.2s;
            color: var(--text-main);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary);
            background: white;
            box-shadow: 0 0 0 4px rgba(0, 82, 204, 0.1);
        }

        .form-group textarea {
            resize: vertical;
        }

        .form-footer {
            padding: 1.5rem 2.5rem;
            background: #f8fafc;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }

        .btn-ghost {
            background: white;
            border: 2px solid #eef2f6;
            padding: 12px 24px;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            color: var(--text-light);
            transition: all 0.2s;
        }

        .btn-ghost:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--text-main);
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            .modal-body {
                height: 100vh;
                max-height: 100vh;
                border-radius: 0;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
</head>

<body>

    <div class="app-container">
<aside class="app-sidebar">
    <div class="app-logo">
        <a href="<?php echo home_url(); ?>">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
        </a>
    </div>
    <ul class="nav-menu">
        <li><a href="?thriveo_dashboard=1" class=""><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
        <li><a href="?thriveo_certificacoes=1" class=""><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
        <li><a href="?thriveo_vagas=1" class=""><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
        <li><a href="?thriveo_talentos=1" class=""><i class="fas fa-users"></i> Banco de Talentos</a></li>
        <li><a href="?thriveo_empresa_vagas=1" class="active"><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
        <li><a href="?thriveo_matching=1" class=""><i class="fas fa-bolt"></i> Matching IA</a></li>
        <li><a href="?thriveo_entrevista=1" class=""><i class="fas fa-comments"></i> Entrevista IA</a></li>
        <li><a href="?thriveo_faq=1" class=""><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
        <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
        <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
    </ul>
    <div class="sidebar-user-info">
        <div class="sidebar-user-name">Usuário Ativo</div>
        <div class="sidebar-user-status">Sessão Segura</div>
    </div>
</aside>

        <main class="app-main">
            <div class="page-intro"
                style="margin-bottom: 2.5rem; background: var(--white); padding: 2rem; border-radius: 20px; border-left: 5px solid var(--accent); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <h1 style="font-size: 1.8rem; color: var(--navy); margin-bottom: 0.5rem;">Gestão Estratégica de Oportunidades</h1>
                <p style="color: var(--text-light); font-size: 1.05rem; max-width: 800px;">Publique e gerencie suas vagas de forma simplificada.</p>
            </div>

            <div class="quota-card"
                title="Seu limite mensal de publicações gratuitas. Após o uso da cota, cada nova vaga custará R$ 99,00.">
                <div class="quota-header">
                    <h2>Cota Mensal Freemium</h2>
                    <span id="quota-badge" class="badge badge-blue">Plano Gratuito</span>
                </div>
                <div class="quota-progress">
                    <div id="quota-fill" class="quota-fill" style="width: 0%"></div>
                </div>
                <div class="quota-text">
                    <span id="quota-usage">Você usou 0 de 1 vaga gratuita este mês</span>
                    <span>Vagas adicionais: a partir de R$ 99,00</span>
                </div>
                <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
                    <button class="btn-new" onclick="document.getElementById('modal-pagamento').style.display='flex'" style="background:var(--navy);"><i class="fas fa-rocket"></i> Fazer Upgrade (Múltiplas Vagas)</button>
                </div>
            </div>

            <div class="actions-header">
                <h1>Minhas Vagas</h1>
                <button class="btn-new" onclick="openVagaModal()"
                    title="Crie uma nova publicação para atrair talentos. A primeira do mês é gratuita!"><i
                        class="fas fa-plus"></i> Publicar Nova Vaga</button>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Vaga</th>
                            <th>Status</th>
                            <th>Candidaturas</th>
                            <th>Tipo</th>
                            <th>Expira em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="vagas-list">
                        <!-- Loaded via JS -->
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- Modal Formulário de Vaga -->
    <div id="vaga-modal">
        <div class="modal-body">
            <div class="modal-header">
                <h2 id="modal-title">Nova Vaga</h2>
                <button onclick="closeVagaModal()" class="btn-icon"><i class="fas fa-times"></i></button>
            </div>
            <form id="vaga-form" class="modal-form">
                <input type="hidden" name="id" id="vaga-id">

                <div class="form-grid">
                    <div class="form-group full">
                        <label>Título da Vaga *</label>
                        <input type="text" name="titulo" required placeholder="Ex: AI Engineer Senior">
                    </div>
                    <div class="form-group">
                        <label>Área de Atuação *</label>
                        <select name="area_atuacao" required>
                            <option value="Backend">Backend</option>
                            <option value="Frontend">Frontend</option>
                            <option value="Full-Stack">Full-Stack</option>
                            <option value="Data/IA">Data/IA</option>
                            <option value="Mobile">Mobile</option>
                            <option value="DevOps">DevOps</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nível *</label>
                        <select name="nivel" required>
                            <option value="Júnior">Júnior</option>
                            <option value="Pleno">Pleno</option>
                            <option value="Sênior">Sênior</option>
                            <option value="Especialista">Especialista</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Regime *</label>
                        <select name="regime" required>
                            <option value="CLT">CLT</option>
                            <option value="PJ">PJ</option>
                            <option value="Freelancer">Freelancer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Modalidade *</label>
                        <select name="modalidade" required>
                            <option value="Remoto">Remoto</option>
                            <option value="Híbrido">Híbrido</option>
                            <option value="Presencial">Presencial</option>
                        </select>
                    </div>
                    <div class="form-group full">
                        <label>Descrição *</label>
                        <textarea name="descricao" rows="5" required></textarea>
                    </div>
                    <div class="form-group full">
                        <label>Requisitos Obrigatórios *</label>
                        <textarea name="requisitos_obrigatorios" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Salário Mínimo (R$)</label>
                        <input type="number" name="salario_min">
                    </div>
                    <div class="form-group">
                        <label>Salário Máximo (R$)</label>
                        <input type="number" name="salario_max">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="ativa">Ativa (Publicar)</option>
                            <option value="rascunho">Rascunho</option>
                            <option value="pausada">Pausada</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Prazo Candidatura</label>
                        <input type="date" name="prazo_candidatura">
                    </div>
                </div>

                <div id="payment-warning"
                    style="display:none; background: #fffbeb; padding: 20px; border-radius: 12px; border: 1px solid #fef3c7; color: #92400e; margin-top: 20px;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Atenção:</strong> Você já atingiu sua cota de 1 vaga gratuita este mês. Para publicar esta
                    vaga como <strong>Ativa</strong>, será gerada uma cobrança de <strong>R$ 99,00</strong>.
                </div>
            </form>
            <div class="form-footer">
                <button class="btn-ghost" onclick="closeVagaModal()">Cancelar</button>
                <button class="btn-new" id="btn-save-vaga" onclick="saveVaga()">Salvar Vaga</button>
            </div>
        </div>
    </div>

    <script>
        // Utiliza a origem crua gerada pelo WP, forçando o envio de cookies de terceiros se necessário
        const rawAjaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';

        async function loadVagas() {
            const response = await fetch(rawAjaxUrl + '?action=thriveo_get_vagas_empresa', {
                credentials: 'include'
            });
            const data = await response.json();

            if (data.success) {
                renderVagas(data.data.vagas);
                renderQuota(data.data.quota);
            }
        }

        function renderVagas(vagas) {
            const list = document.getElementById('vagas-list');
            if (vagas.length === 0) {
                list.innerHTML = '<tr><td colspan="6" style="text-align:center">Nenhuma vaga cadastrada.</td></tr>';
                return;
            }

            list.innerHTML = vagas.map(v => {
                const statusClass = v.status === 'ativa' ? 'badge-green' : (v.status === 'rascunho' ? 'badge-blue' : 'badge-yellow');
                const dataExp = v.expira_em ? new Date(v.expira_em).toLocaleDateString() : 'Sem prazo';

                return `
                <tr>
                    <td>
                        <strong>${v.titulo}</strong><br>
                        <small style="color:var(--text-light)">${v.area_atuacao} • ${v.nivel}</small>
                    </td>
                    <td><span class="badge ${statusClass}">${v.status.toUpperCase()}</span></td>
                    <td><a href="#" onclick="viewApplications(${v.id})" style="color:var(--accent); font-weight:600">Ver Candidaturas</a></td>
                    <td>${v.tipo_publicacao === 'paga' ? '💎 Paga' : '🆓 Grátis'}</td>
                    <td>${dataExp}</td>
                    <td>
                        <button class="btn-icon" onclick="editVaga(${JSON.stringify(v).replace(/"/g, '&quot;')})"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon btn-delete" onclick="deleteVaga(${v.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `;
            }).join('');
        }

        function renderQuota(quota) {
            const fill = document.getElementById('quota-fill');
            const text = document.getElementById('quota-usage');
            const badge = document.getElementById('quota-badge');

            const limite = quota.limite || 1;
            const perc = (quota.usadas / limite) * 100;
            fill.style.width = Math.min(perc, 100) + '%';
            
            const tipoVaga = limite > 1 ? 'vagas' : 'vaga gratuita';
            text.innerText = `Você usou ${quota.usadas} de ${limite} ${tipoVaga} este mês`;

            if (!quota.pode_gratis) {
                badge.innerText = "Cota Esgotada";
                badge.className = "badge badge-yellow";
                document.getElementById('payment-warning').style.display = 'block';
            } else if (limite > 1) {
                badge.innerText = "Plano Premium";
                badge.className = "badge badge-green";
                document.getElementById('payment-warning').style.display = 'none';
            } else {
                badge.innerText = "Plano Gratuito";
                badge.className = "badge badge-blue";
                document.getElementById('payment-warning').style.display = 'none';
            }
        }

        function openVagaModal() {
            document.getElementById('vaga-form').reset();
            document.getElementById('vaga-id').value = '';
            document.getElementById('modal-title').innerText = "Nova Vaga";
            document.getElementById('vaga-modal').style.display = 'flex';
        }

        function closeVagaModal() {
            document.getElementById('vaga-modal').style.display = 'none';
        }

        function editVaga(v) {
            openVagaModal();
            document.getElementById('modal-title').innerText = "Editar Vaga";
            document.getElementById('vaga-id').value = v.id;

            const form = document.getElementById('vaga-form');
            form.titulo.value = v.titulo;
            form.area_atuacao.value = v.area_atuacao;
            form.nivel.value = v.nivel;
            form.regime.value = v.regime;
            form.modalidade.value = v.modalidade;
            form.descricao.value = v.descricao;
            form.requisitos_obrigatorios.value = v.requisitos_obrigatorios;
            form.salario_min.value = v.salario_min;
            form.salario_max.value = v.salario_max;
            form.status.value = v.status;
            form.prazo_candidatura.value = v.prazo_candidatura ? v.prazo_candidatura.split(' ')[0] : '';
        }

        async function deleteVaga(id) {
            if (!confirm("Tem certeza que deseja excluir esta vaga? Esta ação é irreversível.")) {
                return;
            }

            const fd = new FormData();
            fd.append('action', 'thriveo_delete_vaga');
            fd.append('id', id);

            try {
                const response = await fetch(rawAjaxUrl, {
                    method: 'POST',
                    credentials: 'include',
                    body: fd
                });
                const data = await response.json();
                if (data.success) {
                    alert(data?.data?.message || "Excluída com sucesso.");
                    loadVagas();
                } else {
                    alert("Erro ao excluir: " + (data?.data?.message || JSON.stringify(data)));
                }
            } catch (e) {
                console.error("Delete exception", e);
                alert("Erro de rede ao tentar excluir.");
            }
        }

        async function saveVaga() {
            const form = document.getElementById('vaga-form');
            const fd = new FormData(form);
            fd.append('action', 'thriveo_save_vaga');

            const btn = document.getElementById('btn-save-vaga');
            btn.disabled = true;
            btn.innerText = "Salvando...";

            try {
                const response = await fetch(rawAjaxUrl, {
                    method: 'POST',
                    credentials: 'include',
                    body: fd
                });
                
                const rawText = await response.text();
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch(err) {
                    console.error("Raw response:", rawText);
                    alert("Erro interno no servidor: " + rawText.substring(0, 150));
                    return;
                }

                if (data.success) {
                    alert(data?.data?.message || "Salvo com sucesso!");
                    closeVagaModal();
                    loadVagas();
                } else if (data?.data?.code === 'quota_exceeded') {
                    // Cota esgotada. Chamar loadVagas para mostrar o rascunho.
                    loadVagas();
                    closeVagaModal();
                    alert(data.data.message);
                    document.getElementById('modal-pagamento').style.display = 'flex';
                } else {
                    const errorMsg = data?.data?.message || data?.message || data?.data || JSON.stringify(data);
                    alert("Erro do Servidor: " + errorMsg);
                }
            } catch (e) {
                console.error("Fetch Exception:", e);
                alert("Erro de Rede ou Catch: " + (e.message || e));
            } finally {
                btn.disabled = false;
                btn.innerText = "Salvar Vaga";
            }
        }

        function viewApplications(vagaId) {
            alert("Carregando candidatos para a vaga #" + vagaId);
            // Aqui abriríamos uma lista de candidatos filtrada por essa vaga
        }

        loadVagas();

        // Verificar parâmetro para abrir modal de nova vaga ou exibir sucesso de pagamento
        window.addEventListener('load', () => {
            const params = new URLSearchParams(window.location.search);
            if (params.get('nova_vaga') === '1') {
                openVagaModal();
            }
            if (params.get('mp_status') === 'success') {
                alert("🎉 Pagamento confirmado com sucesso! Sua vaga foi ativada e sua cota atualizada.");
                // Limpar a URL para não mostrar o alerta novamente
                window.history.replaceState({}, document.title, window.location.pathname + window.location.search.replace(/[&?]mp_status=success(&payment_id=[^&]*)?/, ''));
            }
        });
    </script>
    
    <?php 
    global $wpdb;
    $current_user_id = get_current_user_id();
    $company_billing = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}thriveo_ai_companies WHERE wp_user_id = %d", 
        $current_user_id
    ));
    include THRIVEO_AI_JOBS_DIR . 'templates/modal-pagamento.php'; 
    ?>
</body>

</html>