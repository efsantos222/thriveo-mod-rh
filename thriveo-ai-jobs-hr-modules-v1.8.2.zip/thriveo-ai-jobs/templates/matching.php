<?php
if (!defined('ABSPATH')) exit;

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0,0,0,0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #0052cc; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) { window.location.href = '<?php echo home_url(); ?>'; }
            else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => { if (data.success) window.location.reload(); else window.location.href = '<?php echo home_url(); ?>'; })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
<?php exit; endif; ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Matching Inteligente — Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-modern.css">
    <style>
        body { background: var(--bg); font-family: 'Plus Jakarta Sans', sans-serif; margin: 0; padding: 0; }
        
        .hero-mini { padding: 2rem 2rem 1.5rem; background: var(--white); border-bottom: 1px solid var(--border); border-radius: 16px; margin-bottom: 2rem;}
        .hero-mini h1 { font-size: 2.2rem; font-weight: 800; color: var(--text-main); margin-bottom: 0.5rem; letter-spacing: -0.02em; }
        .hero-mini p { color: var(--text-muted); max-width: 600px; }
        
        .container-matching { max-width: 1000px; margin: 0 auto; }
        
        .match-card { background: var(--white); border: 1px solid var(--border); border-radius: 12px; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 2rem; position: relative; overflow: hidden; }
        .match-card::before { content: ""; position: absolute; top:0; left:0; width: 4px; height: 100%; background: var(--primary); }
        
        .match-header { display: flex; justify-content: space-between; align-items: start; gap: 2rem; margin-bottom: 1.5rem; }
        .match-info h3 { margin: 0; font-size: 1.2rem; font-weight: 700; color: var(--text-main); }
        .match-info .company { font-size: 0.9rem; color: var(--text-muted); margin-top: 0.2rem; font-weight: 500; }
        
        /* Circular Score */
        .score-circle { width: 80px; height: 80px; position: relative; flex-shrink: 0; }
        .score-circle svg { transform: rotate(-90deg); }
        .score-circle .circle-bg { fill: none; stroke: var(--border); stroke-width: 6; }
        .score-circle .circle-progress { fill: none; stroke: var(--accent); stroke-width: 6; stroke-linecap: round; transition: stroke-dashoffset 1s ease; }
        .score-circle .score-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; font-weight: 800; color: var(--text-main); }

        .tags-vaga { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem; }
        .tag-match { background: rgba(0,200,150,0.1); color: var(--accent); padding: 0.3rem 0.8rem; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        
        .match-details { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border); }
        .detail-item { display: flex; flex-direction: column; gap: 0.2rem; }
        .detail-item label { font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600; }
        .detail-item span { font-size: 1rem; font-weight: 700; color: var(--text-main); }

        .pro-badge { position: absolute; top: 1.5rem; right: 1.5rem; background: var(--accent); color: #fff; padding: 0.2rem 0.7rem; border-radius: 50px; font-size: 0.65rem; font-weight: 800; letter-spacing: 0.1em; }
    </style>
</head>
<body>

<div class="app-container">
<aside class="app-sidebar">
    <div class="app-logo">
        <a href="<?php echo home_url(); ?>">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
        </a>
    </div>
    <ul class="nav-menu">
        <li><a href="?thriveo_dashboard=1" class=""><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
        <li><a href="?thriveo_certificacoes=1" class=""><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
        <li><a href="?thriveo_vagas=1" class=""><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
        <li><a href="?thriveo_talentos=1" class=""><i class="fas fa-users"></i> Banco de Talentos</a></li>
        <li><a href="?thriveo_empresa_vagas=1" class=""><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
        <li><a href="?thriveo_matching=1" class="active"><i class="fas fa-bolt"></i> Matching IA</a></li>
        <li><a href="?thriveo_entrevista=1" class=""><i class="fas fa-comments"></i> Entrevista IA</a></li>
        <li><a href="?thriveo_faq=1" class=""><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
        <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
        <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
    </ul>
    <div class="sidebar-user-info">
        <div class="sidebar-user-name">Usuário Ativo</div>
        <div class="sidebar-user-status">Sessão Segura</div>
    </div>
</aside>

<main class="app-main">
    <header class="hero-mini">
        <div class="tag-modern" style="margin-bottom: 1rem; display:inline-block; font-size:0.75rem; font-weight:700; background:rgba(0,82,204,0.1); color:var(--primary); padding:4px 12px; border-radius:20px;">Módulo 03 — Matching Inteligente</div>
        <h1>Sua compatibilidade com o mercado</h1>
        <p>Utilizamos IA para cruzar suas certificações, habilidades e portfólio com as melhores oportunidades em tempo real.</p>
    </header>

    <div class="container-matching">
        <!-- MATCH 1 -->
        <div class="match-card">
            <div class="pro-badge">PRO MATCH</div>
            <div class="match-header">
                <div class="match-info">
                    <h3>Engenheiro de LLMs & Agentes</h3>
                    <div class="company">TechCorp Solutions · Remoto · São Paulo</div>
                    <div class="tags-vaga" style="margin-top: 1rem;">
                        <span class="tag-match">LangChain</span>
                        <span class="tag-match">Python</span>
                        <span class="tag-match">RAG</span>
                        <span class="tag-match">FastAPI</span>
                    </div>
                </div>
                <div class="score-circle">
                    <svg width="80" height="80">
                        <circle class="circle-bg" cx="40" cy="40" r="34" />
                        <circle class="circle-progress" cx="40" cy="40" r="34" style="stroke-dasharray: 213.6; stroke-dashoffset: 21.3;" />
                    </svg>
                    <div class="score-text">90%</div>
                </div>
            </div>
            
            <div class="match-details">
                <div class="detail-item"><label>Salário Estimado</label><span>R$ 15.000 - 22.000</span></div>
                <div class="detail-item"><label>Nível</label><span>Sênior</span></div>
                <div class="detail-item"><label>Pontos Fortes</label><span style="color: var(--accent); font-size: 0.85rem;"><i class="fas fa-check-circle"></i> Certificação GenAI</span></div>
                <div class="detail-item">
                    <button class="btn-modern btn-modern-primary" style="justify-content: center; width:100%; border:none; padding:10px; border-radius:8px; cursor:pointer; font-weight:600; background:var(--navy); color:white;">Aplicar agora</button>
                </div>
            </div>
        </div>

        <!-- MATCH 2 -->
        <div class="match-card" style="opacity: 0.8;">
            <div class="match-header">
                <div class="match-info">
                    <h3>Analista de Dados & Business Intelligence AI</h3>
                    <div class="company">Fintech Alpha · Híbrido · Barueri, SP</div>
                    <div class="tags-vaga" style="margin-top: 1rem;">
                        <span class="tag-match">SQL</span>
                        <span class="tag-match">Pandas</span>
                        <span class="tag-match">AutoML</span>
                        <span class="tag-match">Tableau</span>
                    </div>
                </div>
                <div class="score-circle">
                    <svg width="80" height="80">
                        <circle class="circle-bg" cx="40" cy="40" r="34" />
                        <circle class="circle-progress" cx="40" cy="40" r="34" style="stroke: var(--warning); stroke-dasharray: 213.6; stroke-dashoffset: 64.0;" />
                    </svg>
                    <div class="score-text" style="color: var(--warning);">70%</div>
                </div>
            </div>
            
            <div class="match-details">
                <div class="detail-item"><label>Salário Estimado</label><span>R$ 10.000 - 14.000</span></div>
                <div class="detail-item"><label>Nível</label><span>Pleno</span></div>
                <div class="detail-item"><label>Gap de Skill</label><span style="color: var(--danger); font-size: 0.85rem;"><i class="fas fa-exclamation-triangle"></i> Docker / MLOps</span></div>
                <div class="detail-item">
                    <button class="btn-modern btn-modern-primary" style="justify-content: center; width:100%; border:none; padding:10px; border-radius:8px; cursor:pointer; font-weight:600; background:var(--text-light); color:white;">Ver Trilha p/ Gap</button>
                </div>
            </div>
        </div>
    </div>
</main>
</div>

</body>
</html>
