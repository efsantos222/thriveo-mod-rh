<?php
/**
 * Template Name: DISC Assessment
 */

get_header();

$nonce = wp_create_nonce('thriveo_disc_nonce');
?>

<div class="thriveo-container" style="max-width: 800px; margin: 40px auto; padding: 20px; font-family: 'Inter', sans-serif;">
    <div class="card" style="background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); padding: 30px;">
        <div style="text-align: center; margin-bottom: 30px;">
            <img src="https://thriveo.com.br/wp-content/uploads/2026/01/cropped-logo_thriveo_75.png" alt="Thriveo" style="height: 50px; margin-bottom: 15px;">
            <h1 style="font-size: 1.8rem; color: #1e293b;">Avaliação de Perfil Comportamental (DISC)</h1>
            <p style="color: #64748b;">Descubra suas tendências comportamentais e como elas influenciam seu trabalho.</p>
        </div>

        <form id="discForm" method="POST" action="">
            <div id="step-0">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Seu Nome Completo</label>
                    <input type="text" name="candidate_name" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600;">Seu E-mail</label>
                    <input type="email" name="candidate_email" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                </div>
                <button type="button" onclick="startAssessment()" class="btn btn-primary" style="width: 100%; padding: 12px; font-weight: 600;">Iniciar Avaliação</button>
            </div>

            <div id="assessment-area" style="display: none;">
                <div id="questions-container">
                    <!-- Questions will be loaded here via JS -->
                </div>
                
                <div style="display: flex; justify-content: space-between; margin-top: 30px;">
                    <button type="button" id="prevBtn" onclick="changeStep(-1)" class="btn btn-secondary" style="display: none;">Anterior</button>
                    <button type="button" id="nextBtn" onclick="changeStep(1)" class="btn btn-primary">Próximo</button>
                    <button type="submit" id="submitBtn" class="btn btn-success" style="display: none;">Finalizar e Ver Resultado</button>
                </div>
                
                <div style="margin-top: 20px; background: #f1f5f9; height: 8px; border-radius: 4px; overflow: hidden;">
                    <div id="progressBar" style="background: #0052cc; height: 100%; width: 0%; transition: width 0.3s;"></div>
                </div>
            </div>
        </form>

        <div id="result-area" style="display: none; text-align: center;">
            <h2 style="color: #0052cc; margin-bottom: 20px;">Resultado do seu Perfil</h2>
            <div id="profile-chart" style="margin-bottom: 30px;">
                <!-- Chart placeholder -->
            </div>
            <div id="profile-description" style="text-align: left; background: #f8fafc; padding: 20px; border-radius: 8px;">
                <!-- Description -->
            </div>
            <button onclick="window.print()" class="btn btn-outline" style="margin-top: 20px;">Imprimir Resultado</button>
        </div>
    </div>
</div>

<script>
let currentStep = 0;
const questions = <?php 
    require_once __DIR__ . '/includes/class-disc-handler.php';
    echo json_encode(Thriveo_AI_DISC_Handler::get_questions()); 
?>;
const totalSteps = Object.keys(questions).length;

function startAssessment() {
    const name = document.querySelector('[name="candidate_name"]').value;
    const email = document.querySelector('[name="candidate_email"]').value;
    
    if(!name || !email) {
        alert('Por favor, preencha nome e e-mail.');
        return;
    }
    
    document.getElementById('step-0').style.display = 'none';
    document.getElementById('assessment-area').style.display = 'block';
    renderQuestion(1);
}

function renderQuestion(step) {
    const qData = questions[step];
    let html = `
        <div class="question-step" id="q-step-${step}">
            <h3 style="margin-bottom: 20px; font-size: 1.2rem;">${step}. ${qData.q}</h3>
            <div style="display: flex; flex-direction: column; gap: 10px;">
    `;
    
    for (const [key, val] of Object.entries(qData.options)) {
        html += `
            <label style="display: flex; align-items: center; gap: 10px; padding: 12px; border: 1px solid #ddd; border-radius: 8px; cursor: pointer; transition: all 0.2s;" class="option-label">
                <input type="radio" name="q${step}" value="${key}" required onclick="highlightOption(this)">
                <span>${val}</span>
            </label>
        `;
    }
    
    html += `</div></div>`;
    document.getElementById('questions-container').innerHTML = html;
    updateProgress();
}

function highlightOption(input) {
    document.querySelectorAll('.option-label').forEach(el => el.style.borderColor = '#ddd');
    input.closest('.option-label').style.borderColor = '#0052cc';
    input.closest('.option-label').style.background = '#e8f0fe';
}

function changeStep(dir) {
    const radio = document.querySelector(`input[name="q${currentStep+1}"]:checked`);
    if(dir === 1 && currentStep > 0 && !radio) {
        alert('Por favor, selecione uma opção.');
        return;
    }

    if(currentStep === 0 && dir === 1) currentStep = 1;
    else currentStep += dir;

    if (currentStep > totalSteps) {
        // Handled by submit
        return;
    }

    renderQuestion(currentStep);
    
    document.getElementById('prevBtn').style.display = currentStep > 1 ? 'block' : 'none';
    document.getElementById('nextBtn').style.display = currentStep < totalSteps ? 'block' : 'none';
    document.getElementById('submitBtn').style.display = currentStep === totalSteps ? 'block' : 'none';
}

function updateProgress() {
    const pct = (currentStep / totalSteps) * 100;
    document.getElementById('progressBar').style.width = pct + '%';
}

function submitDisc(e) {
    e.preventDefault();
    // In a real app, this would be an AJAX call
    const formData = new FormData(e.target);
    const answers = [];
    for(let i=1; i<=totalSteps; i++) {
        answers.push(formData.get('q'+i));
    }
    
    // Process results locally for MVP feedback
    // In production, we send to server
    alert('Avaliação enviada com sucesso! Você receberá o resultado em breve.');
}

document.getElementById('discForm').onsubmit = submitDisc;

</script>

<style>
.btn { border: none; border-radius: 6px; cursor: pointer; padding: 10px 20px; font-weight: 500; font-family: inherit; transition: all 0.2s; }
.btn-primary { background: #0052cc; color: white; }
.btn-primary:hover { background: #003d99; }
.btn-secondary { background: #e2e8f0; color: #475569; }
.btn-success { background: #10b981; color: white; }
.btn-outline { background: transparent; border: 1.5px solid #0052cc; color: #0052cc; }
</style>

<?php get_footer(); ?>
