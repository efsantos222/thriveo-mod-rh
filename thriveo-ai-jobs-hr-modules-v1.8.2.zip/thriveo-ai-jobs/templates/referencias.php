<?php
/**
 * D4 Professional References Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">

    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body {
                font-family: sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                background: #f8fafc;
                color: #1e293b;
            }

            .sync-box {
                text-align: center;
            }

            .spinner {
                border: 4px solid rgba(0, 0, 0, 0.1);
                width: 36px;
                height: 36px;
                border-radius: 50%;
                border-left-color: #1a2e4a;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            }

            @keyframes spin {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }
        </style>
    </head>

    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) {
                window.location.href = '<?php echo home_url(); ?>';
            } else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            window.location.reload();
                        } else {
                            window.location.href = '<?php echo home_url(); ?>';
                        }
                    })
                    .catch(() => {
                        window.location.href = '<?php echo home_url(); ?>';
                    });
            }
        </script>
    </body>

    </html>
    <?php
    exit;
endif;

$ref_ctrl = new Thriveo_AI_Jobs_Referencias_Controller();

// Handle Form Submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['solicitar_ref'])) {
    $data = [
        'nome' => sanitize_text_field($_POST['nome_referente']),
        'email' => sanitize_email($_POST['email_referente']),
        'cargo' => sanitize_text_field($_POST['cargo_referente']),
        'empresa' => sanitize_text_field($_POST['empresa_referente']),
        'tipo_relacao' => sanitize_text_field($_POST['tipo_relacao']),
        'periodo_inicio' => sanitize_text_field($_POST['periodo'])
    ];
    $ref_ctrl->solicitar_referencia($candidato_id, $data);
    $message = 'Convite enviado com sucesso!';
}

global $wpdb;
$referencias = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}thriveo_referencias_profissionais WHERE candidato_id = %d ORDER BY criado_em DESC",
    $candidato_id
));

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Referências | Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0052cc;
            --secondary: #00c896;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --blue-light: #e8f0fe;
            --border: #e2e8f0;
            --white: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text-main);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        aside {
            width: 280px;
            background: var(--primary);
            color: white;
            padding: 30px 20px;
            position: fixed;
            height: 100vh;
        }

        .logo {
            margin-bottom: 40px;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            border-radius: 8px;
            transition: 0.3s;
        }

        .nav-menu a.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        main {
            flex-grow: 1;
            margin-left: 280px;
            padding: 40px;
        }

        .header {
            margin-bottom: 30px;
        }

        .header h1 {
            font-family: 'Barlow', sans-serif;
            font-size: 2rem;
            color: var(--primary);
        }

        .content-layout {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        @media (max-width: 1000px) {
            .content-layout {
                grid-template-columns: 1fr;
            }
        }

        .form-card,
        .list-card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-family: inherit;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }

        .ref-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .ref-item:last-child {
            border-bottom: none;
        }

        .status-badge {
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-enviado {
            background: #fef9c3;
            color: #854d0e;
        }

        .status-respondido {
            background: #dcfce7;
            color: #166534;
        }
    </style>
</head>

<body>

    <div class="app-container">
        <aside>
            <div class="logo">
                <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
            </div>
            <ul class="nav-menu">
                <li><a href="<?php echo home_url('/?thriveo_dashboard=1'); ?>"><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="<?php echo home_url('/?thriveo_trilhas=1'); ?>"><i class="fas fa-road"></i> Trilhas IA</a></li>
                <li><a href="<?php echo home_url('/?thriveo_certificacoes=1'); ?>"><i class="fas fa-medal"></i> Avaliação Técnica</a></li>
                <li><a href="<?php echo home_url('/?thriveo_matching=1'); ?>"><i class="fas fa-bolt"></i> Matching IA</a></li>
                <li><a href="<?php echo home_url('/?thriveo_entrevista=1'); ?>"><i class="fas fa-comments"></i> Entrevista IA</a></li>
                <li><a href="<?php echo home_url('/?thriveo_vagas=1'); ?>"><i class="fas fa-briefcase"></i> Vagas IA</a></li>
                <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Início</a></li>
            </ul>
            <div class="user-info" style="margin-top: auto; padding-top: 20px; border-top: 1px solid var(--border);">
                <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-main);">Sessão Ativa</div>
            </div>
        </aside>

        <main>
            <div class="header">
                <h1>Referências Profissionais (D4)</h1>
                <p>Convide ex-gestores ou colegas para validarem sua jornada profissional.</p>
            </div>

            <?php if ($message): ?>
                <div style="background:#dcfce7; color:#166534; padding:15px; border-radius:10px; margin-bottom:20px;">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="content-layout">
                <div class="form-card">
                    <h3 style="margin-bottom:20px;">Nova Solicitação</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Nome do Referente</label>
                            <input type="text" name="nome_referente" required placeholder="Ex: João Silva">
                        </div>
                        <div class="form-group">
                            <label>E-mail Corporativo</label>
                            <input type="email" name="email_referente" required placeholder="joao@empresa.com.br">
                        </div>
                        <div class="form-group">
                            <label>Cargo dele(a)</label>
                            <input type="text" name="cargo_referente" required placeholder="Ex: CTO / Tech Lead">
                        </div>
                        <div class="form-group">
                            <label>Qual sua relação com ele(a)?</label>
                            <select name="tipo_relacao" required>
                                <option value="gestor_direto">Fui liderado por ele(a)</option>
                                <option value="colega">Éramos colegas de equipe</option>
                                <option value="cliente">Ele(a) era meu cliente</option>
                            </select>
                        </div>
                        <button type="submit" name="solicitar_ref" class="btn-submit">Enviar Convite</button>
                    </form>
                </div>

                <div class="list-card">
                    <h3 style="margin-bottom:20px;">Minhas Solicitações</h3>
                    <?php if (empty($referencias)): ?>
                        <p style="color:var(--text-muted); font-style:italic;">Nenhuma solicitação enviada ainda.</p>
                    <?php else: ?>
                        <?php foreach ($referencias as $ref): ?>
                            <div class="ref-item">
                                <div>
                                    <div style="font-weight:600;">
                                        <?php echo $ref->nome_referente; ?>
                                    </div>
                                    <div style="font-size:0.8rem; color:var(--text-muted);">
                                        <?php echo $ref->email_referente; ?>
                                    </div>
                                </div>
                                <span class="status-badge status-<?php echo $ref->status; ?>">
                                    <?php echo $ref->status === 'respondido' ? 'Validada' : 'Aguardando'; ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/js/hero.js"></script>
</body>

</html>