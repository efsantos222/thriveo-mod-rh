<?php
/**
 * Certification Dashboard Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0, 0, 0, 0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #1a2e4a; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) {
                window.location.href = '<?php echo home_url(); ?>';
            } else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { window.location.reload(); }
                    else { window.location.href = '<?php echo home_url(); ?>'; }
                })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
    <?php exit;
endif;

$cert_ctrl = new Thriveo_AI_Jobs_Certificacao_Controller();
$status = $cert_ctrl->get_certificacoes_status($candidato_id);
$candidato = $status['candidato'];
$certificacoes = $status['certificacoes'];

$is_active = function ($tipo) use ($certificacoes) {
    foreach ($certificacoes as $c) {
        if ($c->tipo === $tipo) return true;
    }
    return false;
};
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificações Thriveo | Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
    <style>
        .header { margin-bottom: 40px; }
        .header h1 { font-weight: 800; font-size: 2.2rem; color: var(--text-main); margin-bottom: 10px; letter-spacing: -0.02em; }
        .header p { color: var(--text-muted); font-size: 1.1rem; }

        .cert-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 40px; }
        .cert-card { background: var(--card-bg); border-radius: 20px; padding: 30px; border: 1px solid rgba(0,0,0,0.05); transition: 0.3s; display: flex; flex-direction: column; position: relative; }
        .cert-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.05); }
        .cert-icon { width: 60px; height: 60px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 20px; }
        
        .d1 { background: rgba(26, 46, 74, 0.1); color: var(--primary); }
        .d2 { background: rgba(255, 107, 53, 0.1); color: var(--secondary); }
        .d3 { background: rgba(124, 58, 237, 0.1); color: var(--accent); }
        .d4 { background: rgba(0, 200, 150, 0.1); color: var(--success); }

        .elite { background: rgba(245, 158, 11, 0.05) !important; color: var(--warning); grid-column: span 2; display: flex; flex-direction: row; align-items: center; gap: 30px; border: 1px solid rgba(245, 158, 11, 0.2); }
        @media (max-width: 900px) { .elite { grid-column: span 1; flex-direction: column; text-align: center; } }

        .cert-card h3 { font-family: 'Plus Jakarta Sans', sans-serif; margin-bottom: 10px; font-size: 1.3rem; color: var(--text-main); }
        .cert-card p { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 20px; }
        
        .status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; font-size: 0.85rem; font-weight: 600; }
        .status-active { background: #dcfce7; color: #166534; }
        .status-locked { background: #f1f5f9; color: #64748b; }

        .btn-action { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: var(--primary); color: white; text-decoration: none; border-radius: 10px; font-weight: 600; transition: 0.3s; margin-top: auto; width: fit-content; }
        .btn-action:hover { opacity: 0.9; }
        .btn-outline { background: transparent; border: 1px solid var(--primary); color: var(--primary); }

        .progress-section { background: var(--card-bg); border-radius: 20px; padding: 40px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 40px; }
        .progress-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .progress-bar-container { height: 12px; background: #e2e8f0; border-radius: 10px; overflow: hidden; }
        .progress-bar-fill { height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); transition: 1s ease-in-out; }

        .elite-seal { width: 120px; height: 120px; background: var(--warning); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: white; box-shadow: 0 10px 20px rgba(245, 158, 11, 0.3); animation: float 3s ease-in-out infinite; flex-shrink: 0; }
        .elite-content { flex-grow: 1; text-align: left; }
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }

        #loading-overlay { display: none; position: fixed; inset: 0; background: rgba(255,255,255,0.7); z-index: 2000; align-items: center; justify-content: center; }
        .spinner { width:40px; height:40px; border:4px solid #eee; border-top-color:var(--primary); border-radius:50%; animation:spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div id="loading-overlay"><div class="spinner"></div></div>

    <div class="app-container">
        <aside class="app-sidebar">
            <div class="app-logo">
                <a href="<?php echo home_url(); ?>">
                    <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="?thriveo_dashboard=1"><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="?thriveo_certificacoes=1" class="active"><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
                <li><a href="?thriveo_vagas=1"><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
                <li><a href="?thriveo_talentos=1"><i class="fas fa-users"></i> Banco de Talentos</a></li>
                <li><a href="?thriveo_empresa_vagas=1"><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
                <li><a href="?thriveo_matching=1"><i class="fas fa-bolt"></i> Matching IA</a></li>
                <li><a href="?thriveo_entrevista=1"><i class="fas fa-comments"></i> Entrevista IA</a></li>
                <li><a href="?thriveo_faq=1"><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
                <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
                <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
            </ul>
        </aside>

        <main class="app-main">
            <div class="header">
                <h1>Certificações Thriveo</h1>
                <p>Candidatos certificados recebem até 3x mais convites para entrevistas. Valide seu potencial.</p>
            </div>

            <div class="progress-section">
                <div class="progress-header">
                    <div>
                        <h2>Seu Progresso de Elite</h2>
                        <p>Complete as 4 dimensões para se tornar um <strong>Thriveo Elite</strong>.</p>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 2.5rem; font-weight: 700; color: var(--primary);">
                            <?php
                            $active_count = ($is_active('D1') ? 1 : 0) + ($is_active('D2') ? 1 : 0) + ($is_active('D3') ? 1 : 0) + ($is_active('D4') ? 1 : 0);
                            echo ($active_count / 4) * 100;
                            ?>%
                        </span>
                    </div>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar-fill" style="width: <?php echo ($active_count / 4) * 100; ?>%"></div>
                </div>
            </div>

            <div class="cert-grid">
                <div class="cert-card">
                    <div class="cert-icon d1"><i class="fas fa-user-check"></i></div>
                    <h3>D1: Perfil Verificado</h3>
                    <p>Validação automática baseada no seu GitHub e LinkedIn. Autenticidade garantida.</p>
                    <?php if ($is_active('D1')): ?>
                        <span class="status-badge status-active"><i class="fas fa-check-circle"></i> Verificado</span>
                    <?php else: ?>
                        <span class="status-badge status-locked"><i class="fas fa-lock"></i> Incompleto</span>
                        <a href="?thriveo_dashboard=1" class="btn-action">Atualizar Perfil</a>
                    <?php endif; ?>
                </div>

                <div class="cert-card">
                    <div class="cert-icon d2"><i class="fas fa-code"></i></div>
                    <h3>D2: Hard Skills</h3>
                    <p>Prove seu conhecimento técnico através de desafios práticos em tempo real.</p>
                    <?php if ($is_active('D2')): ?>
                        <span class="status-badge status-active"><i class="fas fa-check-circle"></i> Aprovado</span>
                    <?php else: ?>
                        <span class="status-badge status-locked"><i class="fas fa-lock"></i> Pendente</span>
                        <a href="?thriveo_trilhas=1" class="btn-action">Fazer Testes</a>
                    <?php endif; ?>
                </div>

                <div class="cert-card">
                    <div class="cert-icon d3"><i class="fas fa-brain"></i></div>
                    <h3>D3: Soft Skills</h3>
                    <p>Mapeamento comportamental DISC e Fit Cultural para empresas de tecnologia.</p>
                    <?php if ($is_active('D3')): ?>
                        <span class="status-badge status-active"><i class="fas fa-check-circle"></i> Perfil Mapeado</span>
                    <?php else: ?>
                        <span class="status-badge status-locked"><i class="fas fa-lock"></i> Não Iniciado</span>
                        <a href="?thriveo_softskills=1" class="btn-action">Avaliar Perfil</a>
                    <?php endif; ?>
                </div>

                <div class="cert-card">
                    <div class="cert-icon d4"><i class="fas fa-users-viewfinder"></i></div>
                    <h3>D4: Reputação</h3>
                    <p>Coleta de referências verificadas de ex-gestores e colegas de trabalho.</p>
                    <?php if ($is_active('D4')): ?>
                        <span class="status-badge status-active"><i class="fas fa-check-circle"></i> Verificado</span>
                    <?php else: ?>
                        <span class="status-badge status-locked"><i class="fas fa-lock"></i> Aguardando</span>
                        <a href="?thriveo_referencias=1" class="btn-action">Pedir Referência</a>
                    <?php endif; ?>
                </div>

                <div class="cert-card elite">
                    <div class="elite-seal"><i class="fas fa-crown"></i></div>
                    <div class="elite-content">
                        <h3>⭐ Thriveo Elite Certified</h3>
                        <p>O nível máximo de reconhecimento. Candidatos Elite aparecem primeiro nas buscas e têm acesso a vagas exclusivas.</p>
                        <?php if ($is_active('ELITE')): ?>
                            <span class="status-badge status-active"><i class="fas fa-star"></i> VOCÊ É ELITE!</span>
                        <?php else: ?>
                            <p style="color:var(--text-muted); font-style:italic;">Complete as 4 missões acima para desbloquear seu selo.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>