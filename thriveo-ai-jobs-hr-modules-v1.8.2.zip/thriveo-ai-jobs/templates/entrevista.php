<?php
if (!defined('ABSPATH')) exit;

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0,0,0,0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #0052cc; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) { window.location.href = '<?php echo home_url(); ?>'; }
            else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => { if (data.success) window.location.reload(); else window.location.href = '<?php echo home_url(); ?>'; })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
<?php exit; endif; ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Entrevista com IA — Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-modern.css">
    <style>
        :root {
            --navy: #0f172a;
            --danger: #ef4444;
        }
        
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); overflow: hidden; height: 100vh; }
        
        .interview-container { flex: 1; display: grid; grid-template-columns: 320px 1fr; gap: 2px; background: var(--border); overflow: hidden; height:calc(100vh - 40px); border-radius: 16px; border: 1px solid var(--border); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);}
        
        /* Sidebar */
        .interview-sidebar { background: var(--card-bg); padding: 2rem; display: flex; flex-direction: column; gap: 2rem; overflow-y: auto; }
        .interview-sidebar h2 { font-size: 1.1rem; font-weight: 800; margin: 0; letter-spacing: -0.01em; color: var(--navy); }
        .interviewer-info { display: flex; align-items: center; gap: 1rem; padding: 1rem; background: var(--bg); border-radius: 12px; border: 1px solid var(--border); }
        .interviewer-av { width: 44px; height: 44px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: #fff; }
        .interviewer-text div { font-size: 0.85rem; font-weight: 700; color: var(--navy); }
        .interviewer-text span { font-size: 0.75rem; color: var(--text-muted); }
        
        .interview-metrics { display: flex; flex-direction: column; gap: 1.5rem; }
        .metric-item { display: flex; flex-direction: column; gap: 0.4rem; }
        .metric-header { display: flex; justify-content: space-between; font-size: 0.75rem; font-weight: 700; color: var(--text-light); text-transform: uppercase; }
        .metric-bar { height: 6px; background: var(--border); border-radius: 3px; overflow: hidden; }
        .metric-fill { height: 100%; background: var(--accent); transition: width 0.3s; }
        
        /* Chat Area */
        .chat-area { background: #fff; display: flex; flex-direction: column; }
        
        .chat-header { padding: 1.5rem 2rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .chat-header h1 { font-size: 1.25rem; font-weight: 800; color: var(--navy); margin: 0; }
        
        .chat-messages { flex: 1; padding: 2rem; overflow-y: auto; display: flex; flex-direction: column; gap: 1.5rem; background: #fff; }
        
        .msg { max-width: 80%; display: flex; flex-direction: column; gap: 0.3rem; }
        .msg-ai { align-self: flex-start; }
        .msg-user { align-self: flex-end; }
        
        .bubble { padding: 1rem 1.25rem; border-radius: 16px; font-size: 0.95rem; line-height: 1.6; }
        .msg-ai .bubble { background: var(--bg); color: var(--navy); border: 1px solid var(--border); border-bottom-left-radius: 4px; }
        .msg-user .bubble { background: var(--primary); color: #fff; border-bottom-right-radius: 4px; }
        
        .msg-meta { font-size: 0.7rem; color: var(--text-light); padding: 0 0.5rem; }
        .msg-user .msg-meta { text-align: right; }
        
        .chat-input-wrapper { padding: 1.5rem 2rem; background: var(--white); border-top: 1px solid var(--border); box-shadow: 0 -4px 12px rgba(0,0,0,0.02); }
        .input-box { display: flex; gap: 1rem; background: var(--bg); padding: 0.5rem; border-radius: 12px; border: 1px solid var(--border); transition: border-color 0.2s, box-shadow 0.2s; }
        .input-box:focus-within { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(0, 200, 150, 0.1); }
        .input-box input { flex: 1; border: none; background: transparent; padding: 0.5rem 0.75rem; font-family: 'Plus Jakarta Sans', sans-serif; font-size: 0.95rem; outline: none; color: var(--navy); }
        .input-box button { background: var(--primary); color: #fff; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .input-box button:hover { background: var(--navy); }
    </style>
</head>
<body>

<div class="app-container">
<aside class="app-sidebar">
    <div class="app-logo">
        <a href="<?php echo home_url(); ?>">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
        </a>
    </div>
    <ul class="nav-menu">
        <li><a href="?thriveo_dashboard=1" class=""><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
        <li><a href="?thriveo_certificacoes=1" class=""><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
        <li><a href="?thriveo_vagas=1" class=""><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
        <li><a href="?thriveo_talentos=1" class=""><i class="fas fa-users"></i> Banco de Talentos</a></li>
        <li><a href="?thriveo_empresa_vagas=1" class=""><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
        <li><a href="?thriveo_matching=1" class=""><i class="fas fa-bolt"></i> Matching IA</a></li>
        <li><a href="?thriveo_entrevista=1" class="active"><i class="fas fa-comments"></i> Entrevista IA</a></li>
        <li><a href="?thriveo_faq=1" class=""><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
        <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
        <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
    </ul>
    <div class="sidebar-user-info">
        <div class="sidebar-user-name">Usuário Ativo</div>
        <div class="sidebar-user-status">Sessão Segura</div>
    </div>
</aside>

<main class="app-main" style="padding: 20px;">
    <div class="interview-container">
        <!-- INTERVIEW SIDEBAR -->
        <aside class="interview-sidebar">
            <div>
                <div class="tag-modern" style="margin-bottom: 0.5rem; display:inline-block; font-size:0.75rem; font-weight:700; background:rgba(0,200,150,0.1); color:var(--accent); padding:4px 12px; border-radius:20px;">Simulação Técnica</div>
                <h2>Foco: Desenvolvedor GenAI</h2>
            </div>
    
            <div class="interviewer-info">
                <div class="interviewer-av"><i class="fas fa-robot"></i></div>
                <div class="interviewer-text">
                    <div>Thriveo Agent</div>
                    <span>Technical Interviewer</span>
                </div>
            </div>
    
            <div class="interview-metrics">
                <div class="metric-item">
                    <div class="metric-header"><span>Domínio Técnico</span><span>65%</span></div>
                    <div class="metric-bar"><div class="metric-fill" style="width: 65%;"></div></div>
                </div>
                <div class="metric-item">
                    <div class="metric-header"><span>Clareza</span><span>80%</span></div>
                    <div class="metric-bar"><div class="metric-fill" style="width: 80%;"></div></div>
                </div>
                <div class="metric-item">
                    <div class="metric-header"><span>Soft Skills</span><span>45%</span></div>
                    <div class="metric-bar"><div class="metric-fill" style="width: 45%; background: var(--warning);"></div></div>
                </div>
            </div>
    
            <div style="margin-top: auto; padding-top: 2rem; border-top: 1px solid var(--border);">
                <p style="font-size: 0.75rem; color: var(--text-light); border-left: 2px solid var(--primary); padding-left: 1rem;">
                    <i class="fas fa-lightbulb" style="color:var(--accent); margin-right:4px;"></i> Dica da IA: Tente ser mais específico sobre a arquitetura de transformers na sua próxima resposta.
                </p>
            </div>
        </aside>
    
        <!-- CHAT AREA -->
        <main class="chat-area">
            <div class="chat-header">
                <h1>Sessão de Entrevista</h1>
                <button style="background:var(--danger); color:white; border:none; padding:8px 16px; border-radius:8px; font-weight:600; cursor:pointer;"><i class="fas fa-stop-circle"></i> Encerrar Sessão</button>
            </div>
            
            <div class="chat-messages" id="chat-stream">
                <!-- AI Message -->
                <div class="msg msg-ai">
                    <div class="bubble">
                        Olá Ezequiel! Vamos iniciar sua simulação técnica para a vaga de Desenvolvedor GenAI. <br><br>
                        Para começar, poderia me explicar como você abordaria o problema de "hallucination" em um sistema de RAG (Retrieval Augmented Generation)?
                    </div>
                    <div class="msg-meta">Agora mesmo</div>
                </div>
    
                <!-- User Message -->
                <div class="msg msg-user">
                    <div class="bubble">
                        Com certeza. Para mitigar alucinações em RAG, eu focaria primeiro na qualidade do chunking e dos embeddings. Além disso, utilizaria técnicas de self-grading, onde um modelo avalia se a resposta gerada está de fato baseada no documento recuperado (grounding).
                    </div>
                    <div class="msg-meta">Lido</div>
                </div>
    
                <!-- AI Message -->
                <div class="msg msg-ai">
                    <div class="bubble">
                        Excelente ponto. O grounding é fundamental. Como você implementaria esse self-grading? Utilizaria algum framework específico como LangGraph ou faria de forma customizada?
                    </div>
                    <div class="msg-meta">Digitando...</div>
                </div>
            </div>
    
            <div class="chat-input-wrapper">
                <div class="input-box">
                    <input type="text" placeholder="Digite sua resposta técnica aqui...">
                    <button><i class="fas fa-paper-plane"></i> Enviar</button>
                </div>
            </div>
        </main>
    </div>
</main>
</div>

</body>
</html>
