<?php
if (!defined('ABSPATH')) exit;

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

// Session Sync Logic
if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f8fafc; color: #1e293b; }
            .sync-box { text-align: center; }
            .spinner { border: 4px solid rgba(0,0,0,0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #0052cc; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) { window.location.href = '<?php echo home_url(); ?>'; }
            else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                .then(r => r.json())
                .then(data => { if (data.success) window.location.reload(); else window.location.href = '<?php echo home_url(); ?>'; })
                .catch(() => { window.location.href = '<?php echo home_url(); ?>'; });
            }
        </script>
    </body>
    </html>
<?php exit; endif; ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Trilhas IA — Thriveo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL . 'assets/css/thriveo-modern.css'; ?>">
    <style>
        :root {
            --nav-height: 72px;
        }
        body { background: #fcfcfd; font-family: 'Plus Jakarta Sans', sans-serif; margin: 0; padding: 0; color: #1e293b; }
        
        /* Navigation */
        .nav-modern { 
            height: var(--nav-height);
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .nav-left, .nav-right { display: flex; align-items: center; gap: 1.5rem; }
        .nav-brand { font-weight: 800; color: #0052cc; font-size: 1.25rem; text-decoration: none; display: flex; align-items: center; gap: 10px; }
        .nav-brand img { height: 32px; width: auto; }
        
        .back-link { 
            text-decoration: none; 
            color: #64748b; 
            font-size: 0.875rem; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 0.5rem; 
            transition: all 0.2s;
            padding: 8px 12px;
            border-radius: 8px;
        }
        .back-link:hover { color: #0052cc; background: rgba(0,82,204,0.05); }

        .user-pill {
            background: #fff;
            border: 1px solid #e2e8f0;
            padding: 6px 14px;
            border-radius: 100px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            font-weight: 600;
            box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }
        .user-avatar { width: 24px; height: 24px; background: #0052cc; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; }

        /* Hero Section */
        .hero-section {
            padding: 80px 2rem 60px;
            background: radial-gradient(circle at top right, rgba(0,82,204,0.03), transparent), #fff;
            text-align: center;
            border-bottom: 1px solid #f1f5f9;
        }
        .tag-badge {
            display: inline-block;
            padding: 6px 14px;
            background: rgba(0,82,204,0.08);
            color: #0052cc;
            border-radius: 100px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 20px;
        }
        .hero-section h1 {
            font-size: 2.75rem;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 16px;
            letter-spacing: -0.03em;
            line-height: 1.1;
        }
        .hero-section p {
            color: #64748b;
            font-size: 1.1rem;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Content Grid */
        .main-container { max-width: 1200px; margin: 0 auto; padding: 60px 2rem; }
        .grid-trilhas { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); 
            gap: 2.5rem; 
        }

        .trail-card { 
            background: #fff; 
            border: 1px solid #e2e8f0; 
            border-radius: 20px; 
            overflow: hidden; 
            display: flex;
            flex-direction: column;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.01);
        }
        .trail-card:hover { 
            transform: translateY(-8px); 
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 10px 10px -5px rgba(0, 0, 0, 0.02);
            border-color: rgba(0,82,204,0.2);
        }

        .trail-header { 
            padding: 32px; 
            position: relative;
            color: #fff;
            min-height: 120px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }
        .header-bg-blue { background: linear-gradient(135deg, #0052cc, #003d99); }
        .header-bg-purple { background: linear-gradient(135deg, #7c3aed, #5b21b6); }
        .header-bg-green { background: linear-gradient(135deg, #059669, #047857); }

        .trail-header h3 { font-size: 1.5rem; font-weight: 700; margin: 0; letter-spacing: -0.01em; }
        .trail-header .level-tag { 
            position: absolute; 
            top: 32px; 
            left: 32px;
            font-size: 0.7rem;
            font-weight: 800;
            text-transform: uppercase;
            padding: 4px 10px;
            background: rgba(255,255,255,0.2);
            border-radius: 6px;
            backdrop-filter: blur(4px);
        }

        .trail-body { padding: 32px; flex-grow: 1; display: flex; flex-direction: column; }
        .trail-desc { color: #64748b; font-size: 0.95rem; margin-bottom: 24px; line-height: 1.5; }

        .trail-steps { list-style: none; padding: 0; margin: 0 0 24px 0; }
        .trail-steps li { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            padding: 14px 0; 
            border-bottom: 1px solid #f1f5f9; 
            font-size: 0.9rem; 
            color: #334155;
            font-weight: 500;
        }
        .trail-steps li:last-child { border-bottom: none; }
        
        .step-icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            flex-shrink: 0;
        }
        .icon-done { background: #dcfce7; color: #166534; }
        .icon-active { background: #ebf5ff; color: #0052cc; border: 1px solid #cce3ff; }
        .icon-locked { background: #f1f5f9; color: #94a3b8; }

        .progress-container { margin-top: auto; padding-top: 20px; }
        .progress-bar { height: 6px; background: #f1f5f9; border-radius: 10px; overflow: hidden; }
        .progress-fill { height: 100%; background: #22c55e; border-radius: 10px; transition: width 1s ease; }
        .progress-info { display: flex; justify-content: space-between; font-size: 0.75rem; color: #94a3b8; margin-top: 8px; font-weight: 600; }

        .btn-trail {
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 24px;
        }
        .btn-primary { background: #0052cc; color: #fff; box-shadow: 0 4px 12px rgba(0,82,204,0.2); }
        .btn-primary:hover { background: #0044aa; transform: scale(1.02); }
        .btn-locked { background: #f8fafc; color: #94a3b8; border: 1px solid #e2e8f0; cursor: not-allowed; }

        @media (max-width: 768px) {
            .hero-section h1 { font-size: 2rem; }
            .nav-brand span { display: none; }
        }
    </style>
</head>
<body>

<nav class="nav-modern">
    <div class="nav-left">
        <a href="<?php echo home_url('/?thriveo_dashboard=1'); ?>" class="nav-brand">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
            <span>Thriveo IA</span>
        </a>
    </div>
    <div class="nav-right">
        <a href="?thriveo_faq=1" class="back-link">
            <i class="fa-solid fa-question-circle"></i> FAQ / Ajuda
        </a>
        <a href="<?php echo home_url('/?thriveo_dashboard=1'); ?>" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Painel Geral
        </a>
        <div class="user-pill">
            <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['thriveo_candidato_nome'] ?? 'C', 0, 1)); ?></div>
            <span><?php echo esc_html($_SESSION['thriveo_candidato_nome'] ?? 'Candidato'); ?></span>
        </div>
    </div>
</nav>

<div class="hero-section">
    <div class="tag-badge">Módulo de Carreiras</div>
    <h1>Domine a Inteligência Artificial</h1>
    <p>Roteiros guiados por especialistas de elite para transformar sua carreira no maior portal de talentos de IA do país.</p>
</div>

<div class="main-container">
    <div class="grid-trilhas">
        <?php
        global $wpdb;
        $trilhas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}thriveo_trilhas WHERE ativa = 1 ORDER BY criado_em DESC");

        if ($trilhas):
            foreach ($trilhas as $trilha):
                $cor_bg = 'header-bg-blue';
                if (strpos(strtolower($trilha->titulo), 'python') !== false) $cor_bg = 'header-bg-purple';
                if (strpos(strtolower($trilha->titulo), 'machine') !== false) $cor_bg = 'header-bg-green';
        ?>
            <div class="trail-card">
                <div class="trail-header <?php echo $cor_bg; ?>" style="<?php echo $trilha->image_url ? 'background: url('.esc_url($trilha->image_url).') center/cover;' : ''; ?>">
                    <span class="level-tag"><?php echo esc_html(ucfirst($trilha->nivel)); ?></span>
                    <h3 style="<?php echo $trilha->image_url ? 'background: rgba(0,0,0,0.5); padding: 10px; border-radius: 8px;' : ''; ?>"><?php echo esc_html($trilha->titulo); ?></h3>
                </div>
                <div class="trail-body">
                    <p class="trail-desc"><?php echo nl2br(esc_html(wp_trim_words($trilha->conteudo, 20))); ?></p>
                    
                    <div style="margin-top:auto;">
                        <a href="?thriveo_trilhas=1&trilha_id=<?php echo $trilha->id; ?>" class="btn-trail btn-primary">
                            Ver Conteúdo Completo <i class="fa-solid fa-chevron-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php 
            endforeach;
        else: ?>
            <!-- FALLBACK: TRILHAS PADRÃO SE NÃO HOUVER NADA NO BANCO -->
            <!-- TRILHA 1 -->
            <div class="trail-card">
                <div class="trail-header header-bg-blue">
                    <span class="level-tag">Iniciante · Gratuito</span>
                    <h3>🧠 Fundamentos de IA Generativa</h3>
                </div>
                <div class="trail-body">
                    <p class="trail-desc">Entenda a base teórica e prática dos Large Language Models e o futuro da automação inteligente.</p>
                    <ul class="trail-steps">
                        <li><div class="step-icon icon-done"><i class="fa-solid fa-check"></i></div> Introdução ao campo da GenAI</li>
                        <li><div class="step-icon icon-done"><i class="fa-solid fa-check"></i></div> Funcionamento de LLMs</li>
                        <li><div class="step-icon icon-active"><i class="fa-solid fa-play"></i></div> Arquitetura Transformer</li>
                        <li><div class="step-icon icon-locked"><i class="fa-solid fa-lock"></i></div> Alinhamento e RLHF</li>
                    </ul>
                    <div class="progress-container">
                        <div class="progress-bar"><div class="progress-fill" style="width: 50%;"></div></div>
                        <div class="progress-info"><span>50% Concluído</span><span>Módulo 3 de 4</span></div>
                    </div>
                    <button class="btn-trail btn-primary">Continuar Aula <i class="fa-solid fa-chevron-right"></i></button>
                </div>
            </div>

            <!-- TRILHA 2 -->
            <div class="trail-card">
                <div class="trail-header header-bg-purple">
                    <span class="level-tag">Intermediário · Pro</span>
                    <h3>⚙️ Engenharia de Prompts Avançada</h3>
                </div>
                <div class="trail-body">
                    <p class="trail-desc">Técnicas avançadas de Chain-of-Thought, RAG e integração profunda com ecossistemas de dados.</p>
                    <ul class="trail-steps">
                        <li><div class="step-icon icon-locked"><i class="fa-solid fa-lock"></i></div> Chain of Thought (CoT)</li>
                        <li><div class="step-icon icon-locked"><i class="fa-solid fa-lock"></i></div> Retrieval Augmented Gen (RAG)</li>
                        <li><div class="step-icon icon-locked"><i class="fa-solid fa-lock"></i></div> Multi-modal Prompting</li>
                        <li><div class="step-icon icon-locked"><i class="fa-solid fa-lock"></i></div> Otimização de Tokens</li>
                    </ul>
                    <div class="progress-container">
                        <div class="progress-bar"><div class="progress-fill" style="width: 0%;"></div></div>
                        <div class="progress-info"><span>Conteúdo Bloqueado</span><span>Requer Assinatura Pro</span></div>
                    </div>
                    <button class="btn-trail btn-locked"><i class="fa-solid fa-crown"></i> Desbloquear Trilha</button>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
