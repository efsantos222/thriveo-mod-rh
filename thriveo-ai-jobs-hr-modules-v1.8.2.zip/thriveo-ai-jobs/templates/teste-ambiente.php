<?php
/**
 * D2 Test Environment Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">

    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body {
                font-family: sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                background: #f8fafc;
                color: #1e293b;
            }

            .sync-box {
                text-align: center;
            }

            .spinner {
                border: 4px solid rgba(0, 0, 0, 0.1);
                width: 36px;
                height: 36px;
                border-radius: 50%;
                border-left-color: #1a2e4a;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            }

            @keyframes spin {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }
        </style>
    </head>

    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) {
                window.location.href = '<?php echo home_url(); ?>';
            } else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            window.location.reload();
                        } else {
                            window.location.href = '<?php echo home_url(); ?>';
                        }
                    })
                    .catch(() => {
                        window.location.href = '<?php echo home_url(); ?>';
                    });
            }
        </script>
    </body>

    </html>
    <?php
    exit;
endif;

// Track and level selection (could be passed via GET)
$trilha = isset($_GET['trilha']) ? $_GET['trilha'] : 'php';
$nivel = isset($_GET['nivel']) ? $_GET['nivel'] : 'basico';

$test_ctrl = new Thriveo_AI_Jobs_Testes_Tecnicos_Controller();
$sessao_id = $test_ctrl->iniciar_teste($candidato_id, $trilha, $nivel);

if (!$sessao_id) {
    // Redirect back if no questions available
    echo "<div style='padding:50px; text-align:center;'><h2>Trilha em manutenção</h2><p>Desculpe, este teste ainda não possui questões suficientes. Tente novamente mais tarde.</p><a href='?thriveo_certificacoes=1'>Voltar</a></div>";
    exit;
}

global $wpdb;
$sessao = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}thriveo_sessoes_teste WHERE id = %d", $sessao_id));
$questoes = json_decode($sessao->questoes_json, true);

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste em Andamento | Thriveo Certification</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono&display=swap"
        rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <style>
        :root {
            --bg-dark: #0f172a;
            --surface: #1e293b;
            --primary: #0052cc;
            --accent: #4c84ff;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-dark);
            color: var(--text);
            overflow: hidden;
        }

        .test-navbar {
            height: 70px;
            background: var(--surface);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        .test-logo {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .timer-box {
            background: rgba(0, 0, 0, 0.3);
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 700;
            font-family: 'JetBrains Mono';
            border: 2px solid var(--primary);
            color: var(--primary);
        }

        .test-container {
            display: flex;
            height: calc(100vh - 70px);
        }

        .sidebar-progress {
            width: 300px;
            background: var(--surface);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            padding: 30px;
            overflow-y: auto;
        }

        .q-item {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 10px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.03);
            transition: 0.2s;
            font-size: 0.9rem;
        }

        .q-item.active {
            background: var(--primary);
            color: white;
        }

        .q-item.answered {
            border-left: 4px solid #00c896;
        }

        .main-content {
            flex-grow: 1;
            padding: 60px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .question-box {
            max-width: 800px;
            margin: 0 auto;
            width: 100%;
        }

        .question-header {
            margin-bottom: 30px;
        }

        .question-header h2 {
            font-size: 1.6rem;
            margin-bottom: 15px;
        }

        .alternatives {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .alternative {
            padding: 20px;
            background: var(--surface);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .alternative:hover {
            border-color: var(--primary);
        }

        .alternative.selected {
            border-color: var(--primary);
            background: rgba(255, 107, 53, 0.1);
        }

        .radio-circle {
            width: 20px;
            height: 20px;
            border: 2px solid var(--text-muted);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }

        .alternative.selected .radio-circle {
            border-color: var(--primary);
        }

        .alternative.selected .radio-circle::after {
            content: '';
            width: 10px;
            height: 10px;
            background: var(--primary);
            border-radius: 50%;
        }

        .footer-nav {
            margin-top: auto;
            padding-top: 50px;
            display: flex;
            justify-content: space-between;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            width: 100%;
        }

        .btn-nav {
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: 0.3s;
            font-size: 1rem;
        }

        .btn-prev {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .btn-next {
            background: var(--primary);
            color: white;
        }

        /* Code Mirror Mock */
        .code-box {
            background: #1e1e1e;
            padding: 20px;
            border-radius: 12px;
            font-family: 'JetBrains Mono';
            margin-bottom: 25px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>

<body>

    <nav class="test-navbar">
        <div class="test-logo">THRIVEO <span style="font-weight:300; color:white; font-family:'Plus Jakarta Sans';">CERTIFICATION</span></div>
        <div class="timer-box" id="timer">--:--</div>
        <div>
            <button class="btn-nav btn-next" onclick="finalizarTeste()" id="btn-finalizar"
                style="display:none;">Finalizar Teste</button>
        </div>
    </nav>

    <div class="test-container">
        <div class="sidebar-progress">
            <h4
                style="margin-bottom:20px; color:var(--text-muted); text-transform:uppercase; font-size:0.8rem; letter-spacing:1px;">
                Questões</h4>
            <div id="questoes-list">
                <?php foreach ($questoes as $i => $q): ?>
                    <div class="q-item <?php echo $i === 0 ? 'active' : ''; ?>" id="nav-q-<?php echo $i; ?>"
                        onclick="gotoQuestion(<?php echo $i; ?>)">
                        Questão
                        <?php echo $i + 1; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <main class="main-content">
            <div class="question-box" id="question-container">
                <!-- Content will be injected by JS -->
            </div>

            <div class="footer-nav">
                <button class="btn-nav btn-prev" disabled id="prev-btn">Anterior</button>
                <button class="btn-nav btn-next" onclick="nextQuestion()" id="next-btn">Próxima</button>
            </div>
        </main>
    </div>

    <script>
        const questoes = <?php echo json_encode($questoes); ?>;
        const totalQuestoes = questoes.length;
        const resps = {};
        let currentIdx = 0;
        let timeLeft = <?php echo $sessao->tempo_limite_min * 60; ?>;

        function renderQuestion(idx) {
            const q = questoes[idx];
            let html = `
                <div class="question-header">
                    <span style="color:var(--primary); font-weight:700; text-transform:uppercase; font-size:0.8rem;">Questão ${idx + 1} de ${totalQuestoes}</span>
                    <h2>${q.enunciado}</h2>
                </div>
            `;

            if (q.codigo_base) {
                html += `<div class="code-box"><pre><code>${q.codigo_base}</code></pre></div>`;
            }

            const alts = JSON.parse(q.alternativas_json);
            html += `<div class="alternatives">`;
            Object.entries(alts).forEach(([key, val]) => {
                const isSelected = resps[q.id] === key;
                html += `
                    <div class="alternative ${isSelected ? 'selected' : ''}" onclick="selectAlt('${q.id}', '${key}')">
                        <div class="radio-circle"></div>
                        <span>${val}</span>
                    </div>
                `;
            });
            html += `</div>`;

            $('#question-container').hide().html(html).fadeIn(300);
            $('#questoes-list .q-item').removeClass('active');
            $(`#nav-q-${idx}`).addClass('active');

            // Button controls
            $('#prev-btn').prop('disabled', idx === 0);
            if (idx === totalQuestoes - 1) {
                $('#next-btn').hide();
                $('#btn-finalizar').show();
            } else {
                $('#next-btn').show();
                $('#btn-finalizar').hide();
            }
        }

        function selectAlt(qId, key) {
            resps[qId] = key;
            $(`#nav-q-${currentIdx}`).addClass('answered');
            renderQuestion(currentIdx);
        }

        function nextQuestion() {
            if (currentIdx < totalQuestoes - 1) {
                currentIdx++;
                renderQuestion(currentIdx);
            }
        }

        function gotoQuestion(idx) {
            currentIdx = idx;
            renderQuestion(currentIdx);
        }

        // Timer
        const timerInt = setInterval(() => {
            if (timeLeft <= 0) {
                clearInterval(timerInt);
                finalizarTeste();
                return;
            }
            timeLeft--;
            const mins = Math.floor(timeLeft / 60);
            const secs = timeLeft % 60;
            $('#timer').text(`${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`);
            if (timeLeft < 300) $('#timer').css('color', '#ef4444');
        }, 1000);

        function finalizarTeste() {
            if (confirm("Deseja realmente finalizar o teste?")) {
                // Request to backend to finalize
                $.post('', { action: 'finalizar_teste', sessao_id: <?php echo $sessao_id; ?>, respostas: resps }, (res) => {
                    window.location.href = '?thriveo_certificacoes=1';
                });
            }
        }

        // Detection of tab switch (anti-cheat)
        document.addEventListener("visibilitychange", function () {
            if (document.hidden) {
                console.warn("Troca de aba detectada.");
                // Log via AJAX if needed
            }
        });

        $(document).ready(() => {
            renderQuestion(0);
        });

    </script>
</body>

</html>