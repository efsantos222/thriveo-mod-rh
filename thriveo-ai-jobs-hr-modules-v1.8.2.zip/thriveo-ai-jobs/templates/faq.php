<?php
/**
 * FAQ / Help Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central de Ajuda | Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo THRIVEO_AI_JOBS_URL; ?>assets/css/thriveo-sidebar-layout.css">
    <style>
        .faq-header { margin-bottom: 40px; }
        .faq-header h1 { font-weight: 800; font-size: 2.2rem; color: var(--text-main); margin-bottom: 10px; }
        .faq-header p { color: var(--text-muted); font-size: 1.1rem; }

        .faq-section { margin-bottom: 30px; background: var(--card-bg); border-radius: 20px; padding: 30px; border: 1px solid rgba(0,0,0,0.05); }
        .faq-section h2 { font-size: 1.5rem; color: var(--primary); margin-bottom: 20px; display: flex; align-items: center; gap: 12px; }
        
        .faq-item { border-bottom: 1px solid #f1f5f9; padding: 20px 0; }
        .faq-item:last-child { border-bottom: none; }
        .faq-question { font-weight: 700; cursor: pointer; display: flex; justify-content: space-between; align-items: center; color: var(--text-main); font-size: 1.05rem; }
        .faq-answer { margin-top: 15px; color: var(--text-muted); line-height: 1.6; display: none; }
        .faq-item.active .faq-answer { display: block; }
        .faq-item.active .fa-chevron-down { transform: rotate(180deg); }
        .fa-chevron-down { transition: 0.3s; font-size: 0.9rem; }

        .category-badge { padding: 4px 10px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; display: inline-block; }
        .cat-candidato { background: #e0f2fe; color: #0369a1; }
        .cat-empresa { background: #fef3c7; color: #92400e; }
        .cat-ia { background: #ede9fe; color: #6d28d9; }
    </style>
</head>
<body>
    <div class="app-container">
        <aside class="app-sidebar">
            <div class="app-logo">
                <a href="<?php echo home_url(); ?>">
                    <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75-transparente.png" alt="Thriveo">
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="?thriveo_dashboard=1"><i class="fas fa-user-circle"></i> Meu Perfil</a></li>
                <li><a href="?thriveo_certificacoes=1"><i class="fas fa-certificate"></i> Avaliação Técnica</a></li>
                <li><a href="?thriveo_vagas=1"><i class="fas fa-briefcase"></i> Portal de Vagas</a></li>
                <li><a href="?thriveo_talentos=1"><i class="fas fa-users"></i> Banco de Talentos</a></li>
                <li><a href="?thriveo_empresa_vagas=1"><i class="fas fa-tasks"></i> Gestão de Vagas</a></li>
                <li><a href="?thriveo_matching=1"><i class="fas fa-bolt"></i> Matching IA</a></li>
                <li><a href="?thriveo_entrevista=1"><i class="fas fa-comments"></i> Entrevista IA</a></li>
                <li><a href="?thriveo_faq=1" class="active"><i class="fas fa-question-circle"></i> FAQ / Ajuda</a></li>
                <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Voltar ao Site</a></li>
                <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="fas fa-sign-out-alt"></i> Sair da Conta</a></li>
            </ul>
        </aside>

        <main class="app-main">
            <div class="faq-header">
                <h1>Central de Ajuda</h1>
                <p>Tudo o que você precisa saber para dominar a plataforma Thriveo.</p>
            </div>

            <div class="faq-section">
                <h2><i class="fas fa-user"></i> Candidatos</h2>
                
                <div class="faq-item">
                    <div class="faq-question">Como completar meu perfil com LinkedIn/GitHub? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        No seu painel (Meu Perfil), clique nos botões de conexão social. O sistema importará automaticamente suas experiências, repositórios e habilidades, formatando seu currículo para a IA.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">O que é a Certificação Elite? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        É o selo de máxima qualidade da plataforma. Para obtê-lo, você deve completar as 4 dimensões (D1 a D4): Perfil Verificado, Hard Skills, Soft Skills e Referências. Candidatos Elite aparecem no topo das buscas das empresas.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">Como funcionam os testes técnicos? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        Na aba "Avaliação Técnica", você escolhe uma trilha (ex: Python, ML, NLP). Os testes são práticos e cronometrados. Seu código é avaliado por nossa IA para gerar seu score de Hard Skills.
                    </div>
                </div>
            </div>

            <div class="faq-section">
                <h2><i class="fas fa-building"></i> Empresas</h2>

                <div class="faq-item">
                    <div class="faq-question">Como cadastrar e publicar uma vaga? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        Acesse "Gestão de Vagas" e clique em "Salvar Vaga". Você ganha 1 vaga gratuita por mês. Para vagas extras ou impulsionadas, o pagamento é processado via Mercado Pago.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">Como encontrar os melhores talentos? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        No "Banco de Talentos", você tem acesso a todos os profissionais. Use filtros de área, nível e localização. Priorize candidatos com selo Elite e alto Score IA.
                    </div>
                </div>
            </div>

            <div class="faq-section">
                <h2><i class="fas fa-robot"></i> Inteligência Artificial</h2>

                <div class="faq-item">
                    <div class="faq-question">Como funciona o Matching IA? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        Nossa IA analisa semanticamente o perfil do candidato contra a descrição da vaga, gerando uma porcentagem de compatibilidade real, indo além de simples palavras-chave.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">O que é a Entrevista com IA? <i class="fas fa-chevron-down"></i></div>
                    <div class="faq-answer">
                        É um simulador onde nossa IA atua como um recrutador técnico. Ela faz perguntas baseadas no seu perfil e na vaga desejada, avaliando suas respostas e dando feedback imediato para você se preparar para entrevistas reais.
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        document.querySelectorAll('.faq-question').forEach(q => {
            q.addEventListener('click', () => {
                const item = q.parentElement;
                item.classList.toggle('active');
            });
        });
    </script>
</body>
</html>
