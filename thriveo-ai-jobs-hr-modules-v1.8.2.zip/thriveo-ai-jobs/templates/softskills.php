<?php
/**
 * D3 Soft Skills Assessment Template (DISC)
 */

if (!defined('ABSPATH')) {
    exit;
}

$candidato_id = isset($_SESSION['thriveo_candidato_id']) ? $_SESSION['thriveo_candidato_id'] : null;

if (!$candidato_id): ?>
    <!DOCTYPE html>
    <html lang="pt-BR">

    <head>
        <meta charset="UTF-8">
        <title>Sincronizando Sessão... | Thriveo</title>
        <style>
            body {
                font-family: sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                background: #f8fafc;
                color: #1e293b;
            }

            .sync-box {
                text-align: center;
            }

            .spinner {
                border: 4px solid rgba(0, 0, 0, 0.1);
                width: 36px;
                height: 36px;
                border-radius: 50%;
                border-left-color: #1a2e4a;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            }

            @keyframes spin {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }
        </style>
    </head>

    <body>
        <div class="sync-box">
            <div class="spinner"></div>
            <p>Validando suas credenciais...</p>
        </div>
        <script>
            const token = localStorage.getItem('thriveo_token');
            if (!token) {
                window.location.href = '<?php echo home_url(); ?>';
            } else {
                fetch('<?php echo admin_url('admin-ajax.php?action=thriveo_sync_session'); ?>', {
                    headers: { 'Authorization': 'Bearer ' + token }
                })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            window.location.reload();
                        } else {
                            window.location.href = '<?php echo home_url(); ?>';
                        }
                    })
                    .catch(() => {
                        window.location.href = '<?php echo home_url(); ?>';
                    });
            }
        </script>
    </body>

    </html>
    <?php
    exit;
endif;

$soft_ctrl = new Thriveo_AI_Jobs_Soft_Skills_Controller();

// For simple demo, using DISC
$tipo = 'DISC';
$avaliacao_id = $soft_ctrl->iniciar_avaliacao($candidato_id, $tipo);

$perguntas = [
    1 => "Como você prefere lidar com novos desafios?",
    2 => "Em uma discussão em equipe, você costuma:",
    3 => "Seu ambiente de trabalho ideal possui:",
    4 => "Ao tomar uma decisão importante, você prioriza:",
    5 => "Como você reage a mudanças repentinas no projeto?",
    6 => "Sua forma preferida de comunicação é:",
    7 => "Ao organizar suas tarefas, você prefere:",
    8 => "Em momentos de pressão extrema, você tende a:",
    9 => "Como você prefere receber feedback?",
    10 => "Qual seu papel natural em uma nova equipe?"
];

$opcoes = [
    'D' => "Focar no resultado e agir com rapidez.",
    'I' => "Engajar as pessoas e manter o clima positivo.",
    'S' => "Garantir a estabilidade e o planejamento.",
    'C' => "Analisar os fatos e seguir os processos."
];

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliação Comportamental | Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <style>
        :root {
            --primary: #0052cc;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg);
            color: var(--text-main);
            line-height: 1.6;
        }

        .navbar {
            height: 70px;
            background: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 100;
        }

        .logo {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--primary);
            letter-spacing: -0.02em;
        }

        .assessment-container {
            max-width: 800px;
            margin: 120px auto 100px;
            padding: 0 20px;
        }

        .progress-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        .progress-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #e2e8f0;
            transition: 0.3s;
        }

        .progress-dot.active {
            background: var(--primary);
            transform: scale(1.2);
        }

        .progress-dot.completed {
            background: var(--primary);
            opacity: 0.5;
        }

        .question-card {
            background: white;
            border-radius: 24px;
            padding: 40px;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.02);
        }

        .question-text {
            font-family: 'Barlow', sans-serif;
            font-size: 1.6rem;
            margin-bottom: 30px;
            font-weight: 700;
            text-align: center;
        }

        .options-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .option {
            padding: 25px;
            border: 2px solid #f1f5f9;
            border-radius: 16px;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .option:hover {
            border-color: var(--primary);
            background: rgba(124, 58, 237, 0.05);
        }

        .option.selected {
            border-color: var(--primary);
            background: rgba(124, 58, 237, 0.1);
        }

        .option-bullet {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 2px solid #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }

        .option.selected .option-bullet {
            border-color: var(--primary);
            background: var(--primary);
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            height: 80px;
            background: white;
            border-top: 1px solid #e2e8f0;
            padding: 0 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-prev {
            background: transparent;
            color: var(--text-muted);
        }

        .btn-next {
            background: var(--primary);
            color: white;
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
    </style>
</head>

<body>

    <nav class="navbar" style="justify-content: space-between; padding: 0 40px;">
        <div class="logo">Mapeamento <span style="font-weight:300; color:var(--text-main);">Soft Skills</span></div>
        <a href="?thriveo_faq=1" style="text-decoration:none; color:var(--primary); font-weight:700; font-size:0.9rem; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-question-circle"></i> FAQ / Ajuda
        </a>
    </nav>

    <div class="assessment-container">
        <div class="progress-indicator" id="progress-dots">
            <?php foreach ($perguntas as $i => $q): ?>
                <div class="progress-dot <?php echo $i === 1 ? 'active' : ''; ?>"></div>
            <?php endforeach; ?>
        </div>

        <div class="question-card" id="question-area">
            <!-- Questions injected by JS -->
        </div>
    </div>

    <div class="footer">
        <button class="btn btn-prev" onclick="prev()" id="btn-prev" disabled>Anterior</button>
        <div style="font-weight:600; font-size:0.9rem; color:var(--text-muted);" id="q-counter">Questão 1 de
            <?php echo count($perguntas); ?>
        </div>
        <button class="btn btn-next" onclick="next()" id="btn-next">Próxima</button>
    </div>

    <script>
        const questions = <?php echo json_encode($perguntas); ?>;
        const options = <?php echo json_encode($opcoes); ?>;
        const answers = {};
        let currentIdx = 1;

        function renderQuestion(idx) {
            const text = questions[idx];
            let html = `<h2 class="question-text">${text}</h2><div class="options-list">`;

            Object.entries(options).forEach(([key, val]) => {
                const isSelected = answers[idx] === key;
                html += `
                    <div class="option ${isSelected ? 'selected' : ''}" onclick="select('${key}')">
                        <div class="option-bullet"></div>
                        <span style="font-weight:500;">${val}</span>
                    </div>
                `;
            });

            html += `</div>`;
            $('#question-area').hide().html(html).fadeIn(300);

            // UI Updates
            $('#q-counter').text(`Questão ${idx} de ${Object.keys(questions).length}`);
            $('#btn-prev').prop('disabled', idx === 1);
            if (idx === Object.keys(questions).length) {
                $('#btn-next').text('Finalizar Avaliação');
            } else {
                $('#btn-next').text('Próxima');
            }

            // Sync dots
            $('#progress-dots .progress-dot').removeClass('active completed');
            $('#progress-dots .progress-dot').each((i, el) => {
                if (i + 1 === idx) $(el).addClass('active');
                else if (i + 1 < idx) $(el).addClass('completed');
            });
        }

        function select(key) {
            answers[currentIdx] = key;
            renderQuestion(currentIdx);
        }

        function next() {
            if (!answers[currentIdx]) {
                alert("Por favor, selecione uma opção.");
                return;
            }
            if (currentIdx < Object.keys(questions).length) {
                currentIdx++;
                renderQuestion(currentIdx);
            } else {
                finalizar();
            }
        }

        function prev() {
            if (currentIdx > 1) {
                currentIdx--;
                renderQuestion(currentIdx);
            }
        }

        function finalizar() {
            if (confirm("Avaliação concluída! Deseja ver seu perfil?")) {
                $.post('', { action: 'finalizar_disc', avaliacao_id: <?php echo $avaliacao_id; ?>, respostas: answers }, (res) => {
                    window.location.href = '?thriveo_certificacoes=1';
                });
            }
        }

        $(document).ready(() => {
            renderQuestion(1);
        });
    </script>
</body>

</html>