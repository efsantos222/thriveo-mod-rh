<?php
/**
 * Public Certificate Verification Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$codigo = isset($_GET['thriveo_verificar']) ? sanitize_text_field($_GET['thriveo_verificar']) : '';

$cert_ctrl = new Thriveo_AI_Jobs_Certificado_Controller();
$cert = $cert_ctrl->verificar_certificado($codigo);

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Certificado | Thriveo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Barlow:wght@600;700&display=swap"
        rel="stylesheet">
    <style>
        :root {
            --primary: #1a2e4a;
            --secondary: #ff6b35;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text-main);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }

        .verification-card {
            background: var(--card-bg);
            border-radius: 30px;
            padding: 60px;
            max-width: 600px;
            width: 100%;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.05);
            text-align: center;
        }

        .logo {
            margin-bottom: 40px;
        }

        .result-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 30px;
        }

        .icon-valid {
            background: #dcfce7;
            color: #166534;
        }

        .icon-invalid {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-title {
            font-family: 'Barlow', sans-serif;
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .status-desc {
            color: var(--text-muted);
            margin-bottom: 40px;
        }

        .cert-details {
            background: #f1f5f9;
            padding: 30px;
            border-radius: 20px;
            text-align: left;
            margin-bottom: 40px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            color: var(--text-muted);
            font-size: 0.85rem;
            font-weight: 500;
        }

        .detail-val {
            font-weight: 600;
            font-size: 1rem;
        }

        .btn-home {
            display: inline-block;
            padding: 14px 30px;
            background: var(--primary);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-home:hover {
            opacity: 0.9;
        }
    </style>
</head>

<body>

    <div class="verification-card">
        <div class="logo">
            <img src="http://thriveo.com.br/wp-content/uploads/2026/03/logo_thriveo_75.png" alt="Thriveo"
                style="width: 140px; height: auto;">
        </div>

        <?php if ($cert): ?>
            <div class="result-icon icon-valid"><i class="fas fa-check-circle"></i></div>
            <h2 class="status-title">Certificado Autêntico</h2>
            <p class="status-desc">Este certificado foi validado com sucesso pela plataforma Thriveo.</p>

            <div class="cert-details">
                <div class="detail-row"><span class="detail-label">Candidato</span><span class="detail-val">
                        <?php echo $cert->candidato_name; ?>
                    </span></div>
                <div class="detail-row"><span class="detail-label">Certificação</span><span class="detail-val">
                        <?php echo $cert->subtipo; ?>
                    </span></div>
                <div class="detail-row"><span class="detail-label">Data de Emissão</span><span class="detail-val">
                        <?php echo date('d/m/Y', strtotime($cert->concedido_em)); ?>
                    </span></div>
                <div class="detail-row"><span class="detail-label">Score Obtido</span><span class="detail-val">
                        <?php echo (int) $cert->score; ?>%
                    </span></div>
                <div class="detail-row"><span class="detail-label">Status</span><span class="detail-val"
                        style="color:#166534;">Ativo</span></div>
            </div>
        <?php else: ?>
            <div class="result-icon icon-invalid"><i class="fas fa-times-circle"></i></div>
            <h2 class="status-title">Certificado Inválido</h2>
            <p class="status-desc">O código informado não corresponde a um certificado válido em nossa base de dados.</p>
        <?php endif; ?>

        <a href="<?php echo home_url(); ?>" class="btn-home">Voltar para a Home</a>
    </div>

</body>

</html>