<?php
/**
 * Run DB updates
 */
define('WP_USE_THEMES', false);
require_once('../../../../wp-load.php'); // Path to WP root

require_once('includes/class-db-schema.php');
Thriveo_AI_Jobs_DB_Schema::create_tables();

echo "As tabelas do banco de dados foram criadas/atualizadas com sucesso!";
