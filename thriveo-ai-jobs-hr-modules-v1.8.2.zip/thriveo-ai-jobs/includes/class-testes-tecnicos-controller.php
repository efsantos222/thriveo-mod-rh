<?php
/**
 * D2 Hard Skills Testing Controller
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Testes_Tecnicos_Controller
{

    private $table_questoes;
    private $table_sessoes;

    public function __construct()
    {
        global $wpdb;
        $this->table_questoes = $wpdb->prefix . 'thriveo_questoes_tecnicas';
        $this->table_sessoes = $wpdb->prefix . 'thriveo_sessoes_teste';
    }

    /**
     * Start a new test session
     */
    public function iniciar_teste($candidato_id, $trilha, $nivel)
    {
        global $wpdb;

        // Verify if session already exists for this test level
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_sessoes} WHERE candidato_id = %d AND trilha = %s AND nivel = %s AND status = 'em_andamento'",
            $candidato_id,
            $trilha,
            $nivel
        ));

        if ($existing)
            return $existing;

        // Get questions for this track and level
        $questoes = $wpdb->get_results($wpdb->prepare(
            "SELECT id, enunciado, tipo, codigo_base, alternativas_json, resposta_correta, explicacao, dificuldade 
             FROM {$this->table_questoes} WHERE trilha = %s AND nivel = %s AND ativa = 1 ORDER BY RAND() LIMIT 20",
            $trilha,
            $nivel
        ));

        // If not enough questions, generate via IA
        if (count($questoes) < 20) {
            $needed = 20 - count($questoes);
            $novas = $this->gerar_questoes_ia($trilha, $nivel, $needed);
            if (!is_wp_error($novas)) {
                // Refresh list
                $questoes = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, enunciado, tipo, codigo_base, alternativas_json, resposta_correta, explicacao, dificuldade 
                     FROM {$this->table_questoes} WHERE trilha = %s AND nivel = %s AND ativa = 1 ORDER BY RAND() LIMIT 20",
                    $trilha,
                    $nivel
                ));
            }
        }

        if (count($questoes) < 20)
            return false;

        $sessao_id = $wpdb->insert($this->table_sessoes, [
            'candidato_id' => $candidato_id,
            'trilha' => $trilha,
            'nivel' => $nivel,
            'status' => 'em_andamento',
            'questoes_json' => json_encode($questoes),
            'respostas_json' => '{}',
            'tempo_inicio' => current_time('mysql'),
            'tempo_limite_min' => ($nivel === 'avancado' ? 60 : ($nivel === 'intermediario' ? 45 : 30)),
            'ip_candidato' => $_SERVER['REMOTE_ADDR']
        ]);

        return $wpdb->insert_id;
    }

    /**
     * Submit an answer for a question
     */
    public function salvar_resposta($sessao_id, $questao_id, $resposta)
    {
        global $wpdb;
        $sessao = $wpdb->get_row($wpdb->prepare("SELECT respostas_json FROM {$this->table_sessoes} WHERE id = %d", $sessao_id));
        if (!$sessao)
            return false;

        $respostas = json_decode($sessao->respostas_json, true);
        $respostas[$questao_id] = $resposta;

        $wpdb->update($this->table_sessoes, [
            'respostas_json' => json_encode($respostas)
        ], ['id' => $sessao_id]);

        return true;
    }

    /**
     * Finish and correct the test
     */
    public function finalizar_teste($sessao_id)
    {
        global $wpdb;
        $sessao = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_sessoes} WHERE id = %d", $sessao_id));
        if (!$sessao)
            return false;

        $questoes = json_decode($sessao->questoes_json, true);
        $respostas = json_decode($sessao->respostas_json, true);

        $corretas = 0;
        foreach ($questoes as $q) {
            if (isset($respostas[$q['id']]) && $respostas[$q['id']] === $q['resposta_correta']) {
                $corretas++;
                // Update stats
                $wpdb->query($wpdb->prepare("UPDATE {$this->table_questoes} SET vezes_usada = vezes_usada + 1 WHERE id = %d", $q['id']));
            }
        }

        $score = ($corretas / count($questoes)) * 100;
        $min_score = ($sessao->nivel === 'avancado' ? 80 : ($sessao->nivel === 'intermediario' ? 75 : 70));
        $aprovado = ($score >= $min_score);

        $wpdb->update($this->table_sessoes, [
            'status' => 'concluida',
            'score_obtido' => $score,
            'aprovado' => $aprovado ? 1 : 0,
            'tempo_fim' => current_time('mysql')
        ], ['id' => $sessao_id]);

        if ($aprovado) {
            $cert_ctrl = new Thriveo_AI_Jobs_Certificacao_Controller();
            $cert_ctrl->conceder_selo($sessao->candidato_id, 'D2', strtoupper($sessao->trilha . '_' . $sessao->nivel), $score);
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}thriveo_ai_candidates SET selo_d2 = 1 WHERE id = %d", $sessao->candidato_id));
        }

        return [
            'score' => $score,
            'aprovado' => $aprovado,
            'corretas' => $corretas,
            'total' => count($questoes)
        ];
    }

    /**
     * Internal: Use AI to populate questions table
     */
    private function gerar_questoes_ia($trilha, $nivel, $quantidade)
    {
        global $wpdb;
        $questoes = Thriveo_AI_Jobs_AI_Handler::gerar_questoes($trilha, $nivel, $quantidade);

        if (is_wp_error($questoes))
            return $questoes;

        foreach ($questoes as $q) {
            $wpdb->insert($this->table_questoes, [
                'trilha' => $trilha,
                'nivel' => $nivel,
                'topico' => $q['topico'] ?? 'Geral',
                'tipo' => $q['tipo'] ?? 'multipla_escolha',
                'enunciado' => $q['enunciado'],
                'codigo_base' => $q['codigo_base'] ?? '',
                'alternativas_json' => json_encode($q['alternativas']),
                'resposta_correta' => $q['resposta_correta'],
                'explicacao' => $q['explicacao'] ?? '',
                'dificuldade' => ($nivel === 'avancado' ? 3 : ($nivel === 'intermediario' ? 2 : 1)),
                'ativa' => 1
            ]);
        }

        return true;
    }
}
