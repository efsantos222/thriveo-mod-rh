<?php
/**
 * D3 Soft Skills Controller
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Soft_Skills_Controller
{

    private $table_soft;

    public function __construct()
    {
        global $wpdb;
        $this->table_soft = $wpdb->prefix . 'thriveo_avaliacoes_softskills';
    }

    /**
     * Start a new soft skill assessment
     */
    public function iniciar_avaliacao($candidato_id, $tipo)
    {
        global $wpdb;

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_soft} WHERE candidato_id = %d AND tipo = %s AND status = 'iniciada'",
            $candidato_id,
            $tipo
        ));

        if ($existing)
            return $existing;

        $wpdb->insert($this->table_soft, [
            'candidato_id' => $candidato_id,
            'tipo' => $tipo,
            'status' => 'iniciada',
            'respostas_json' => '{}',
            'resultado_json' => '{}'
        ]);

        return $wpdb->insert_id;
    }

    /**
     * Save answers for an assessment
     */
    public function salvar_respostas($avaliacao_id, $respostas)
    {
        global $wpdb;
        return $wpdb->update($this->table_soft, [
            'respostas_json' => json_encode($respostas)
        ], ['id' => $avaliacao_id]);
    }

    /**
     * Calculate results for DISC
     */
    public function finalizar_disc($avaliacao_id)
    {
        global $wpdb;
        $avaliacao = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_soft} WHERE id = %d", $avaliacao_id));
        if (!$avaliacao)
            return false;

        $respostas = json_decode($avaliacao->respostas_json, true);

        // Mocking DISC calculation for now
        $scores = ['D' => 0, 'I' => 0, 'S' => 0, 'C' => 0];
        foreach ($respostas as $resp) {
            // Simplified: in a real case, each option maps to a trait
            $traits = array_keys($scores);
            $trait = $traits[array_rand($traits)];
            $scores[$trait] += (int) $resp;
        }

        arsort($scores);
        $perfil_predominante = array_key_first($scores);

        $wpdb->update($this->table_soft, [
            'status' => 'concluida',
            'resultado_json' => json_encode($scores),
            'perfil_predominante' => $perfil_predominante,
            'concluido_em' => current_time('mysql'),
            'score_geral' => 100 // Hard skills are mandatory, soft skills just map profile
        ], ['id' => $avaliacao_id]);

        $cert_ctrl = new Thriveo_AI_Jobs_Certificacao_Controller();
        $cert_ctrl->conceder_selo($avaliacao->candidato_id, 'D3', 'DISC', 100);
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}thriveo_ai_candidates SET selo_d3 = 1 WHERE id = %d", $avaliacao->candidato_id));

        return [
            'perfil' => $perfil_predominante,
            'scores' => $scores
        ];
    }
}
