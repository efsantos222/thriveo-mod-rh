<?php
/**
 * Modulo DISC Handler
 */

if (!defined('ABSPATH')) exit;

class Thriveo_AI_DISC_Handler
{
    public static function get_questions()
    {
        return [
            1 => [
                'q' => 'Em uma situação de trabalho, eu geralmente sou...',
                'options' => [
                    'D' => 'Direto e decisivo',
                    'I' => 'Interativo e amigável',
                    'S' => 'Estável e paciente',
                    'C' => 'Cauteloso e preciso'
                ]
            ],
            2 => [
                'q' => 'Quando lido com problemas, eu...',
                'options' => [
                    'D' => 'Tomo ação imediata',
                    'I' => 'Envolvo outras pessoas',
                    'S' => 'Mantenho a calma',
                    'C' => 'Analiso cuidadosamente'
                ]
            ],
            3 => [
                'q' => 'Em grupo, eu tendo a...',
                'options' => [
                    'D' => 'Liderar e dirigir',
                    'I' => 'Socializar e motivar',
                    'S' => 'Apoiar e harmonizar',
                    'C' => 'Planejar e organizar'
                ]
            ],
            4 => [
                'q' => 'Sob pressão, eu posso me tornar...',
                'options' => [
                    'D' => 'Impaciente e dominante',
                    'I' => 'Impulsivo e expressivo',
                    'S' => 'Resistente a mudanças',
                    'C' => 'Crítico e detalhista'
                ]
            ],
            5 => [
                'q' => 'Minhas decisões são baseadas em...',
                'options' => [
                    'D' => 'Resultados',
                    'I' => 'Relacionamentos',
                    'S' => 'Consenso',
                    'C' => 'Dados e fatos'
                ]
            ],
            // ... truncated for brevity in this first batch, I will add more in the template logic
        ];
    }

    public static function calculate_profile($answers)
    {
        $scores = ['D' => 0, 'I' => 0, 'S' => 0, 'C' => 0];
        foreach ($answers as $ans) {
            if (isset($scores[$ans])) {
                $scores[$ans]++;
            }
        }

        $total = array_sum($scores);
        $percentages = [];
        foreach ($scores as $k => $v) {
            $percentages[$k] = $total > 0 ? round(($v / $total) * 100) : 0;
        }

        arsort($percentages);
        $predominant = key($percentages);

        return [
            'scores' => $percentages,
            'predominant' => $predominant,
            'label' => self::get_label($predominant)
        ];
    }

    public static function get_label($type)
    {
        $labels = [
            'D' => 'Dominância',
            'I' => 'Influência',
            'S' => 'Estabilidade',
            'C' => 'Conformidade'
        ];
        return $labels[$type] ?? 'Desconhecido';
    }
}
