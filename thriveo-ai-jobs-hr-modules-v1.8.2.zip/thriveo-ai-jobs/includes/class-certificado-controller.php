<?php
/**
 * Certificado Controller - PDF Generation & Public Verification
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Certificado_Controller
{

    private $table_cert;
    private $table_candidates;

    public function __construct()
    {
        global $wpdb;
        $this->table_cert = $wpdb->prefix . 'thriveo_certificacoes';
        $this->table_candidates = $wpdb->prefix . 'thriveo_ai_candidates';
    }

    /**
     * Public verification endpoint
     */
    public function verificar_certificado($codigo)
    {
        global $wpdb;
        $cert = $wpdb->get_row($wpdb->prepare("SELECT c.*, cand.name as candidato_name FROM {$this->table_cert} c JOIN {$this->table_candidates} cand ON c.candidato_id = cand.id WHERE c.codigo_verificacao = %s", $codigo));
        if (!$cert)
            return false;

        // Log the verification
        $wpdb->insert($wpdb->prefix . 'thriveo_log_verificacoes', [
            'codigo_verificacao' => $codigo,
            'ip_consultor' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT']
        ]);

        return $cert;
    }

    /**
     * Generate PDF (Mock logic, requires TCPDF/FPDF)
     */
    public function gerar_pdf($cert_id)
    {
        global $wpdb;
        $cert = $wpdb->get_row($wpdb->prepare("SELECT c.*, cand.name as candidato_name FROM {$this->table_cert} c JOIN {$this->table_candidates} cand ON c.candidato_id = cand.id WHERE c.id = %d", $cert_id));
        if (!$cert)
            return false;

        // In a real scenario, use TCPDF to generate and save the PDF
        $fileName = 'certificado_' . $cert->codigo_verificacao . '.pdf';
        $uploadDir = wp_upload_dir();
        $filePath = $uploadDir['basedir'] . '/thriveo-certificados/' . $fileName;
        $fileUrl = $uploadDir['baseurl'] . '/thriveo-certificados/' . $fileName;

        if (!file_exists($uploadDir['basedir'] . '/thriveo-certificados/')) {
            mkdir($uploadDir['basedir'] . '/thriveo-certificados/', 0755, true);
        }

        // Mock PDF file creation
        file_put_contents($filePath, "CERTIFICADO THRIVEO\nCandidato: " . $cert->candidato_name . "\nTrilha: " . $cert->subtipo . "\nCódigo: " . $cert->codigo_verificacao);

        $wpdb->update($this->table_cert, [
            'pdf_path' => $fileUrl
        ], ['id' => $cert_id]);

        return $fileUrl;
    }
}
