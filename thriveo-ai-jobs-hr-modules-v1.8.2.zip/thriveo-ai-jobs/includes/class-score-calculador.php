<?php
/**
 * Score Calculator for Thriveo Certification
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Score_Calculador
{

    /**
     * Calculates Dimension 1 - Profile Verified (D1)
     * Score 0-100
     */
    public static function calcular_score_d1($candidato)
    {
        $score = 0;

        // DADOS PESSOAIS (20 pontos)
        if (!empty($candidato->avatar) && !strpos($candidato->avatar, 'default'))
            $score += 5;
        if (!empty($candidato->name) && str_word_count($candidato->name) >= 2)
            $score += 5;
        if (!empty($candidato->cidade) && !empty($candidato->estado))
            $score += 5;
        if (!empty($candidato->email))
            $score += 5; // Simplified, assuming email is present if logged in

        // GITHUB (30 pontos)
        // Assume metadata_json or top_repos has these details
        $github_data = json_decode($candidato->top_repos ?? '{}', true);
        // Realistically, we'd need more specific fields from the OAuth handler's save process
        // For now, using what we have in the candidates table
        if ($candidato->public_repos >= 5)
            $score += 10;
        // Mocking some criteria for now as they aren't explicit columns yet
        // In a real scenario, we'd store these during OAuth
        $created_at = strtotime($candidato->created_at);
        if (time() - $created_at > (180 * 24 * 60 * 60))
            $score += 10;

        // LINKEDIN (30 pontos)
        // Assuming we have some LinkedIn data stored
        if (!empty($candidato->profile_url))
            $score += 5;
        if (!empty($candidato->bio) && strlen($candidato->bio) >= 100)
            $score += 5;

        // CONSISTÊNCIA (20 pontos)
        // To be implemented with real comparison logic

        return min(100, $score);
    }

    /**
     * Calculates the overall Elite score
     */
    public static function calcular_score_elite($candidato_id)
    {
        global $wpdb;
        $table_cert = $wpdb->prefix . 'thriveo_certificacoes';

        $certs = $wpdb->get_results($wpdb->prepare(
            "SELECT tipo, score FROM $table_cert WHERE candidato_id = %d AND status = 'ativo'",
            $candidato_id
        ));

        if (count($certs) < 4)
            return 0;

        $total_score = 0;
        foreach ($certs as $cert) {
            $total_score += $cert->score;
        }

        return $total_score / count($certs);
    }
}
