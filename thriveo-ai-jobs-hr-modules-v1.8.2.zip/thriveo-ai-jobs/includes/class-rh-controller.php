<?php
/**
 * RH Modules Controller (DISC, ZBB, PDI)
 * Handles trials, user limits and module integration.
 */

if (!defined('ABSPATH')) exit;

class Thriveo_RH_Controller
{
    public static function init()
    {
        // Enforce trial check on RH module access
        add_action('template_redirect', [__CLASS__, 'check_access_permissions']);
    }

    /**
     * Check if the current company (employer) can access RH modules
     */
    public static function check_access_permissions()
    {
        if (!isset($_GET['tab']) || !in_array($_GET['tab'], ['disc', 'zbb', 'pdi'])) {
            return;
        }

        $user_id = get_current_user_id();
        if (!$user_id) return;

        global $wpdb;
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}thriveo_ai_companies WHERE wp_user_id = %d",
            $user_id
        ));

        if (!$company && !current_user_can('manage_options')) {
            wp_die('Empresa não encontrada.');
        }

        // System Administrators always have access
        if (current_user_can('manage_options')) return;

        // Trial Check
        if (!$company->is_paying) {
            $trial_end = strtotime($company->trial_ends_at);
            if (time() > $trial_end) {
                wp_die('Seu período de teste de 30 dias expirou. Por favor, adquira um pacote para continuar utilizando os módulos de RH.');
            }
        }
    }

    /**
     * Get current user count for a company
     */
    public static function get_company_user_count($empresa_id)
    {
        global $wpdb;
        // Assuming we count entries in thriveo_plataforma_usuarios linked to this company
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}thriveo_plataforma_usuarios WHERE empresa_id = %d",
            $empresa_id
        ));
    }

    /**
     * Check if company can add more users
     */
    public static function can_add_user($empresa_id)
    {
        global $wpdb;
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT max_users FROM {$wpdb->prefix}thriveo_ai_companies WHERE id = %d",
            $empresa_id
        ));

        if (!$company) return false;

        $current_count = self::get_company_user_count($empresa_id);
        return $current_count < $company->max_users;
    }
}
