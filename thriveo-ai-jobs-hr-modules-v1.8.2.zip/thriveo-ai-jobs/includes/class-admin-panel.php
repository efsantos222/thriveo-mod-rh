<?php
/**
 * Admin Panel for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Admin_Panel
{

    public static function init()
    {
        add_action('admin_menu', [__CLASS__, 'add_admin_menu']);
    }

    public static function add_admin_menu()
    {
        add_menu_page(
            'Thriveo AI Jobs',
            'Thriveo IA',
            'thriveo_manage_ai',
            'thriveo-ai-jobs',
            [__CLASS__, 'render_admin_page'],
            'dashicons-groups',
            30
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Candidatos (IA)',
            'Candidatos',
            'thriveo_manage_ai',
            'thriveo-ai-candidates',
            [__CLASS__, 'render_candidates_page']
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Empresas / Vagas',
            'Empresas & Vagas',
            'thriveo_manage_ai',
            'thriveo-ai-companies',
            [__CLASS__, 'render_companies_page']
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Gerenciar Trilhas',
            'Gerenciar Trilhas',
            'thriveo_manage_ai',
            'thriveo-ai-trilhas',
            [__CLASS__, 'render_trilhas_management_page']
        );

        add_submenu_page(
            'thriveo-ai-jobs', // Parent slug should be 'thriveo-ai-jobs' to appear under the main menu
            'Gerador de Conteúdo IA', // Keep original page title
            'Gerador IA',
            'thriveo_manage_ai',
            'thriveo-ai-generator',
            [__CLASS__, 'render_generator_page']
        );

        add_submenu_page(
            'thriveo-ai-jobs',
            'Configurações IA',
            'Configurações IA',
            'thriveo_manage_ai',
            'thriveo-ai-settings',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function render_generator_page()
    {
        $result = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && wp_verify_nonce($_POST['_wpnonce'], 'thriveo_generate')) {
            $type = sanitize_text_field($_POST['content_type'] ?? '');
            $topic = sanitize_text_field($_POST['topic'] ?? '');
            
            $prompt = "";
            switch($type) {
                case 'roadmap':
                    $prompt = "Crie um roteiro (roadmap) profissional para alguém que deseja se tornar especialista em '{$topic}' focado em Inteligência Artificial. Divida em níveis Básico, Intermediário e Avançado.";
                    break;
                case 'questions':
                    $prompt = "Gere 3 questões técnicas de múltipla escolha sobre '{$topic}' com respostas comentadas.";
                    break;
                default:
                    $prompt = "Escreva um parágrafo profissional sobre as tendências de '{$topic}' no mercado de IA.";
            }

            $ai_result = Thriveo_AI_Jobs_AI_Handler::call_openai($prompt);
            
            // Limpeza de Markdown (### e **)
            $ai_result = str_replace(['#', '*', '`'], '', $ai_result);
            
            $result = is_wp_error($ai_result) ? $ai_result->get_error_message() : $ai_result;

            // NEW: If it's a roadmap, save it to the actual Trilhas table
            if (!is_wp_error($ai_result) && $type === 'roadmap') {
                $image_url = '';
                if (isset($_POST['generate_image'])) {
                    $image_url = Thriveo_AI_Jobs_AI_Handler::generate_image($topic);
                }

                global $wpdb;
                $wpdb->insert($wpdb->prefix . 'thriveo_trilhas', [
                    'titulo' => 'Roteiro: ' . $topic,
                    'conteudo' => $ai_result,
                    'image_url' => $image_url,
                    'nivel' => 'iniciante',
                    'ativa' => 1
                ]);
                $result .= "\n\n✅ SUCESSO: Esta trilha foi salva e já está disponível para os candidatos em /?thriveo_trilhas=1";
                if ($image_url) {
                    $result .= "\n🖼️ Imagem gerada com sucesso!";
                }
            }
        }

        ?>
        <div class="wrap">
            <h1>Gerador de Conteúdo IA (Administrador)</h1>
            <p>Utilize o poder da GPT-4o para criar conteúdos rápidos para a plataforma.</p>

            <div class="card" style="padding:24px; background:#fff; border-radius:12px; max-width:800px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
                <form method="post" id="thriveo-gen-form">
                    <?php wp_nonce_field('thriveo_generate'); ?>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; margin-bottom:8px; font-weight:600;">O que você deseja gerar?</label>
                        <select name="content_type" style="width:100%; padding:8px;">
                            <option value="roadmap" <?php selected($type ?? '', 'roadmap'); ?>>Roteiro de Trilha (Roadmap IA)</option>
                            <option value="questions" <?php selected($type ?? '', 'questions'); ?>>Draft de Questões Técnicas</option>
                            <option value="insight" <?php selected($type ?? '', 'insight'); ?>>Insight de Tendências</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; margin-bottom:8px; font-weight:600;">Tópico/Tecnologia (Ex: Python, Machine Learning)</label>
                        <input type="text" name="topic" value="<?php echo esc_attr($topic ?? ''); ?>" required style="width:100%; padding:8px;" placeholder="Ex: Engenharia de Prompt">
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:flex; align-items:center; cursor:pointer;">
                            <input type="checkbox" name="generate_image" value="1" checked style="margin-right:10px;">
                            <span>Gerar Imagem Conceitual via AI (DALL-E 3)</span>
                        </label>
                    </div>

                    <button type="submit" name="generate_content" id="btn-submit-ia" class="button button-primary button-large" style="height:46px;">
                        <span class="dashicons dashicons-marker" style="margin-top:10px;"></span> 
                        <span id="btn-text-ia">Gerar com IA</span>
                    </button>
                </form>

                <script>
                    document.getElementById('thriveo-gen-form').onsubmit = function() {
                        const btn = document.getElementById('btn-submit-ia');
                        const text = document.getElementById('btn-text-ia');
                        btn.disabled = true;
                        text.innerText = 'Processando IA (Pode levar 20-30s)...';
                        btn.style.opacity = '0.7';
                    };
                </script>

                <?php if ($result): ?>
                    <div style="margin-top:30px; padding:20px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
                        <h3 style="margin-top:0;">Resultado da Geração:</h3>
                        <div style="white-space: pre-wrap; font-family: monospace; background:#fff; padding:15px; border-radius:6px; border:1px solid #eee;">
                            <?php echo esc_html($result); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public static function render_settings_page()
    {
        // Processar salvamento OpenAI
        if (isset($_POST['save_openai_key']) && wp_verify_nonce($_POST['_wpnonce'], 'save_thriveo_ai')) {
            $key = sanitize_text_field($_POST['openai_key']);
            Thriveo_AI_Jobs_AI_Handler::save_api_key($key);
            echo '<div class="notice notice-success is-dismissible"><p>Configurações OpenAI atualizadas.</p></div>';
        }

        // Processar salvamento Mercado Pago
        if (isset($_POST['save_mp_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'save_thriveo_mp')) {
            update_option('thriveo_mp_access_token', sanitize_text_field($_POST['mp_access_token']));
            update_option('thriveo_mp_public_key', sanitize_text_field($_POST['mp_public_key']));
            update_option('thriveo_mp_sandbox_access_token', sanitize_text_field($_POST['mp_sandbox_access_token']));
            update_option('thriveo_mp_sandbox_public_key', sanitize_text_field($_POST['mp_sandbox_public_key']));
            update_option('thriveo_mp_sandbox_mode', isset($_POST['mp_sandbox_mode']) ? 1 : 0);
            echo '<div class="notice notice-success is-dismissible"><p>Configurações Mercado Pago atualizadas com sucesso.</p></div>';
        }

        $current_openai_key = Thriveo_AI_Jobs_AI_Handler::get_api_key();
        $mp_access_token = get_option('thriveo_mp_access_token', '');
        $mp_public_key = get_option('thriveo_mp_public_key', '');
        $mp_sandbox_access_token = get_option('thriveo_mp_sandbox_access_token', 'APP_USR-227931852663399-031509-381b83217eb0aa63d710fc5a35eacb88-3268408628');
        $mp_sandbox_public_key = get_option('thriveo_mp_sandbox_public_key', 'APP_USR-ac5a0383-29d2-4ad3-a5f2-e87e5e78ef95');
        $mp_sandbox_mode = get_option('thriveo_mp_sandbox_mode', 1);

        ?>
        <div class="wrap">
            <h1>Configurações Thriveo <small style="font-size:12px; color:#999;">v1.5.1</small></h1>
            
            <!-- OpenAI Section -->
            <div class="card" style="padding:20px; margin-bottom:20px; max-width:800px; border-radius:8px;">
                <form method="post">
                    <?php wp_nonce_field('save_thriveo_ai'); ?>
                    <h2 style="margin-top:0;"><span class="dashicons dashicons-rest-api"></span> OpenAI Integration</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label>API Key</label></th>
                            <td>
                                <input type="password" name="openai_key" value="<?php echo esc_attr($current_openai_key); ?>" class="regular-text">
                                <p class="description">Utilizada para geração de trilhas e análise de candidatos.</p>
                            </td>
                        </tr>
                    </table>
                    <p><button type="submit" name="save_openai_key" class="button button-primary">Salvar OpenAI</button></p>
                </form>
            </div>

            <!-- Mercado Pago Section -->
            <div class="card" style="padding:20px; max-width:800px; border-radius:8px; margin-bottom: 20px;">
                <form method="post">
                    <?php wp_nonce_field('save_thriveo_mp'); ?>
                    <h2 style="margin-top:0;"><span class="dashicons dashicons-cart"></span> Mercado Pago Integration</h2>
                    <p>Configure o Access Token para ativação de faturamento Checkout Pro.</p>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Ambiente de Testes (Sandbox)</th>
                            <td>
                                <input type="checkbox" name="mp_sandbox_mode" value="1" <?php checked($mp_sandbox_mode, 1); ?>> Ativar Sandbox
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" style="background: #fdf2f2;">Sandbox: Access Token</th>
                            <td style="background: #fdf2f2;">
                                <input type="password" name="mp_sandbox_access_token" value="<?php echo esc_attr($mp_sandbox_access_token); ?>" class="regular-text" style="width:100%">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row" style="background: #fdf2f2;">Sandbox: Public Key</th>
                            <td style="background: #fdf2f2;">
                                <input type="text" name="mp_sandbox_public_key" value="<?php echo esc_attr($mp_sandbox_public_key); ?>" class="regular-text" style="width:100%">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">PRODUÇÃO: Access Token</th>
                            <td>
                                <input type="password" name="mp_access_token" value="<?php echo esc_attr($mp_access_token); ?>" class="regular-text" style="width:100%"><br>
                                <p class="description">Access Token oficial para cobranças reais.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">PRODUÇÃO: Public Key</th>
                            <td>
                                <input type="text" name="mp_public_key" value="<?php echo esc_attr($mp_public_key); ?>" class="regular-text" style="width:100%">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Webhook URL Notificações</th>
                            <td><code><?php echo home_url('/wp-json/thriveo/v1/mp-webhook'); ?></code></td>
                        </tr>
                    </table>
                    <p><button type="submit" name="save_mp_settings" class="button button-primary">Salvar Mercado Pago</button></p>
                </form>
            </div>

            <!-- Mercado Pago Test Tools -->
            <div class="card" style="padding:20px; max-width:800px; border-radius:8px;">
                <h2 style="margin-top:0;"><span class="dashicons dashicons-admin-tools"></span> Guia de Testes (Mercado Pago)</h2>
                <p>Use os dados abaixo para simular pagamentos no ambiente Sandbox.</p>
                
                <h3>💳 Cartões de Teste</h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Bandeira</th>
                            <th>Número</th>
                            <th>CVV</th>
                            <th>Vencimento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>Mastercard</td><td><code>5031 4332 1540 6351</code></td><td>123</td><td>11/30</td></tr>
                        <tr><td>Visa</td><td><code>4235 6477 2802 5682</code></td><td>123</td><td>11/30</td></tr>
                        <tr><td>Amex</td><td><code>3753 651535 56885</code></td><td>1234</td><td>11/30</td></tr>
                        <tr><td>Elo (Débito)</td><td><code>5067 7667 8388 8311</code></td><td>123</td><td>11/30</td></tr>
                    </tbody>
                </table>

                <h3 style="margin-top:20px;">🚦 Cenários de Resposta</h3>
                <p>Altere o <strong>Nome do Titular</strong> no checkout para forçar um status:</p>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Status Desejado</th>
                            <th>Nome do Titular</th>
                            <th>CPF (Dica)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td><span style="color:green;font-weight:bold;">Aprovado</span></td><td><code>APRO</code></td><td>12345678909</td></tr>
                        <tr><td>Pendente</td><td><code>CONT</code></td><td>-</td></tr>
                        <tr><td>Recusado (Geral)</td><td><code>OTHE</code></td><td>-</td></tr>
                        <tr><td>Saldo Insuficiente</td><td><code>FUND</code></td><td>-</td></tr>
                        <tr><td>Cartão Bloqueado</td><td><code>LOCK</code></td><td>-</td></tr>
                        <tr><td>Expirado</td><td><code>EXPI</code></td><td>-</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public static function render_admin_page()
    {
        ?>
        <div class="wrap">
            <h1>Painel Thriveo AI Jobs</h1>
            <p>Bem-vindo ao gerenciamento do talento de IA da Thriveo.</p>
            <p>Use os submenus para gerenciar candidatos, empresas (e seus status de pagamento).</p>
        </div>
        <?php
    }

    public static function render_candidates_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_candidates';
        $candidates = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC LIMIT 50");
        ?>
        <div class="wrap">
            <h1>Candidatos IA</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Provider</th>
                        <th>Autorizado Divulgação?</th>
                        <th>Repositórios Públicos</th>
                        <th>Data Cadastro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($candidates)): ?>
                        <tr>
                            <td colspan="7">Nenhum candidato encontrado.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($candidates as $c): ?>
                            <tr>
                                <td>#
                                    <?php echo esc_html($c->id); ?>
                                </td>
                                <td>
                                    <?php if ($c->avatar): ?><img src="<?php echo esc_url($c->avatar); ?>"
                                            style="width:24px;height:24px;border-radius:50%;vertical-align:middle;margin-right:8px;">
                                    <?php endif; ?>
                                    <strong>
                                        <?php echo esc_html($c->name); ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php echo esc_html($c->email); ?>
                                </td>
                                <td>
                                    <?php echo esc_html(ucfirst($c->provider)); ?>
                                </td>
                                <td>
                                    <?php echo $c->authorized_disclosure ? '<span style="color:green">Sim</span>' : '<span style="color:red">Não</span>'; ?>
                                </td>
                                <td>
                                    <?php echo esc_html($c->public_repos); ?>
                                </td>
                                <td>
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($c->created_at))); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function render_companies_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_ai_companies';

        // Handle basic action forms (Make paying / Not paying)
        if (isset($_POST['action']) && isset($_POST['company_id']) && current_user_can('manage_options') && wp_verify_nonce($_POST['_wpnonce'], 'toggle_company_status')) {
            $comp_id = intval($_POST['company_id']);
            $is_paying = $_POST['action'] === 'make_paying' ? 1 : 0;
            $wpdb->update($table, ['is_paying' => $is_paying], ['id' => $comp_id]);
            echo '<div class="notice notice-success is-dismissible"><p>Status da empresa atualizado.</p></div>';
        }

        $companies = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC");
        ?>
        <div class="wrap">
            <h1>Empresas</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>WP User ID</th>
                        <th>Nome da Empresa</th>
                        <th>Status Pagante?</th>
                        <th>Trial Expira</th>
                        <th>Limite Usuários</th>
                        <th>Data Cadastro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($companies)): ?>
                        <tr>
                            <td colspan="6">Nenhuma empresa encontrada. Obs: A criação de empresas será via Front-end/Dashboard de
                                Usuários WP.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($companies as $c): ?>
                            <tr>
                                <td>#
                                    <?php echo esc_html($c->id); ?>
                                </td>
                                <td>
                                    <?php echo esc_html($c->wp_user_id); ?>
                                </td>
                                <td><strong>
                                        <?php echo esc_html($c->company_name); ?>
                                    </strong></td>
                                <td>
                                    <?php echo $c->is_paying ? '<span style="color:green;font-weight:bold;">Sim (Premium)</span>' : '<span style="color:gray">Não</span>'; ?>
                                </td>
                                <td>
                                    <?php 
                                    if ($c->trial_ends_at) {
                                        $diff = strtotime($c->trial_ends_at) - time();
                                        $days = round($diff / (60 * 60 * 24));
                                        if ($days > 0) {
                                            echo "<span style='color:blue;'>RESTAM $days DIAS</span>";
                                        } else {
                                            echo "<span style='color:red;'>EXPIRADO</span>";
                                        }
                                    } else {
                                        echo "-";
                                    }
                                    ?>
                                </td>
                                <td><?php echo intval($c->max_users); ?></td>
                                <td>
                                    <?php echo esc_html(date('d/m/Y H:i', strtotime($c->created_at))); ?>
                                </td>
                                <td>
                                    <form method="post" style="display:inline-block;">
                                        <?php wp_nonce_field('toggle_company_status'); ?>
                                        <input type="hidden" name="company_id" value="<?php echo esc_attr($c->id); ?>">
                                        <?php if ($c->is_paying): ?>
                                            <input type="hidden" name="action" value="remove_paying">
                                            <button type="submit" class="button button-small">Remover Premium</button>
                                        <?php else: ?>
                                            <input type="hidden" name="action" value="make_paying">
                                            <button type="submit" class="button button-small button-primary">Tornar Premium</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <hr style="margin:2em 0;">

            <h2>Adicionar Empresa Manualmente</h2>
            <p>Para testes, você pode vincular um Usuário WordPress existente como uma Empresa.</p>
            <?php
            if (isset($_POST['add_company']) && isset($_POST['wp_user_id']) && current_user_can('manage_options') && wp_verify_nonce($_POST['_wpnonce'], 'add_thriveo_company')) {
                $wpdb->insert($table, [
                    'wp_user_id' => intval($_POST['wp_user_id']),
                    'company_name' => sanitize_text_field($_POST['company_name']),
                    'is_paying' => intval($_POST['is_paying']),
                    'trial_ends_at' => date('Y-m-d H:i:s', strtotime('+30 days')),
                    'max_users' => 5
                ]);
                echo '<meta http-equiv="refresh" content="0">';
            }
            ?>
            <form method="post" class="form-table">
                <?php wp_nonce_field('add_thriveo_company'); ?>
                <input type="hidden" name="add_company" value="1">
                <p>
                    <label>Selecionar Usuário WP (Que será o dono da empresa):</label><br>
                    <select name="wp_user_id" required style="max-width:300px;">
                        <option value="">--- Selecione um Usuário ---</option>
                        <?php
                        // Carregar usuários que podem ser empresas
                        $users = get_users();
                        foreach ($users as $u) {
                            echo '<option value="' . esc_attr($u->ID) . '">' . esc_html($u->user_login . ' (' . $u->user_email . ')') . '</option>';
                        }
                        ?>
                    </select>
                </p>
                <p>
                    <label>Nome Fantasia (Empresa):</label><br>
                    <input type="text" name="company_name" required>
                </p>
                <p>
                    <label>Plano Premium (Pagante)?</label><br>
                    <select name="is_paying">
                        <option value="0">Não</option>
                        <option value="1">Sim</option>
                    </select>
                </p>
                <p><button type="submit" class="button button-primary">Adicionar</button></p>
            </form>
        </div>
        <?php
    }

    public static function render_trilhas_management_page()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'thriveo_trilhas';
        $message = '';

        // Handle Delete
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
            check_admin_referer('delete_trilha_' . $_GET['id']);
            $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
            $message = 'Trilha excluída com sucesso.';
        }

        // Handle Update
        if (isset($_POST['update_trilha'])) {
            check_admin_referer('update_trilha_nonce');
            $id = intval($_POST['trilha_id']);
            $wpdb->update($table_name, [
                'titulo' => sanitize_text_field($_POST['titulo']),
                'conteudo' => wp_kses_post($_POST['conteudo']),
                'nivel' => sanitize_text_field($_POST['nivel'])
            ], ['id' => $id]);
            $message = 'Trilha atualizada com sucesso.';
        }

        // List or Edit
        $edit_id = isset($_GET['action']) && $_GET['action'] == 'edit' ? intval($_GET['id']) : 0;
        
        ?>
        <div class="wrap">
            <h1>Gestão de Trilhas IA</h1>
            <?php if ($message): ?>
                <div class="notice notice-success is-dismissible"><p><?php echo $message; ?></p></div>
            <?php endif; ?>

            <?php if ($edit_id): 
                $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $edit_id));
            ?>
                <div class="card" style="max-width:800px; padding:20px;">
                    <h2>Editar Trilha</h2>
                    <form method="post">
                        <?php wp_nonce_field('update_trilha_nonce'); ?>
                        <input type="hidden" name="trilha_id" value="<?php echo $item->id; ?>">
                        
                        <p><label>Título:</label><br>
                        <input type="text" name="titulo" value="<?php echo esc_attr($item->titulo); ?>" class="large-text"></p>
                        
                        <p><label>Conteúdo (Edite livremente):</label><br>
                        <textarea name="conteudo" rows="15" class="large-text"><?php echo esc_textarea($item->conteudo); ?></textarea></p>
                        
                        <p><label>Nível:</label><br>
                        <select name="nivel">
                            <option value="iniciante" <?php selected($item->nivel, 'iniciante'); ?>>Iniciante</option>
                            <option value="intermediario" <?php selected($item->nivel, 'intermediario'); ?>>Intermediário</option>
                            <option value="avancado" <?php selected($item->nivel, 'avancado'); ?>>Avançado</option>
                        </select></p>

                        <button type="submit" name="update_trilha" class="button button-primary">Salvar Alterações</button>
                        <a href="?page=thriveo-ai-trilhas" class="button">Cancelar</a>
                    </form>
                </div>
            <?php else: 
                $items = $wpdb->get_results("SELECT * FROM $table_name ORDER BY criado_em DESC");
            ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Nível</th>
                            <th>Data</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td><strong><?php echo esc_html($item->titulo); ?></strong></td>
                                <td><?php echo esc_html($item->nivel); ?></td>
                                <td><?php echo esc_html($item->criado_em); ?></td>
                                <td>
                                    <a href="?page=thriveo-ai-trilhas&action=edit&id=<?php echo $item->id; ?>" class="button">Editar</a>
                                    <a href="<?php echo wp_nonce_url("?page=thriveo-ai-trilhas&action=delete&id=$item->id", 'delete_trilha_' . $item->id); ?>" class="button" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                                    <a href="<?php echo home_url('/?thriveo_trilhas=1&trilha_id=' . $item->id); ?>" target="_blank" class="button">Ver no Site</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$items) echo '<tr><td colspan="4">Nenhuma trilha encontrada.</td></tr>'; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
}
