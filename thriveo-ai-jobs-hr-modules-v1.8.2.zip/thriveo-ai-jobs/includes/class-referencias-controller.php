<?php
/**
 * D4 Professional Reputation Controller
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Referencias_Controller
{

    private $table_refs;

    public function __construct()
    {
        global $wpdb;
        $this->table_refs = $wpdb->prefix . 'thriveo_referencias_profissionais';
    }

    /**
     * Request a professional reference
     */
    public function solicitar_referencia($candidato_id, $data)
    {
        global $wpdb;

        $token = wp_generate_password(32, false);
        $expira = date('Y-m-d H:i:s', strtotime('+7 days'));

        $wpdb->insert($this->table_refs, [
            'candidato_id' => $candidato_id,
            'nome_referente' => $data['nome'],
            'email_referente' => $data['email'],
            'cargo_referente' => $data['cargo'],
            'empresa_referente' => $data['empresa'],
            'tipo_relacao' => $data['tipo_relacao'],
            'periodo_inicio' => $data['periodo_inicio'],
            'token_resposta' => $token,
            'token_expira_em' => $expira,
            'status' => 'enviado',
            'criado_em' => current_time('mysql')
        ]);

        $this->enviar_email_convite($data['email'], $token, $data);

        return $wpdb->insert_id;
    }

    /**
     * Submit a reference response
     */
    public function salvar_resposta($token, $dados)
    {
        global $wpdb;
        $ref = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_refs} WHERE token_resposta = %s AND status = 'enviado'", $token));
        if (!$ref)
            return false;

        $scores = [
            'qualidade' => (int) $dados['qualidade'],
            'comunicacao' => (int) $dados['comunicacao'],
            'prazos' => (int) $dados['prazos'],
            'proatividade' => (int) $dados['proatividade'],
            'adaptabilidade' => (int) $dados['adaptabilidade']
        ];

        $media = array_sum($scores) / count($scores);
        $total_score = ($media / 5) * 100;

        $wpdb->update($this->table_refs, [
            'status' => 'respondido',
            'scores_json' => json_encode($scores),
            'recomendaria' => $dados['recomendaria'],
            'comentario' => $dados['comentario'],
            'respondido_em' => current_time('mysql'),
            'ip_referente' => $_SERVER['REMOTE_ADDR']
        ], ['id' => $ref->id]);

        $this->check_d4_badge($ref->candidato_id);

        return true;
    }

    /**
     * Check if D4 badge should be granted (Minimum 2 references)
     */
    private function check_d4_badge($candidato_id)
    {
        global $wpdb;
        $respondidas = $wpdb->get_results($wpdb->prepare(
            "SELECT scores_json, tipo_relacao FROM {$this->table_refs} WHERE candidato_id = %d AND status = 'respondido'",
            $candidato_id
        ));

        if (count($respondidas) >= 2) {
            $total_score = 0;
            foreach ($respondidas as $resp) {
                $scores = json_decode($resp->scores_json, true);
                $media = array_sum($scores) / count($scores);
                $total_score += ($media / 5) * 100;
            }
            $final_score = $total_score / count($respondidas);

            $cert_ctrl = new Thriveo_AI_Jobs_Certificacao_Controller();
            $cert_ctrl->conceder_selo($candidato_id, 'D4', 'Referências Verificadas', $final_score);
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}thriveo_ai_candidates SET selo_d4 = 1 WHERE id = %d", $candidato_id));
        }
    }

    private function enviar_email_convite($email, $token, $data)
    {
        // Mock email sending
        // In a real scenario, use wp_mail
    }
}
