<?php
/**
 * AI Handler for Thriveo AI Jobs using OpenAI
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_AI_Handler
{

    private static $option_name = 'thriveo_openai_api_key_secure';

    /**
     * Get the API Key (Prioritizes constant for maximum security, then DB)
     */
    public static function get_api_key()
    {
        if (defined('THRIVEO_OPENAI_KEY')) {
            return THRIVEO_OPENAI_KEY;
        }
        return get_option(self::$option_name, '');
    }

    /**
     * Save the API Key (Securely)
     */
    public static function save_api_key($key)
    {
        if (current_user_can('manage_options')) {
            update_option(self::$option_name, sanitize_text_field($key));
            return true;
        }
        return false;
    }

    /**
     * Generic call to OpenAI Chat Completion
     */
    public static function call_openai($prompt, $system_message = "Você é o núcleo de inteligência da Thriveo, especializado em Recrutamento e IA.")
    {
        $api_key = self::get_api_key();

        if (empty($api_key)) {
            return new WP_Error('missing_api_key', 'Chave API do OpenAI não configurada.');
        }

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => 'gpt-4o',
                'messages' => [
                    ['role' => 'system', 'content' => $system_message],
                    ['role' => 'user', 'content' => $prompt]
                ],
                'temperature' => 0.7,
            ]),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($body['error'])) {
            return new WP_Error('openai_error', $body['error']['message']);
        }

        return $body['choices'][0]['message']['content'] ?? '';
    }

    /**
     * Specialized: Generate technical questions
     */
    public static function gerar_questoes($trilha, $nivel, $quantidade = 5)
    {
        $prompt = "Gere {$quantidade} questões de múltipla escolha para a trilha técnica '{$trilha}' no nível '{$nivel}'.
        O retorno deve ser estritamente um array JSON válido no seguinte formato:
        [
          {
            'topico': 'Assunto',
            'tipo': 'multipla_escolha',
            'enunciado': 'Pergunta...',
            'codigo_base': 'Opcional código...',
            'alternativas': {'A': '...', 'B': '...', 'C': '...', 'D': '...'},
            'resposta_correta': 'A',
            'explicacao': 'Por que esta é a correta?'
          }
        ]";

        $result = self::call_openai($prompt, "Você é um avaliador técnico sênior da Thriveo.");

        if (is_wp_error($result))
            return $result;

        $json = json_decode(trim(str_replace(['```json', '```'], '', $result)), true);
        return is_array($json) ? $json : new WP_Error('invalid_json', 'Falha ao processar JSON da IA.');
    }

    /**
     * Generate an image using DALL-E 3
     */
    public static function generate_image($topic)
    {
        $api_key = self::get_api_key();

        if (empty($api_key)) {
            return '';
        }

        $prompt = "A high-tech, futuristic, professional digital art representation of '{$topic}' for a learning path thumbnail. IMPORTANT: Any text visible in the image must be in Brazilian Portuguese. Style: Photorealistic, 3D render, vibrant lighting, ultra-detailed, clean corporate aesthetic.";

        $response = wp_remote_post('https://api.openai.com/v1/images/generations', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => 'dall-e-3',
                'prompt' => $prompt,
                'n' => 1,
                'size' => '1024x1024',
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            return '';
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['data'][0]['url'] ?? '';
    }
}
