<?php
/**
 * Main module for Thriveo Certification
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'class-score-calculador.php';

class Thriveo_AI_Jobs_Certificacao_Controller
{

    private $table_cert;
    private $table_candidates;

    public function __construct()
    {
        global $wpdb;
        $this->table_cert = $wpdb->prefix . 'thriveo_certificacoes';
        $this->table_candidates = $wpdb->prefix . 'thriveo_ai_candidates';
    }

    /**
     * D1 Profile Validation (Automatic)
     */
    public function validar_v1_perfil($candidato_id)
    {
        global $wpdb;
        $candidato = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_candidates} WHERE id = %d", $candidato_id));
        if (!$candidato)
            return false;

        $score = Thriveo_AI_Jobs_Score_Calculador::calcular_score_d1($candidato);

        if ($score >= 70) {
            $this->conceder_selo($candidato_id, 'D1', 'Perfil Verificado', $score);
            $wpdb->update($this->table_candidates, ['selo_d1' => 1, 'score_perfil' => $score], ['id' => $candidato_id]);
        } else {
            $wpdb->update($this->table_candidates, ['selo_d1' => 0, 'score_perfil' => $score], ['id' => $candidato_id]);
        }

        return [
            'score' => $score,
            'selo_concedido' => ($score >= 70)
        ];
    }

    /**
     * General function to grant a badge
     */
    public function conceder_selo($candidato_id, $tipo, $subtipo, $score)
    {
        global $wpdb;

        // Check for existing active badge
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$this->table_cert} 
             WHERE candidato_id = %d AND tipo = %s AND subtipo = %s AND status = 'ativo'",
            $candidato_id,
            $tipo,
            $subtipo
        ));

        if ($existing) {
            $wpdb->update($this->table_cert, [
                'score' => $score,
                'concedido_em' => current_time('mysql')
            ], ['id' => $existing->id]);
        } else {
            $codigo = wp_generate_uuid4();
            $wpdb->insert($this->table_cert, [
                'candidato_id' => $candidato_id,
                'tipo' => $tipo,
                'subtipo' => $subtipo,
                'score' => $score,
                'codigo_verificacao' => $codigo,
                'status' => 'ativo',
                'concedido_em' => current_time('mysql'),
                'expira_em' => date('Y-m-d H:i:s', strtotime('+12 months'))
            ]);
        }

        $this->check_elite_badge($candidato_id);
    }

    /**
     * Check if Elite badge should be granted (D1 to D4 active)
     */
    private function check_elite_badge($candidato_id)
    {
        global $wpdb;
        $active_types = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT tipo FROM {$this->table_cert} WHERE candidato_id = %d AND status = 'ativo' AND tipo IN ('D1','D2','D3','D4')",
            $candidato_id
        ));

        if (count($active_types) >= 4) {
            $score_elite = Thriveo_AI_Jobs_Score_Calculador::calcular_score_elite($candidato_id);
            $this->conceder_selo($candidato_id, 'ELITE', 'Thriveo Elite', $score_elite);
            $wpdb->update($this->table_candidates, ['selo_elite' => 1], ['id' => $candidato_id]);
        }
    }

    /**
     * Get candidate certifications status
     */
    public function get_certificacoes_status($candidato_id)
    {
        global $wpdb;
        $certs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_cert} WHERE candidato_id = %d AND status = 'ativo'",
            $candidato_id
        ));

        $candidato = $wpdb->get_row($wpdb->prepare("SELECT score_perfil, selo_d1, selo_d2, selo_d3, selo_d4, selo_elite FROM {$this->table_candidates} WHERE id = %d", $candidato_id));

        return [
            'candidato' => $candidato,
            'certificacoes' => $certs
        ];
    }
}
