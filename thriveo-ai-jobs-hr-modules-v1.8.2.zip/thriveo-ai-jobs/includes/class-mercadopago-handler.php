<?php
/**
 * Mercado Pago API Handler for Thriveo AI Jobs
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_MercadoPago_Handler
{
    public static function get_config()
    {
        $is_sandbox = (bool) get_option('thriveo_mp_sandbox_mode', 1);
        
        if ($is_sandbox) {
            $token = get_option('thriveo_mp_sandbox_access_token', 'APP_USR-227931852663399-031509-381b83217eb0aa63d710fc5a35eacb88-3268408628');
            $public_key = get_option('thriveo_mp_sandbox_public_key', 'APP_USR-ac5a0383-29d2-4ad3-a5f2-e87e5e78ef95');
        } else {
            $token = get_option('thriveo_mp_access_token', '');
            $public_key = get_option('thriveo_mp_public_key', '');
        }

        return [
            'token'      => $token,
            'public_key' => $public_key,
            'sandbox'    => $is_sandbox
        ];
    }

    private static function request($method, $endpoint, $body = [])
    {
        $config = self::get_config();
        $url = 'https://api.mercadopago.com' . $endpoint;

        $args = [
            'method'     => $method,
            'timeout'    => 45,
            'sslverify'  => false,
            'headers'    => [
                'Authorization'   => 'Bearer ' . $config['token'],
                'Content-Type'    => 'application/json',
                'User-Agent'      => 'ThriveoAIJobs/1.0.0'
            ],
        ];

        if (!empty($body)) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $data = json_decode($raw_body, true);

        return [
            'success'     => ($code >= 200 && $code < 300),
            'code'        => $code,
            'data'        => $data ?? [],
            'debug_url'   => $url
        ];
    }

    /**
     * Cria a Preferência de Pagamento (Checkout Pro)
     */
    public static function criar_preferencia($dados)
    {
        $config = self::get_config();
        
        // Em modo sandbox, forçamos um e-mail de teste para o pagador.
        // Isso impede que o Mercado Pago identifique o usuário logado (ex: ezequiel@ezequiel.pro.br)
        // como um usuário real do Mercado Pago e tente forçar login/2FA ou bloqueie pagamentos sandbox.
        $payer_email = $dados['customer_email'];
        if ($config['sandbox']) {
            $payer_email = 'comprador_teste_' . time() . '@testuser.com';
        }

        $payload = [
            'items' => [
                [
                    'title'       => $dados['plan_name'],
                    'quantity'    => 1,
                    'unit_price'  => (float) $dados['price'],
                    'currency_id' => 'BRL'
                ]
            ],
            'payer' => [
                'email' => $payer_email,
                'name'  => $dados['customer_name']
            ],
            'back_urls' => [
                'success' => home_url('/?thriveo_empresa_vagas=1&mp_status=success'),
                'failure' => home_url('/?thriveo_empresa_vagas=1&mp_status=failure'),
                'pending' => home_url('/?thriveo_empresa_vagas=1&mp_status=pending'),
            ],
            'auto_return' => 'approved',
            'external_reference' => $dados['reference_id']
        ];
        
        // Remove empty payer identification if none is provided
        if (!empty($dados['customer_tax_id'])) {
            $tax_id = preg_replace('/[^0-9]/', '', $dados['customer_tax_id']);
            $type = strlen($tax_id) > 11 ? 'CNPJ' : 'CPF';
            $payload['payer']['identification'] = [
                'type'   => $type,
                'number' => $tax_id
            ];
        }

        return self::request('POST', '/checkout/preferences', $payload);
    }

    /**
     * Busca dados do pagamento no Mercado Pago
     */
    public static function get_payment($payment_id)
    {
        return self::request('GET', '/v1/payments/' . $payment_id);
    }
}
