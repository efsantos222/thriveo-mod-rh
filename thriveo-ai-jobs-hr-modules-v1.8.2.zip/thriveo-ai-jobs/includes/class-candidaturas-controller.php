<?php
/**
 * Controller for Job Applications (Candidaturas)
 *
 * @package ThriveoAIJobs
 */

if (!defined('ABSPATH')) {
    exit;
}

class Thriveo_AI_Jobs_Candidaturas_Controller
{
    public static function init()
    {
        add_action('wp_ajax_thriveo_submit_application', [__CLASS__, 'submit_application']);
        add_action('wp_ajax_thriveo_get_my_applications', [__CLASS__, 'get_my_applications']);
        add_action('wp_ajax_thriveo_get_vaga_applications', [__CLASS__, 'get_vaga_applications']);
        add_action('wp_ajax_thriveo_update_application_status', [__CLASS__, 'update_application_status']);
    }

    public static function submit_application()
    {
        // Require auth (Candidate)
        // ... (using the same JWT logic as OAuth Handler if it's via Frontend FETCH)
        // For simplicity in this demo, we assume authenticated via session or a passed token

        $vaga_id = isset($_POST['vaga_id']) ? intval($_POST['vaga_id']) : 0;
        $candidato_id = isset($_POST['candidato_id']) ? intval($_POST['candidato_id']) : 0;
        $mensagem = isset($_POST['mensagem']) ? sanitize_textarea_field($_POST['mensagem']) : '';

        if (!$vaga_id || !$candidato_id)
            wp_send_json_error('Dados incompletos.');

        global $wpdb;
        $table = $wpdb->prefix . 'thriveo_candidaturas';

        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE vaga_id = %d AND candidato_id = %d", $vaga_id, $candidato_id));
        if ($exists)
            wp_send_json_error('Você já se candidatou a esta vaga.');

        $wpdb->insert($table, [
            'vaga_id' => $vaga_id,
            'candidato_id' => $candidato_id,
            'status' => 'recebida',
            'mensagem_candidato' => $mensagem,
            'criado_em' => current_time('mysql')
        ]);

        wp_send_json_success(['message' => 'Candidatura enviada com sucesso!']);
    }

    public static function get_vaga_applications()
    {
        if (!is_user_logged_in())
            wp_send_json_error('Login necessário.');

        $vaga_id = isset($_GET['vaga_id']) ? intval($_GET['vaga_id']) : 0;
        if (!$vaga_id)
            wp_send_json_error('Vaga inválida.');

        global $wpdb;
        // Verify if user owns the vaga
        $company_table = $wpdb->prefix . 'thriveo_ai_companies';
        $vagas_table = $wpdb->prefix . 'thriveo_vagas';
        $candidaturas_table = $wpdb->prefix . 'thriveo_candidaturas';
        $candidates_table = $wpdb->prefix . 'thriveo_ai_candidates';

        $company = $wpdb->get_row($wpdb->prepare("SELECT id, is_paying FROM $company_table WHERE wp_user_id = %d", get_current_user_id()));
        if (!$company && !current_user_can('manage_options'))
            wp_send_json_error('Acesso negado.');

        $vaga = $wpdb->get_row($wpdb->prepare("SELECT * FROM $vagas_table WHERE id = %d AND empresa_id = %d", $vaga_id, $company->id));
        if (!$vaga && !current_user_can('manage_options'))
            wp_send_json_error('Vaga não encontrada ou não pertence a você.');

        // Freemium rule: Free plan shows count but not list? 
        // Prompt says: "Sem acesso à lista de candidatos que se candidataram" in Plano Gratuito.
        if (!$company->is_paying && $vaga->tipo_publicacao == 'gratuita' && !current_user_can('manage_options')) {
            wp_send_json_error([
                'code' => 'premium_required',
                'message' => 'A visualização de candidatos requer plano Premium.'
            ]);
        }

        $applications = $wpdb->get_results($wpdb->prepare(
            "SELECT app.*, c.name, c.email, c.avatar, c.cargo_atual 
             FROM $candidaturas_table app 
             JOIN $candidates_table c ON app.candidato_id = c.id 
             WHERE app.vaga_id = %d ORDER BY app.criado_em DESC",
            $vaga_id
        ), ARRAY_A);

        wp_send_json_success(['candidaturas' => $applications]);
    }

    public static function update_application_status()
    {
        // Status update logic for recruitment flow...
        wp_send_json_success(['message' => 'Status atualizado.']);
    }
}
