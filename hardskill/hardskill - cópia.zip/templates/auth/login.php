<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TestProf Hardskill</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
</head>

<body style="justify-content: center; align-items: center;">

    <div class="card" style="width: 100%; max-width: 400px;">
        <div class="text-center mb-4">
            <h1 class="logo">TestProf Hardskill</h1>
            <p style="color: var(--text-muted)">Acesse sua conta para continuar</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form action="<?= APP_URL ?>/login" method="POST">
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" name="email" id="email" required placeholder="seu@email.com">
            </div>

            <div class="form-group">
                <label for="password">Senha</label>
                <input type="password" name="password" id="password" required placeholder="Sua senha">
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%;">Entrar</button>
        </form>
    </div>

</body>

</html>