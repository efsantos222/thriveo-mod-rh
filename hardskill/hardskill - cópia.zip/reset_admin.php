<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/config/database.php';

echo "<h1>Reset de Senha Admin</h1>";

$email = 'admin@testprof.com.br';
$newPass = 'admin123';
$hash = password_hash($newPass, PASSWORD_DEFAULT);

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se usuário existe
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Atualiza senha
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->execute([$hash, $email]);
        echo "<p style='color:green'>Senha do usuário <strong>$email</strong> atualizada com sucesso!</p>";
        echo "<p>Novo Hash gerado: $hash</p>";
    } else {
        // Cria usuário
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES ('Administrador', ?, ?, 'admin')");
        $stmt->execute([$email, $hash]);
        echo "<p style='color:green'>Usuário <strong>$email</strong> CRIADO com sucesso!</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color:red'>Erro no banco: " . $e->getMessage() . "</p>";
}
