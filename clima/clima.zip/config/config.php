<?php
session_start();

// Configurações gerais
define('SITE_NAME', 'Pesquisa de Clima Semanal');
define('BASE_URL', 'http://localhost/pesquisa-clima'); // Alterar para URL de produção
define('ADMIN_EMAIL', 'admin@exemplo.com');

// Configurações de timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurações de sessão
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);

// Funções de utilidade
function redirect($path) {
    header("Location: " . BASE_URL . $path);
    exit();
}

function sanitize($input) {
    return htmlspecialchars(strip_tags($input), ENT_QUOTES, 'UTF-8');
}

// Função para verificar se usuário está logado
function checkAuth() {
    if (!isset($_SESSION['admin_id'])) {
        redirect('/admin/login.php');
    }
}

// Função para gerar código único
function generateUniqueCode() {
    return strtoupper(substr(uniqid(), -6));
}

// Função para validar e-mail
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}
