<?php
require_once '../config/config.php';
require_once '../config/database.php';

// Verificar se o respondente está autenticado
if (!isset($_SESSION['respondente_id'])) {
    redirect('/');
}

$db = Database::getInstance()->getConnection();

// Verificar se já respondeu a pesquisa desta semana
$stmt = $db->prepare("
    SELECT COUNT(*) as total 
    FROM respostas r 
    WHERE r.id_respondente = ? 
    AND YEARWEEK(r.data_resposta) = YEARWEEK(NOW())
");
$stmt->execute([$_SESSION['respondente_id']]);
$jaRespondeu = $stmt->fetch()['total'] > 0;

if ($jaRespondeu) {
    session_destroy();
    $_SESSION['error'] = "Você já respondeu a pesquisa desta semana.";
    redirect('/');
}

// Buscar perguntas ativas
$stmt = $db->prepare("
    SELECT id, texto_pergunta 
    FROM perguntas 
    WHERE ativa = 1 
    AND (
        recorrente = 1 
        OR (recorrente = 0 AND YEARWEEK(created_at) = YEARWEEK(NOW()))
    )
    ORDER BY created_at ASC
");
$stmt->execute();
$perguntas = $stmt->fetchAll();

if (empty($perguntas)) {
    session_destroy();
    $_SESSION['error'] = "Não há perguntas disponíveis no momento.";
    redirect('/');
}

// Processar respostas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();
        
        foreach ($_POST['respostas'] as $pergunta_id => $resposta) {
            if (empty(trim($resposta))) {
                throw new Exception("Todas as perguntas devem ser respondidas.");
            }
            
            $stmt = $db->prepare("
                INSERT INTO respostas (id_pergunta, id_respondente, resposta) 
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$pergunta_id, $_SESSION['respondente_id'], trim($resposta)]);
        }
        
        $db->commit();
        session_destroy();
        $_SESSION['success'] = "Obrigado por participar da pesquisa!";
        redirect('/');
        
    } catch (Exception $e) {
        $db->rollBack();
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa de Clima</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .question-card {
            transition: transform 0.2s;
        }
        .question-card:hover {
            transform: translateY(-5px);
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0 text-center">Pesquisa de Clima Semanal</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <div class="alert alert-info">
                            <p class="mb-0">
                                <i class="bi bi-info-circle"></i>
                                Suas respostas são confidenciais e ajudarão a melhorar nosso ambiente de trabalho.
                            </p>
                        </div>

                        <form method="POST" id="surveyForm">
                            <?php foreach ($perguntas as $index => $pergunta): ?>
                                <div class="card question-card mb-4">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            Pergunta <?php echo $index + 1; ?>
                                        </h5>
                                        <p class="card-text">
                                            <?php echo htmlspecialchars($pergunta['texto_pergunta']); ?>
                                        </p>
                                        <textarea 
                                            class="form-control" 
                                            name="respostas[<?php echo $pergunta['id']; ?>]" 
                                            required
                                            placeholder="Digite sua resposta aqui..."
                                        ></textarea>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    Enviar Respostas
                                </button>
                                <a href="logout.php" class="btn btn-outline-secondary">
                                    Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confirmação antes de enviar o formulário
        document.getElementById('surveyForm').addEventListener('submit', function(e) {
            if (!confirm('Tem certeza que deseja enviar suas respostas? Esta ação não poderá ser desfeita.')) {
                e.preventDefault();
            }
        });

        // Salvar rascunho no localStorage
        const form = document.getElementById('surveyForm');
        const textareas = form.getElementsByTagName('textarea');

        // Carregar rascunhos salvos
        for (let textarea of textareas) {
            const savedValue = localStorage.getItem('draft_' + textarea.name);
            if (savedValue) {
                textarea.value = savedValue;
            }

            // Salvar ao digitar
            textarea.addEventListener('input', function() {
                localStorage.setItem('draft_' + this.name, this.value);
            });
        }

        // Limpar rascunhos após envio
        form.addEventListener('submit', function() {
            for (let textarea of textareas) {
                localStorage.removeItem('draft_' + textarea.name);
            }
        });
    </script>
</body>
</html>
