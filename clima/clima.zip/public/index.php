<?php
require_once '../config/config.php';
require_once '../config/database.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h4>Pesquisa de Clima</h4>
                    </div>
                    <div class="card-body">
                        <form action="validate.php" method="POST">
                            <div class="mb-3">
                                <label for="codigo" class="form-label">Digite seu código:</label>
                                <input type="text" class="form-control" id="codigo" name="codigo" required 
                                       maxlength="10" placeholder="Digite o código fornecido">
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Acessar Pesquisa</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
