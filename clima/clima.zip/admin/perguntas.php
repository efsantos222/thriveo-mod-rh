<?php
require_once '../config/config.php';
require_once '../config/database.php';
checkAuth();

$db = Database::getInstance()->getConnection();

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $texto = sanitize($_POST['texto_pergunta']);
        $recorrente = isset($_POST['recorrente']) ? 1 : 0;
        $periodicidade = sanitize($_POST['periodicidade'] ?? 'semanal');
        
        $stmt = $db->prepare("INSERT INTO perguntas (texto_pergunta, recorrente, periodicidade) VALUES (?, ?, ?)");
        $stmt->execute([$texto, $recorrente, $periodicidade]);
        
    } elseif ($action === 'update') {
        $id = (int)$_POST['id'];
        $texto = sanitize($_POST['texto_pergunta']);
        $ativa = isset($_POST['ativa']) ? 1 : 0;
        $recorrente = isset($_POST['recorrente']) ? 1 : 0;
        $periodicidade = sanitize($_POST['periodicidade'] ?? 'semanal');
        
        $stmt = $db->prepare("UPDATE perguntas SET texto_pergunta = ?, ativa = ?, recorrente = ?, periodicidade = ? WHERE id = ?");
        $stmt->execute([$texto, $ativa, $recorrente, $periodicidade, $id]);
        
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("DELETE FROM perguntas WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    redirect('/admin/perguntas.php');
}

// Buscar perguntas
$stmt = $db->query("SELECT * FROM perguntas ORDER BY created_at DESC");
$perguntas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Perguntas - Área Administrativa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Painel Administrativo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="perguntas.php">Perguntas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="respondentes.php">Respondentes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.php">Relatórios</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Gestão de Perguntas</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#novaPerguntaModal">
                Nova Pergunta
            </button>
        </div>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Pergunta</th>
                        <th>Status</th>
                        <th>Recorrente</th>
                        <th>Periodicidade</th>
                        <th>Criada em</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($perguntas as $pergunta): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pergunta['texto_pergunta']); ?></td>
                        <td>
                            <span class="badge bg-<?php echo $pergunta['ativa'] ? 'success' : 'danger'; ?>">
                                <?php echo $pergunta['ativa'] ? 'Ativa' : 'Inativa'; ?>
                            </span>
                        </td>
                        <td><?php echo $pergunta['recorrente'] ? 'Sim' : 'Não'; ?></td>
                        <td><?php echo htmlspecialchars($pergunta['periodicidade']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($pergunta['created_at'])); ?></td>
                        <td>
                            <button class="btn btn-sm btn-primary" 
                                    onclick="editarPergunta(<?php echo htmlspecialchars(json_encode($pergunta)); ?>)">
                                Editar
                            </button>
                            <button class="btn btn-sm btn-danger" 
                                    onclick="confirmarExclusao(<?php echo $pergunta['id']; ?>)">
                                Excluir
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Nova Pergunta -->
    <div class="modal fade" id="novaPerguntaModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nova Pergunta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create">
                        <div class="mb-3">
                            <label for="texto_pergunta" class="form-label">Texto da Pergunta</label>
                            <textarea class="form-control" id="texto_pergunta" name="texto_pergunta" required></textarea>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="recorrente" name="recorrente">
                                <label class="form-check-label" for="recorrente">
                                    Pergunta Recorrente
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="periodicidade" class="form-label">Periodicidade</label>
                            <select class="form-select" id="periodicidade" name="periodicidade">
                                <option value="semanal">Semanal</option>
                                <option value="quinzenal">Quinzenal</option>
                                <option value="mensal">Mensal</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Editar Pergunta -->
    <div class="modal fade" id="editarPerguntaModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Editar Pergunta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label for="edit_texto_pergunta" class="form-label">Texto da Pergunta</label>
                            <textarea class="form-control" id="edit_texto_pergunta" name="texto_pergunta" required></textarea>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit_ativa" name="ativa">
                                <label class="form-check-label" for="edit_ativa">
                                    Pergunta Ativa
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit_recorrente" name="recorrente">
                                <label class="form-check-label" for="edit_recorrente">
                                    Pergunta Recorrente
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="edit_periodicidade" class="form-label">Periodicidade</label>
                            <select class="form-select" id="edit_periodicidade" name="periodicidade">
                                <option value="semanal">Semanal</option>
                                <option value="quinzenal">Quinzenal</option>
                                <option value="mensal">Mensal</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Exclusão -->
    <div class="modal fade" id="confirmarExclusaoModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja excluir esta pergunta?
                </div>
                <div class="modal-footer">
                    <form method="POST">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" id="delete_id">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Confirmar Exclusão</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editarPergunta(pergunta) {
            document.getElementById('edit_id').value = pergunta.id;
            document.getElementById('edit_texto_pergunta').value = pergunta.texto_pergunta;
            document.getElementById('edit_ativa').checked = pergunta.ativa == 1;
            document.getElementById('edit_recorrente').checked = pergunta.recorrente == 1;
            document.getElementById('edit_periodicidade').value = pergunta.periodicidade;
            
            new bootstrap.Modal(document.getElementById('editarPerguntaModal')).show();
        }

        function confirmarExclusao(id) {
            document.getElementById('delete_id').value = id;
            new bootstrap.Modal(document.getElementById('confirmarExclusaoModal')).show();
        }
    </script>
</body>
</html>
